"use client";

import { useEffect, useRef, useState } from "react";
import { cn } from "@/lib/utils";
import { OptionalSvgIcon } from "@/components/OptionalSvgIcon";

function labelForScore(score: number) {
  if (score <= 20) return "Extreme Fear";
  if (score <= 40) return "Fear";
  if (score <= 60) return "Neutral";
  if (score <= 80) return "Greed";
  return "Extreme Greed";
}

function colorClassForScore(score: number) {
  if (score <= 20) return { bar: "bg-red-600",     text: "text-red-500"     };
  if (score <= 40) return { bar: "bg-orange-500",  text: "text-orange-400"  };
  if (score <= 60) return { bar: "bg-yellow-400",  text: "text-yellow-400"  };
  if (score <= 80) return { bar: "bg-lime-400",    text: "text-lime-400"    };
  return                  { bar: "bg-emerald-400", text: "text-emerald-400" };
}

// Interpolate bar color as a hex string based on 0-100 score
function barColorForPct(pct: number): string {
  // red(0) → orange(25) → yellow(50) → lime(75) → emerald(100)
  const stops: [number, [number,number,number]][] = [
    [0,   [220, 38,  38 ]],  // red-600
    [25,  [249, 115, 22 ]],  // orange-500
    [50,  [250, 204, 21 ]],  // yellow-400
    [75,  [163, 230, 53 ]],  // lime-400
    [100, [52,  211, 153]],  // emerald-400
  ];
  let lo = stops[0], hi = stops[stops.length - 1];
  for (let i = 0; i < stops.length - 1; i++) {
    if (pct >= stops[i][0] && pct <= stops[i + 1][0]) {
      lo = stops[i]; hi = stops[i + 1]; break;
    }
  }
  const t = (pct - lo[0]) / (hi[0] - lo[0] || 1);
  const r = Math.round(lo[1][0] + (hi[1][0] - lo[1][0]) * t);
  const g = Math.round(lo[1][1] + (hi[1][1] - lo[1][1]) * t);
  const b = Math.round(lo[1][2] + (hi[1][2] - lo[1][2]) * t);
  return `rgb(${r},${g},${b})`;
}

// Rolling digit wheel — same mechanic as PriceChart
const DIGITS = ["0","1","2","3","4","5","6","7","8","9"];
// The preceding 9 makes the initial 0 and target 9 adjacent on the wheel.
const DIGIT_WHEEL = ["9", ...DIGITS];
const DIGIT_RATIO: Record<string, number> = {
  "0": 0.62, "1": 0.36, "2": 0.58, "3": 0.58,
  "4": 0.62, "5": 0.58, "6": 0.60, "7": 0.52,
  "8": 0.62, "9": 0.60,
};

function RollingDigit({ ch, started }: { ch: string; started: boolean }) {
  const isDigit = DIGITS.includes(ch);
  const idx = isDigit ? parseInt(ch) : 0;
  const rowPx = 36;
  const slotPx = Math.round((DIGIT_RATIO[ch] ?? 0.62) * rowPx);
  if (!isDigit) {
    return (
      <span className="inline-block leading-none text-3xl font-bold" style={{ lineHeight: `${rowPx}px` }}>
        {ch}
      </span>
    );
  }
  return (
    <span className="inline-block overflow-hidden align-bottom" style={{ height: rowPx, width: slotPx }}>
      <span
        className="flex flex-col"
        style={{
          transform: `translateY(-${started ? (ch === "9" ? 0 : (idx + 1) * rowPx) : rowPx}px)`,
          transition: started ? "transform 1.657s cubic-bezier(0.22, 1, 0.36, 1)" : "none",
          willChange: "transform",
        }}
      >
        {DIGIT_WHEEL.map((d, index) => (
          <span key={`${d}-${index}`} className="block text-center select-none text-3xl font-bold leading-none" style={{ height: rowPx, lineHeight: `${rowPx}px`, width: slotPx }}>
            {d}
          </span>
        ))}
      </span>
    </span>
  );
}

function RollingScore({ score, colorClass, started }: { score: number; colorClass: string; started: boolean }) {
  const chars = String(score).split("");
  return (
    <span className={cn("inline-flex items-end", colorClass)} style={{ height: 36 }}>
      {chars.map((ch, i) => (
        <RollingDigit key={i} ch={ch} started={started} />
      ))}
    </span>
  );
}

function barGlowForPct(pct: number): string {
  return barColorForPct(pct).replace("rgb(", "rgba(").replace(")", ", 0.42)");
}

function SentimentBar({ score }: { score: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const [started, setStarted] = useState(false);
  const [animPct, setAnimPct] = useState(0);
  const { text } = colorClassForScore(score);
  const label = labelForScore(score);

  // Trigger once when section enters viewport
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setStarted(true);
          obs.disconnect();
        }
      },
      { threshold: 0.3 }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);

  // Animate the percentage smoothly after started
  useEffect(() => {
    if (!started) return;
    const target = Math.min(99, Math.max(1, score));
    const duration = 1755;
    const start = performance.now();
    let raf: number;
    function step(now: number) {
      const t = Math.min(1, (now - start) / duration);
      // ease out cubic
      const eased = 1 - Math.pow(1 - t, 3);
      setAnimPct(eased * target);
      if (t < 1) raf = requestAnimationFrame(step);
    }
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [started, score]);

  return (
    <div ref={ref} className="flex flex-col gap-3">
      <div className="flex items-baseline gap-2">
        <RollingScore score={score} colorClass={text} started={started} />
        <span className={cn("text-sm font-semibold", text)}>{label}</span>
      </div>

      {/* Track with animated fill + interpolated color */}
      <div className="h-2 w-full rounded-full bg-panel-muted">
        <div
          className="h-full rounded-full"
          style={{
            width: `${animPct}%`,
            backgroundColor: barColorForPct(animPct),
            boxShadow: `0 0 10px ${barGlowForPct(animPct)}`,
            transition: "none",
          }}
        />
      </div>
    </div>
  );
}

export function MarketSentiment({
  score,
  drivers,
}: {
  score: number;
  drivers: string[];
}) {
  return (
    <section className="rounded-xl bg-black p-5">
      <p className="-ml-5 mb-4 inline-flex items-center gap-2 text-sm font-medium uppercase tracking-[0.18em] text-accent">
        <OptionalSvgIcon name="stock-sentiment" className="h-6 w-6" />
        Stock Sentiment
      </p>

      <SentimentBar score={score} />
    </section>
  );
}

export function ComparisonMarketSentiment({ scores }: { scores: [number, number] }) {
  const ref = useRef<HTMLElement>(null);
  const [started, setStarted] = useState(false);
  const [animatedScores, setAnimatedScores] = useState<[number, number]>([0, 0]);
  const colors = ["#a855f7", "#f97316"] as const;

  useEffect(() => {
    const element = ref.current;
    if (!element) return;
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) {
        setStarted(true);
        observer.disconnect();
      }
    }, { threshold: 0.3 });
    observer.observe(element);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!started) return;
    const targets = scores.map((score) => Math.min(99, Math.max(1, score))) as [number, number];
    const duration = 1755;
    const start = performance.now();
    let frame = 0;
    function step(now: number) {
      const progress = Math.min(1, (now - start) / duration);
      const eased = 1 - Math.pow(1 - progress, 3);
      setAnimatedScores([targets[0] * eased, targets[1] * eased]);
      if (progress < 1) frame = requestAnimationFrame(step);
    }
    frame = requestAnimationFrame(step);
    return () => cancelAnimationFrame(frame);
  }, [started, scores[0], scores[1]]);

  return (
    <section ref={ref} className="rounded-xl bg-black p-5">
      <p className="mb-4 inline-flex items-center gap-2 text-sm font-medium uppercase tracking-[0.18em] text-accent"><OptionalSvgIcon name="stock-sentiment" className="h-6 w-6" />Stock Sentiment</p>
      <div className="space-y-4">
        {scores.map((rawScore, index) => {
          const score = Math.max(0, Math.min(100, Math.round(rawScore)));
          const color = colors[index];
          return (
            <div key={index}>
              <div className="mb-3 flex justify-start">
                <RollingScore score={score} colorClass={index === 0 ? "text-purple-400" : "text-orange-400"} started={started} />
              </div>
              <div className="h-2 w-full rounded-full bg-panel-muted">
                <div
                  className="h-full rounded-full"
                  style={{
                    width: `${animatedScores[index]}%`,
                    backgroundColor: color,
                    boxShadow: `0 0 10px ${color}70`,
                    transition: "none",
                  }}
                />
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
