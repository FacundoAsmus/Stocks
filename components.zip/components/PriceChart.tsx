"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Area,
  ComposedChart,
  CartesianGrid,
  Line,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis
} from "recharts";
import { RotateCcw } from "lucide-react";

import { cn } from "@/lib/utils";
import type { CandlePoint, ChartPeriod } from "@/types/stock";

const SHORT_PERIODS: ChartPeriod[] = ["1D", "1W", "1M", "2M", "3M", "5M", "6M"];
const LONG_PERIODS:  ChartPeriod[] = ["1Y", "2Y", "5Y", "ALL"];
const LONG_TERM_SET  = new Set<ChartPeriod>(["1Y", "2Y", "5Y", "ALL"]);

// Which moving averages make sense to offer for a given period — a moving
// average that's much longer than the visible window just renders as a
// flat, uninformative line, so it's hidden rather than shown broken.
const MA_AVAILABILITY: Record<ChartPeriod, number[]> = {
  "1D": [],
  "1W": [7],
  "1M": [7, 25],
  "2M": [7, 25],
  "3M": [7, 25, 99],
  "5M": [7, 25, 99],
  "6M": [7, 25, 99],
  "1Y": [7, 25, 99],
  "2Y": [7, 25, 99],
  "5Y": [7, 25, 99],
  "ALL": [7, 25, 99],
};
const MA_COLORS: Record<number, string> = {
  7: "#f59e0b",   // orange-yellowish
  25: "#ec4899",  // pink
  99: "#8b5cf6",  // violet
};

// `windowDays` is a number of *days*, not points — periods have wildly
// different point granularity (a "5Y" chart's points might each span a
// week, while "1M" points are daily), so a fixed point-count window would
// mean very different real time spans depending on the period. Using a
// time-based sliding window keeps "MA(99)" meaning the same thing — the
// trailing 99 days — regardless of how coarse the underlying data is.
function computeMA(points: CandlePoint[], windowDays: number): (number | null)[] {
  const DAY_MS = 24 * 60 * 60 * 1000;
  const result: (number | null)[] = new Array(points.length).fill(null);
  if (!points.length) return result;

  const time = (p: CandlePoint) => new Date(p.date === "prev" ? Date.now() : p.date).getTime();
  const firstTime = time(points[0]);

  let start = 0;
  let sum = 0;
  for (let i = 0; i < points.length; i++) {
    sum += points[i].close;
    const endTime = time(points[i]);
    const windowStart = endTime - windowDays * DAY_MS;
    while (start < i && time(points[start]) < windowStart) {
      sum -= points[start].close;
      start++;
    }
    const count = i - start + 1;
    const hasFullWindow = (endTime - firstTime) >= windowDays * DAY_MS;
    result[i] = hasFullWindow && count > 0 ? sum / count : null;
  }
  return result;
}

/* ─── Date label for tooltip crosshair ──────────────────────────────────── */
function tooltipLabel(dateStr: string, period: ChartPeriod): string {
  if (dateStr === "prev") return "Yesterday";
  const d = new Date(dateStr);
  if (period === "1D")
    return d.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit", hour12: true });
  if (period === "1W")
    return d.toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric", hour: "numeric", minute: "2-digit", hour12: true });
  if (period === "5Y" || period === "ALL")
    return d.toLocaleDateString("en-US", { month: "short", year: "numeric" });
  if (period === "1Y" || period === "2Y")
    return d.toLocaleDateString("en-US", { month: "long", year: "numeric" });
  return d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
}

/* ─── X-axis tick labels ─────────────────────────────────────────────────── */
function xAxisLabel(dateStr: string, period: ChartPeriod): string {
  const d = new Date(dateStr);
  if (period === "1D")
    return d.toLocaleTimeString("en-US", { hour: "numeric", hour12: true });
  if (period === "1W")
    return d.toLocaleDateString("en-US", { weekday: "short" });
  if (period === "5Y" || period === "ALL")
    return d.getFullYear().toString();
  if (period === "1Y" || period === "2Y")
    return d.toLocaleDateString("en-US", { month: "short", year: "2-digit" });
  return d.toLocaleDateString("en-US", { month: "short", day: "numeric" });
}


/* ─── Number-wheel digit ─────────────────────────────────────────────────── */
// Each digit is a vertical strip of 0–9. We translate it up by idx × rowPx.
// Digit wheel — vertical strip of 0–9, clipped to one row height.
// Width per digit is set via CSS `ch` units scoped to each size, which gives
// natural variable spacing (1 narrower than 8) without any JS measurement loop.
const DIGIT_CHARS = ["0","1","2","3","4","5","6","7","8","9"];

// Proportional widths as a fraction of rowPx (measured from Inter at text-5xl/text-2xl).
// "1" is naturally narrow; "0","4","8" are wide. These ratios stay correct at any px size.
const DIGIT_RATIO: Record<string, number> = {
  "0": 0.62, "1": 0.36, "2": 0.58, "3": 0.58,
  "4": 0.62, "5": 0.58, "6": 0.60, "7": 0.52,
  "8": 0.62, "9": 0.60,
};

function Digit({ ch, size = "lg" }: { ch: string; size?: "sm" | "lg" }) {
  const isDigit = DIGIT_CHARS.includes(ch);
  const idx     = isDigit ? parseInt(ch) : 0;

  const rowPx     = size === "lg" ? 54 : 32;
  const fontClass = size === "lg"
    ? "text-5xl font-semibold text-text-primary"
    : "text-2xl font-medium";

  if (!isDigit) {
    return (
      <span
        className={cn(fontClass, "inline-block leading-none")}
        style={{ lineHeight: `${rowPx}px` }}
      >
        {ch}
      </span>
    );
  }

  const slotPx = Math.round((DIGIT_RATIO[ch] ?? 0.62) * rowPx);

  return (
    <span
      className="inline-block overflow-hidden align-bottom"
      style={{ height: rowPx, width: slotPx, transition: "width 1.04s cubic-bezier(0.22, 1, 0.36, 1)" }}
    >
      <span
        className="flex flex-col"
        style={{
          transform: `translateY(-${idx * rowPx}px)`,
          transition: "transform 1.04s cubic-bezier(0.22, 1, 0.36, 1)",
          willChange: "transform",
        }}
      >
        {DIGIT_CHARS.map((d) => (
          <span
            key={d}
            className={cn(fontClass, "block text-center select-none leading-none")}
            style={{ height: rowPx, lineHeight: `${rowPx}px`, width: slotPx }}
          >
            {d}
          </span>
        ))}
      </span>
    </span>
  );
}

/* ─── Animated price display (wheels for digits, static for $ . , + - %) ── */
function WheelPrice({
  value,
  size = "lg",
  colorClass,
}: {
  value: string;
  size?: "sm" | "lg";
  colorClass?: string;
}) {
  const chars = value.split("");
  return (
    <span className={cn("inline-flex items-end", colorClass)}>
      {chars.map((ch, i) => (
        <Digit key={i} ch={ch} size={size} />
      ))}
    </span>
  );
}

/* ─── Custom crosshair tooltip ───────────────────────────────────────────── */
function CrosshairTooltip({
  active,
  payload,
  label,
  period,
  onHover,
  isTouching,
}: {
  active?: boolean;
  payload?: { value: number }[];
  label?: string;
  period: ChartPeriod;
  onHover: (price: number | null, date: string | null) => void;
  isTouching?: boolean;
}) {
  const price = payload?.[0]?.value ?? null;
  const date  = label ?? null;

  const prevRef = useRef<{ price: number | null; date: string | null }>({ price: null, date: null });

  useEffect(() => {
    const p = active ? price : null;
    const d = active ? date  : null;
    if (prevRef.current.price !== p || prevRef.current.date !== d) {
      prevRef.current = { price: p, date: d };
      onHover(p, d);
    }
  });

  // On touch devices, hide the bubble when finger is lifted (isTouching=false).
  // On desktop (mouse), always show when active.
  const isTouchDevice = typeof window !== "undefined" && "ontouchstart" in window;
  const showBubble = active && price !== null && date && (!isTouchDevice || isTouching);

  if (!showBubble) return null;

  return (
    <div
      className="rounded-md border border-white/25 px-2.5 py-1.5 text-xs text-text-muted pointer-events-none"
      style={{
        background: "linear-gradient(155deg, rgba(255,255,255,0.14), rgba(255,255,255,0.03) 40%, rgba(0,0,0,0.35))",
        backdropFilter: "blur(22px) saturate(160%)",
        WebkitBackdropFilter: "blur(22px) saturate(160%)",
        boxShadow: "0 10px 34px rgba(0,0,0,0.45), inset 0 1px 0 rgba(255,255,255,0.16), inset 0 0 0 1px rgba(255,255,255,0.04)",
      }}
    >
      {tooltipLabel(date, period)}
    </div>
  );
}

/* ─── Main PriceChart ────────────────────────────────────────────────────── */
export function PriceChart({
  symbol,
  currentPrice,
  currentChangePercent,
  previousClose,
  initialPeriod = "1D",
  heightClassName = "h-[320px]",
  priceIndent
}: {
  symbol: string;
  currentPrice: number;
  currentChangePercent: number;
  previousClose?: number;
  initialPeriod?: ChartPeriod;
  heightClassName?: string;
  priceIndent?: string;
}) {
  const [period, setPeriod]           = useState<ChartPeriod>(initialPeriod);
  const [chartKey, setChartKey]       = useState(0);
  const [data, setData]               = useState<CandlePoint[]>([]);
  const [isLoading, setIsLoading]     = useState(true);
  const [error, setError]             = useState<string | null>(null);
  const [reloadNonce, setReloadNonce] = useState(0);
  const [hoverPrice, setHoverPrice]   = useState<number | null>(null);
  const [hoverDate,  setHoverDate]    = useState<string | null>(null);
  const [priceVisible, setPriceVisible] = useState(true);
  const [activeMAs, setActiveMAs] = useState<Set<number>>(new Set());

  // Buttons currently rendered (includes ones mid-exit-animation) and which
  // of those are actively exiting — kept mounted a bit longer than
  // MA_AVAILABILITY[period] itself so the shrink-out animation can play
  // instead of the button just vanishing instantly.
  const [displayedMAWindows, setDisplayedMAWindows] = useState<number[]>(MA_AVAILABILITY[period] ?? []);
  const [exitingMAWindows, setExitingMAWindows] = useState<Set<number>>(new Set());

  // If the period changes to one that doesn't support a currently-active MA
  // (e.g. switching from 1M to 1W drops MA(25)), drop it rather than leave
  // it toggled on with nothing shown.
  useEffect(() => {
    const allowed = MA_AVAILABILITY[period] ?? [];
    setActiveMAs(prev => {
      const next = new Set([...prev].filter(w => allowed.includes(w)));
      return next.size === prev.size ? prev : next;
    });

    setDisplayedMAWindows(prev => {
      const removed = prev.filter(w => !allowed.includes(w));
      const added   = allowed.filter(w => !prev.includes(w));
      if (removed.length) {
        setExitingMAWindows(ex => new Set([...ex, ...removed]));
        setTimeout(() => {
          setExitingMAWindows(ex => {
            const n = new Set(ex);
            removed.forEach(w => n.delete(w));
            return n;
          });
          setDisplayedMAWindows(cur => cur.filter(w => !removed.includes(w)));
        }, 320);
      }
      if (!added.length && !removed.length) return prev;
      return [...prev, ...added];
    });
  }, [period]);
  const [proMode, setProMode]         = useState(() =>
    typeof window !== "undefined" ? localStorage.getItem("pro-mode") === "1" : false
  );

  // Keep proMode in sync across tabs and after settings toggle
  useEffect(() => {
    function sync() {
      setProMode(localStorage.getItem("pro-mode") === "1");
    }
    window.addEventListener("pro-mode-changed", sync);
    window.addEventListener("storage", sync);
    return () => {
      window.removeEventListener("pro-mode-changed", sync);
      window.removeEventListener("storage", sync);
    };
  }, []);

  /* Load candles */
  useEffect(() => {
    const controller = new AbortController();
    async function load() {
      setIsLoading(true);
      setError(null);
      setHoverPrice(null);
      setHoverDate(null);
      setPriceVisible(false);
      try {
        const res = await fetch(
          `/api/candles?symbol=${encodeURIComponent(symbol)}&period=${period}`,
          { signal: controller.signal }
        );
        const payload = (await res.json()) as { candles?: CandlePoint[]; error?: string };
        if (!res.ok) throw new Error(payload.error ?? "Unable to load chart data.");
        const candles = payload.candles ?? [];
        if (candles.length && !LONG_TERM_SET.has(period)) {
          const todayPrefix = new Date().toISOString().slice(0, 10);
          const last  = candles[candles.length - 1];
          if (!last.date.startsWith(todayPrefix)) {
            const liveRes   = await fetch(`/api/stocks?symbols=${encodeURIComponent(symbol)}`, { signal: controller.signal });
            const liveData  = (await liveRes.json()) as { stocks?: { price: number }[] };
            const livePrice = liveData.stocks?.[0]?.price;
            if (livePrice) candles.push({ date: new Date().toISOString(), time: Date.now() / 1000, close: livePrice });
          }
        }
        // For 1D: prepend yesterday's close as the first data point
        // Uses quote.pc (previousClose prop) — same technique as watchlist StockCard
        if (period === "1D" && previousClose && previousClose > 0 && candles.length > 0) {
          const prevPoint: CandlePoint = {
            date: "prev",
            time: candles[0].time - 1,
            close: previousClose,
          };
          setData([prevPoint, ...candles]);
        } else {
          setData(candles);
        }
        // Small delay so digits have settled before fading back in
        setTimeout(() => setPriceVisible(true), 40);

      } catch (err) {
        if (!controller.signal.aborted) {
          setData([]);
          setError(err instanceof Error ? err.message : "Unable to load chart data.");
        }
      } finally {
        if (!controller.signal.aborted) setIsLoading(false);
      }
    }
    load();
    return () => controller.abort();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [period, reloadNonce, symbol]);

  const hasData    = data.length > 1;
  const isLongTerm = LONG_TERM_SET.has(period);

  // Merge in MA fields for whichever windows are both available for this
  // period and currently toggled on. Only computed when needed.
  const chartData = useMemo(() => {
    const allowed = MA_AVAILABILITY[period] ?? [];
    if (!allowed.length) return data;
    // Compute every MA available for this period regardless of whether it's
    // currently toggled on — this array must stay referentially stable
    // across activeMAs changes, or Recharts treats the whole chart's data
    // as "changed" and replays every line's draw animation, not just the
    // one that was actually toggled.
    const mas = new Map(allowed.map(w => [w, computeMA(data, w)]));
    return data.map((d, i) => ({
      ...d,
      ma7:  mas.get(7)?.[i]  ?? undefined,
      ma25: mas.get(25)?.[i] ?? undefined,
      ma99: mas.get(99)?.[i] ?? undefined,
    }));
  }, [data, period]);

  /* Displayed price and % change — hover overrides live values */
  const displayPrice = hoverPrice ?? currentPrice;
  const startPrice   = hasData ? data[0].close : currentPrice;
  const endPrice     = hasData ? data[data.length - 1].close : currentPrice;
  // When not hovering: show pct change across the full visible period (data[0] → latest)
  // When hovering: show pct from period start to hovered point
  const displayPct   = hasData
    ? ((( hoverPrice ?? endPrice) - startPrice) / startPrice) * 100
    : currentChangePercent;

  const isPositive = useMemo(() => {
    if (!hasData) return (currentChangePercent ?? 0) >= 0;
    return (hoverPrice ?? data[data.length - 1].close) >= data[0].close;
  }, [data, hasData, hoverPrice, currentChangePercent]);

  const lineColor   = isPositive ? "#00c805" : "#ff3003";
  const pctColor    = displayPct >= 0 ? "text-positive" : "text-negative";
  const pctSign     = displayPct >= 0 ? "+" : "";

  /* Format strings for wheels */
  const priceStr = formatPrice(displayPrice);
  const pctStr   = `${pctSign}${displayPct.toFixed(2)}%`;

  // suppressRef: when true, CrosshairTooltip's onHover calls are ignored for one frame.
  const suppressRef = useRef(false);
  // isTouching: true only while a finger is actively on the chart
  const [isTouching, setIsTouching] = useState(false);
  // touchOverlay: the computed X% and Y% for the custom dot/crosshair overlay (touch only)
  const [touchOverlay, setTouchOverlay] = useState<{ xPct: number; yPct: number } | null>(null);
  // dotCY: active dot's Y pixel inside the SVG, used to draw the pro-mode horizontal crosshair
  const [dotCY, setDotCY] = useState<number | null>(null);

  const onHover = useCallback((price: number | null, date: string | null) => {
    if (suppressRef.current) return;
    setHoverPrice(price);
    setHoverDate(date);
  }, []);

  const clearHover = useCallback(() => {
    suppressRef.current = true;
    setIsTouching(false);
    setTouchOverlay(null);
    setHoverPrice(null);
    setHoverDate(null);
    requestAnimationFrame(() => requestAnimationFrame(() => { suppressRef.current = false; }));
  }, []);

  // dataRef always holds the latest data so touch handlers (attached once) can read it
  const dataRef = useRef<CandlePoint[]>([]);
  useEffect(() => { dataRef.current = data; }, [data]);

  // Scroll-lock + full custom touch tracking on document so finger can roam anywhere
  const chartRef = useRef<HTMLDivElement>(null);
  const blockScrollRef = useRef<((e: TouchEvent) => void) | null>(null);

  useEffect(() => {
    const el = chartRef.current;
    if (!el) return;

    // Given a clientX, find the closest data point and update hover + overlay state
    const updateFromClientX = (clientX: number) => {
      const pts = dataRef.current;
      if (!pts.length) return;
      const rect = el.getBoundingClientRect();
      const clampedX = Math.max(rect.left, Math.min(rect.right, clientX));
      const xPct = (clampedX - rect.left) / rect.width;
      const idx  = Math.round(xPct * (pts.length - 1));
      const pt   = pts[Math.max(0, Math.min(pts.length - 1, idx))];

      const prices = pts.map(p => p.close);
      const minP = Math.min(...prices);
      const maxP = Math.max(...prices);
      const yPct = maxP === minP ? 0.5 : 1 - (pt.close - minP) / (maxP - minP);

      suppressRef.current = true;
      setHoverPrice(pt.close);
      setHoverDate(pt.date);
      setTouchOverlay({ xPct, yPct });
      requestAnimationFrame(() => { suppressRef.current = false; });
    };

    const onTouchMove = (e: TouchEvent) => {
      updateFromClientX(e.touches[0].clientX);
    };

    const onTouchEnd = () => {
      // Remove the per-gesture listeners
      document.removeEventListener("touchmove", onTouchMove);
      document.removeEventListener("touchend", onTouchEnd);
      document.removeEventListener("touchcancel", onTouchEnd);
      if (blockScrollRef.current) {
        document.removeEventListener("touchmove", blockScrollRef.current);
        blockScrollRef.current = null;
      }
      clearHover();
    };

    const onTouchStart = (e: TouchEvent) => {
      setIsTouching(true);
      updateFromClientX(e.touches[0].clientX);

      // Attach move/end listeners only for this gesture — removed in onTouchEnd
      document.addEventListener("touchmove", onTouchMove, { passive: true });
      document.addEventListener("touchend", onTouchEnd);
      document.addEventListener("touchcancel", onTouchEnd);

      // Block scroll for entire gesture
      const block = (ev: TouchEvent) => ev.preventDefault();
      blockScrollRef.current = block;
      document.addEventListener("touchmove", block, { passive: false });
    };

    el.addEventListener("touchstart", onTouchStart, { passive: true });

    return () => {
      el.removeEventListener("touchstart", onTouchStart);
      // Clean up in case component unmounts mid-gesture
      document.removeEventListener("touchmove", onTouchMove);
      document.removeEventListener("touchend", onTouchEnd);
      document.removeEventListener("touchcancel", onTouchEnd);
      if (blockScrollRef.current) {
        document.removeEventListener("touchmove", blockScrollRef.current);
        blockScrollRef.current = null;
      }
    };
  }, [clearHover]);

  function PeriodButton({ option }: { option: ChartPeriod }) {
    const active = period === option;
    return (
      <button
        type="button"
        onClick={() => { if (active) return; setPeriod(option); setChartKey(k => k + 1); }}
        className={cn(
          "rounded-lg px-2.5 py-1.5 text-xs font-semibold transition sm:px-3 sm:py-2 sm:text-sm",
          active ? "bg-positive text-black" : "text-positive hover:text-positive/80"
        )}
      >
        {option}
      </button>
    );
  }

  return (
    <div>
      {/* ── Price header — indented to align with name when priceIndent is set ── */}
      <div className="mb-6 price-block-fade" style={{ ...(priceIndent ? { paddingLeft: priceIndent } : {}), opacity: priceVisible ? 1 : 0, transition: "opacity 0.18s ease", WebkitTransition: "opacity 0.18s ease" }}>
        <div className="flex items-end gap-3">
          <WheelPrice value={priceStr} size="lg" />
          <WheelPrice value={pctStr} size="sm" colorClass={pctColor} />
        </div>
        <p className="mt-2 text-sm text-text-muted">
          {hoverDate ? tooltipLabel(hoverDate, period) : "Current price"}
        </p>
      </div>

      {/* ── Chart area ────────────────────────────────────────────────── */}
      <div
        ref={chartRef}
        className={cn(heightClassName, "relative")}
        onMouseLeave={() => { setDotCY(null); clearHover(); }}
      >
        {isLoading ? (
          <div className="flex h-full flex-col items-center justify-center gap-5">
            <style>{`
              @keyframes chart-candle-breathe { 0%,100%{transform:scaleY(0.6)} 50%{transform:scaleY(1.4)} }
              @keyframes chart-wick-breathe   { 0%,100%{opacity:0.25;transform:scaleY(0.7)} 50%{opacity:0.9;transform:scaleY(1.3)} }
              .cc-1{animation:chart-candle-breathe 1.8s ease-in-out infinite -1.8s;transform-origin:bottom}
              .cc-2{animation:chart-candle-breathe 1.8s ease-in-out infinite -1.32s;transform-origin:bottom}
              .cc-3{animation:chart-candle-breathe 1.8s ease-in-out infinite -0.84s;transform-origin:bottom}
              .cw-1{animation:chart-wick-breathe 1.8s ease-in-out infinite -1.8s;transform-origin:bottom}
              .cw-2{animation:chart-wick-breathe 1.8s ease-in-out infinite -1.32s;transform-origin:bottom}
              .cw-3{animation:chart-wick-breathe 1.8s ease-in-out infinite -0.84s;transform-origin:bottom}
            `}</style>
            <div className="flex items-end gap-[5px] h-10">
              <div className="flex flex-col items-center gap-[2px]">
                <div className="cw-1 w-[2px] h-1.5 rounded-full bg-positive/50" />
                <div className="cc-1 w-3.5 h-4 rounded-sm bg-positive/50" />
              </div>
              <div className="flex flex-col items-center gap-[2px]">
                <div className="cw-2 w-[2px] h-2 rounded-full bg-positive/70" />
                <div className="cc-2 w-3.5 h-6 rounded-sm bg-positive/70" />
              </div>
              <div className="flex flex-col items-center gap-[2px]">
                <div className="cw-3 w-[2px] h-2.5 rounded-full bg-positive" />
                <div className="cc-3 w-3.5 h-8 rounded-sm bg-positive" />
              </div>
            </div>
            <span className="text-sm text-text-muted">Loading price history</span>
          </div>
        ) : error ? (
          <div className="flex h-full flex-col items-center justify-center rounded-md border border-dashed border-negative/30 bg-negative/5 px-4 text-center">
            <p className="text-sm font-medium text-text-primary">Chart unavailable</p>
            <p className="mt-2 max-w-md text-sm leading-6 text-text-muted">{error}</p>
            <button type="button" onClick={() => setReloadNonce((n) => n + 1)}
              className="mt-4 inline-flex items-center gap-2 rounded-md border border-border-subtle px-3 py-2 text-sm text-text-primary transition hover:bg-panel-muted">
              <RotateCcw className="h-4 w-4" aria-hidden /> Retry
            </button>
          </div>
        ) : hasData ? (
          <>
          <style>{`
            @keyframes chart-reveal {
              from { clip-path: inset(0 100% 0 0); }
              to   { clip-path: inset(0 0% 0 0); }
            }
          `}</style>
          <div
            key={chartKey}
            style={{ animation: "chart-reveal 0.7s cubic-bezier(0.4,0,0.2,1) both", width: "100%", height: "100%" }}
          >
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart
              data={chartData}
              margin={{ left: 0, right: 0, top: 8, bottom: 0 }}
            >
              {/* No Y axis, no grid lines */}
              <CartesianGrid stroke="transparent" />
              <YAxis domain={["dataMin", "dataMax"]} hide />
              <XAxis dataKey="date" hide />

              <Tooltip
                cursor={(() => {
                  const isTouchDevice = typeof window !== "undefined" && "ontouchstart" in window;
                  if (isTouchDevice) return false;
                  if (proMode) {
                    // Vertical line only — drawn via SVG props (what Recharts cursor accepts).
                    // The horizontal line is drawn as a separate overlay div using dotCY.
                    return { stroke: "rgba(128,128,128,0.5)", strokeWidth: 1 };
                  }
                  return { stroke: "rgba(128,128,128,0.4)", strokeWidth: 1 };
                })()}
                content={(() => {
                  const isTouchDevice = typeof window !== "undefined" && "ontouchstart" in window;
                  if (isTouchDevice) return <></>;
                  return <CrosshairTooltip period={period} onHover={onHover} isTouching={isTouching} />;
                })()}
              />

              <Area
                type="monotone"
                dataKey="close"
                stroke={lineColor}
                fill="none"
                strokeWidth={isLongTerm ? 2 : 2.5}
                strokeLinecap="round"
                strokeLinejoin="round"
                dot={false}
                activeDot={(props: Record<string, unknown>) => {
                  const { cx, cy } = props as { cx?: number; cy?: number };
                  const isTouchDevice = typeof window !== "undefined" && "ontouchstart" in window;
                  if (isTouchDevice) return <g key="no-dot" />;
                  if (cx == null || cy == null) return <g key="no-dot2" />;
                  // Update horizontal crosshair position for pro mode
                  if (proMode && cy !== dotCY) setDotCY(cy);
                  return <circle key="dot" cx={cx} cy={cy} r={5} fill={lineColor} stroke="#000" strokeWidth={2} />;
                }}
                isAnimationActive={false}
              />

              {/* ── Moving average overlays ── */}
              {(MA_AVAILABILITY[period] ?? []).includes(7) && activeMAs.has(7) && (
                <Line key="ma7" type="monotone" dataKey="ma7" stroke={MA_COLORS[7]} strokeWidth={3}
                  dot={false} activeDot={false} isAnimationActive animationDuration={700} animationEasing="ease-out" connectNulls />
              )}
              {(MA_AVAILABILITY[period] ?? []).includes(25) && activeMAs.has(25) && (
                <Line key="ma25" type="monotone" dataKey="ma25" stroke={MA_COLORS[25]} strokeWidth={3}
                  dot={false} activeDot={false} isAnimationActive animationDuration={700} animationEasing="ease-out" connectNulls />
              )}
              {(MA_AVAILABILITY[period] ?? []).includes(99) && activeMAs.has(99) && (
                <Line key="ma99" type="monotone" dataKey="ma99" stroke={MA_COLORS[99]} strokeWidth={3}
                  dot={false} activeDot={false} isAnimationActive animationDuration={700} animationEasing="ease-out" connectNulls />
              )}
            </ComposedChart>
          </ResponsiveContainer>
          </div>

          {/* ── Pro mode desktop horizontal crosshair — follows the active dot ── */}
          {proMode && !isTouching && dotCY !== null && (() => {
            // dotCY is already an absolute pixel position within the chart SVG —
            // Recharts bakes margin.top into cx/cy for activeDot, so no extra
            // offset is needed here (adding one pushes the line below the dot).
            const rect = chartRef.current?.getBoundingClientRect();
            const containerH = rect?.height ?? 260;
            const topPct = (dotCY / containerH) * 100;
            return (
              <div
                className="absolute inset-x-0 pointer-events-none"
                aria-hidden
                style={{ top: `${topPct}%`, height: 1, background: "rgba(128,128,128,0.5)" }}
              />
            );
          })()}

          {/* ── Custom touch overlay: dot + crosshair line + date bubble ── */}
          {isTouching && touchOverlay && (() => {
            const xPct = touchOverlay.xPct * 100;
            // Recharts renders the data area with margin top:8 bottom:0.
            // Convert yPct (0=top of data area) into % of the full container height.
            const chartMarginTopPx = 8;
            const rect = chartRef.current?.getBoundingClientRect();
            const containerH = rect?.height ?? 260;
            const dataAreaH = containerH - chartMarginTopPx;
            const dotTopPx = chartMarginTopPx + touchOverlay.yPct * dataAreaH;
            const dotTopPct = (dotTopPx / containerH) * 100;
            return (
              <div className="absolute inset-0 pointer-events-none" aria-hidden>
                {/* Vertical crosshair line */}
                <div
                  data-crosshair-v=""
                  className="absolute top-0 bottom-0 w-px bg-white/20"
                  style={{ left: `${xPct}%` }}
                />
                {/* Horizontal crosshair line — Pro Mode only */}
                {proMode && (
                  <div
                    data-crosshair-h=""
                    className="absolute left-0 right-0 h-px"
                    style={{ top: `${dotTopPct}%`, background: "rgba(255,255,255,0.18)" }}
                  />
                )}
                {/* Dot */}
                <div
                  className="absolute w-3 h-3 rounded-full border-2 border-black"
                  style={{
                    left: `${xPct}%`,
                    top: `${dotTopPct}%`,
                    transform: "translate(-50%, -50%)",
                    background: lineColor,
                  }}
                />
                {/* Date bubble — flip to left side if too close to right edge */}
                {hoverDate && (
                  <div
                    className="absolute top-2 rounded-md border border-white/25 px-2.5 py-1.5 text-xs text-text-muted"
                    style={{
                      left: xPct > 65 ? undefined : `calc(${xPct}% + 10px)`,
                      right: xPct > 65 ? `calc(${100 - xPct}% + 10px)` : undefined,
                      background: "linear-gradient(155deg, rgba(255,255,255,0.14), rgba(255,255,255,0.03) 40%, rgba(0,0,0,0.35))",
                      backdropFilter: "blur(22px) saturate(160%)",
                      WebkitBackdropFilter: "blur(22px) saturate(160%)",
                      boxShadow: "0 10px 34px rgba(0,0,0,0.45), inset 0 1px 0 rgba(255,255,255,0.16), inset 0 0 0 1px rgba(255,255,255,0.04)",
                    }}
                  >
                    {tooltipLabel(hoverDate, period)}
                  </div>
                )}
              </div>
            );
          })()}
          </>
        ) : (
          <div className="flex h-full items-center justify-center rounded-md border border-dashed border-border-subtle px-4 text-center text-sm text-text-muted">
            Price history is not available for this symbol and period.
          </div>
        )}
      </div>

      {/* ── Period selector — centred below chart ────────────────────── */}
      <div className="mt-4 flex justify-center">
        <div className="flex flex-col gap-1">
          <div className="flex items-center justify-center">
            {SHORT_PERIODS.map((o) => <PeriodButton key={o} option={o} />)}
          </div>
          <div className="mx-1 h-px bg-border-subtle" />
          <div className="flex items-center justify-center">
            {LONG_PERIODS.map((o) => <PeriodButton key={o} option={o} />)}
          </div>
        </div>
      </div>

      {/* ── Moving average toggles — only shown when at least one MA makes
          sense for the currently selected period ── */}
      {displayedMAWindows.length > 0 && (
        <>
        <style>{`
          @keyframes ma-btn-pop {
            from { transform: scale(0); opacity: 0; }
            to   { transform: scale(1); opacity: 1; }
          }
          @keyframes ma-btn-pop-out {
            from { transform: scale(1); opacity: 1; }
            to   { transform: scale(0); opacity: 0; }
          }
        `}</style>
        <div className="mt-3 flex items-center justify-center gap-2">
          {displayedMAWindows.map((window) => {
            const active   = activeMAs.has(window);
            const exiting  = exitingMAWindows.has(window);
            const color    = MA_COLORS[window];
            return (
              <button
                key={window}
                type="button"
                disabled={exiting}
                onClick={() => {
                  setActiveMAs(prev => {
                    const next = new Set(prev);
                    if (next.has(window)) next.delete(window); else next.add(window);
                    return next;
                  });
                }}
                className="flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-semibold transition border"
                style={{
                  ...(active
                    ? { borderColor: color, backgroundColor: `${color}22`, color }
                    : { borderColor: "var(--color-border-subtle)", color: "var(--color-text-muted)" }),
                  animation: exiting
                    ? "ma-btn-pop-out 0.32s cubic-bezier(0.4, 0, 1, 1) both"
                    : "ma-btn-pop 0.4s cubic-bezier(0.34, 1.56, 0.64, 1) both",
                }}
              >
                <span className="h-2 w-2 rounded-full shrink-0" style={{ backgroundColor: color }} />
                MA({window})
              </button>
            );
          })}
        </div>
        </>
      )}
    </div>
  );
}

/* ─── Helpers ────────────────────────────────────────────────────────────── */
function formatPrice(price: number): string {
  // Always 2 decimal places, with $ prefix and thousands comma
  const formatted = price.toLocaleString("en-US", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
  return `$${formatted}`;
}
