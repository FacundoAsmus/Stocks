"use client";

import { useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import type { RefObject } from "react";
import { createPortal } from "react-dom";
import { CalendarDays, ChevronLeft } from "lucide-react";

import { formatCompact, formatCurrency } from "@/lib/format";
import { WheelPrice } from "@/components/PriceChart";
import {
  todayStr
} from "@/lib/earnings";
import type { EarningsEvent } from "@/types/stock";

export const WEEKDAYS = ["S", "M", "T", "W", "T", "F", "S"];

type QuarterMetric = "revenue" | "eps";

function metricColor(percentage: number) {
  const stops: [number, [number, number, number]][] = [[0, [220, 38, 38]], [25, [249, 115, 22]], [50, [250, 204, 21]], [75, [163, 230, 53]], [100, [52, 211, 153]]];
  const upperIndex = stops.findIndex(([stop]) => percentage <= stop);
  const upper = stops[Math.max(1, upperIndex === -1 ? stops.length - 1 : upperIndex)];
  const lower = stops[stops.indexOf(upper) - 1];
  const progress = (percentage - lower[0]) / (upper[0] - lower[0] || 1);
  return `rgb(${Math.round(lower[1][0] + (upper[1][0] - lower[1][0]) * progress)}, ${Math.round(lower[1][1] + (upper[1][1] - lower[1][1]) * progress)}, ${Math.round(lower[1][2] + (upper[1][2] - lower[1][2]) * progress)})`;
}

// The phone counterpart of the desktop quarter charts. It keeps the same
// bars, animated value wheel, estimates, and hover interaction, but is sized
// for the calendar detail sheet.
function MobileQuarterMetricChart({ metric, title, events, selectedDate }: { metric: QuarterMetric; title: string; events: EarningsEvent[]; selectedDate: string }) {
  const [animated, setAnimated] = useState(false);
  const [hoveredValue, setHoveredValue] = useState<number | null>(null);
  useEffect(() => { const frame = requestAnimationFrame(() => setAnimated(true)); return () => cancelAnimationFrame(frame); }, []);
  const points = events.map(event => {
    const actual = metric === "revenue" ? event.revenueActual : event.epsActual;
    const estimate = metric === "revenue" ? event.revenueEstimate : event.epsEstimate;
    return { event, value: actual ?? estimate, estimate: event.date >= todayStr() };
  });
  const values = points.map(point => point.value).filter((value): value is number => value !== null);
  const selectedValue = points.find(point => point.event.date === selectedDate)?.value ?? [...points].reverse().find(point => point.value !== null)?.value ?? null;
  const displayedValue = hoveredValue ?? selectedValue;
  const maximum = Math.max(...values.map(value => Math.abs(value)), 1);
  const hasNegative = values.some(value => value < 0);
  const baseline = hasNegative ? "45%" : "14%";
  return (
    <section>
      <p className="mb-3 text-sm font-semibold uppercase tracking-[0.18em] text-accent">{title}</p>
      <div className="mb-4 text-text-primary"><WheelPrice value={displayedValue === null ? "N/A" : metric === "revenue" ? `$${formatCompact(displayedValue)}` : formatCurrency(displayedValue)} size="xs" /></div>
      <div className="relative h-48 border-y border-border-subtle">
        <div className="absolute inset-x-0 border-t border-border-subtle" style={hasNegative ? { top: baseline } : { bottom: baseline }} aria-hidden />
        <div className="grid h-full grid-flow-col auto-cols-fr">
          {points.map(({ event, value, estimate }) => {
            const percentage = value === null ? 0 : Math.abs(value) / maximum * 100;
            const height = value === null ? 0 : Math.max(percentage * (hasNegative ? 0.4 : 0.78), 3);
            const color = metricColor(value === null ? 50 : value < 0 ? 50 - Math.abs(value) / maximum * 50 : 50 + value / maximum * 50);
            const selected = event.date === selectedDate;
            return <div key={event.date} className="relative border-l border-border-subtle first:border-l-0" onMouseEnter={() => { if (value !== null) setHoveredValue(value); }} onMouseLeave={() => setHoveredValue(null)}>
              {value !== null && <div className={`absolute left-1/2 w-1/4 max-w-5 -translate-x-1/2 rounded-sm ${estimate ? selected ? "border-2 border-accent bg-accent/15" : "border border-accent/70 bg-accent/15 opacity-45" : selected ? "border-2 border-accent" : ""}`} style={{ ...(value < 0 ? { top: baseline } : { bottom: hasNegative ? "55%" : baseline }), height: animated ? `${height}%` : "0%", ...(!estimate ? { backgroundColor: color, boxShadow: `0 0 10px ${color.replace("rgb(", "rgba(").replace(")", ", 0.42)")}` } : {}), transition: "height 1.657s cubic-bezier(0.22, 1, 0.36, 1)" }} />}
              <span className="absolute bottom-1 left-1/2 -translate-x-1/2 whitespace-nowrap text-[10px] font-semibold text-accent">Q{event.quarter}</span>
            </div>;
          })}
        </div>
      </div>
    </section>
  );
}

export function EarningsDetailCard({
  event, earnings, onBack
}: { event: EarningsEvent; earnings: EarningsEvent[]; onBack: () => void }) {
  const dateLabel = new Intl.DateTimeFormat("en-US", { month: "long", day: "numeric", year: "numeric" })
    .format(new Date(`${event.date}T00:00:00`));
  const sorted = [...earnings].sort((a, b) => a.date.localeCompare(b.date));
  const selectedIndex = Math.max(0, sorted.findIndex(item => item.date === event.date));
  const chartEvents = sorted.slice(Math.max(0, selectedIndex - 4), selectedIndex + 5);

  return (
    <div
      className="earnings-detail-glass w-full rounded-2xl p-5 shadow-2xl"
      style={{
        maxWidth: "min(380px, calc(100vw - 2rem))",
        animation: "detailFadeIn 0.18s ease both",
        backdropFilter: "blur(22px) saturate(160%)",
        WebkitBackdropFilter: "blur(22px) saturate(160%)",
        boxShadow: "0 10px 34px rgba(0,0,0,0.45), inset 0 1px 0 rgba(255,255,255,0.14), inset 0 0 0 1px rgba(255,255,255,0.05)"
      }}
      onClick={e => e.stopPropagation()}
    >
      <div className="flex items-center gap-3 mb-5">
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 bg-accent text-black text-sm font-semibold px-3 py-1.5 rounded-lg shrink-0"
        >
          <ChevronLeft className="h-4 w-4" />
          Back
        </button>
        <div>
          <p className="text-xs font-semibold uppercase tracking-widest text-accent">Q{event.quarter} {event.year}</p>
          <p className="text-sm text-text-muted">{dateLabel}</p>
        </div>
      </div>

      <div className="space-y-7">
        <MobileQuarterMetricChart title="Earnings (Revenue)" metric="revenue" events={chartEvents} selectedDate={event.date} />
        <MobileQuarterMetricChart title="EPS" metric="eps" events={chartEvents} selectedDate={event.date} />
      </div>
    </div>
  );
}

// ─── One month's grid ───────────────────────────────────────────────────────
function MonthGrid({
  monthDate, eventsByDate, onSelect, today, isCurrent, monthRef
}: {
  monthDate: Date;
  eventsByDate: Map<string, EarningsEvent>;
  onSelect: (event: EarningsEvent) => void;
  today: string;
  isCurrent: boolean;
  monthRef?: (el: HTMLDivElement | null) => void;
}) {
  const year  = monthDate.getFullYear();
  const month = monthDate.getMonth();
  const firstWeekday = new Date(year, month, 1).getDay();
  const daysInMonth  = new Date(year, month + 1, 0).getDate();
  const monthLabel = new Intl.DateTimeFormat("en-US", { month: "long", year: "numeric" }).format(monthDate);

  const cells: (number | null)[] = [
    ...Array(firstWeekday).fill(null),
    ...Array.from({ length: daysInMonth }, (_, i) => i + 1)
  ];

  return (
    <div className="mb-6" ref={monthRef} data-current-month={isCurrent || undefined}>
      <p className="mb-2 text-center text-sm font-semibold uppercase tracking-widest text-accent">{monthLabel}</p>
      <div className="grid grid-cols-7 gap-y-1.5">
        {cells.map((day, i) => {
          if (day === null) return <div key={`blank-${i}`} />;
          const dateStr = `${year}-${String(month + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
          const event = eventsByDate.get(dateStr);
          const isToday = dateStr === today;
          // Past dates fade to grey, today stays green, and anything still
          // to come reads as solid primary text instead of muted grey.
          const isPast = dateStr < today;
          return (
            <div key={dateStr} className="flex items-center justify-center py-0.5">
              {event ? (
                <button
                  onClick={() => onSelect(event)}
                  className="flex h-8 w-8 items-center justify-center rounded-full bg-accent text-sm font-bold text-black transition active:scale-90"
                >
                  {day}
                </button>
              ) : (
                <span className={`h-8 w-8 flex items-center justify-center text-sm ${
                  isToday ? "font-bold text-accent" : isPast ? "text-text-muted" : "text-text-primary"
                }`}>
                  {day}
                </span>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ─── Trigger button + calendar overlay + detail popup ──────────────────────
export function EarningsCalendarButton({
  earnings,
  containerRef
}: {
  earnings: EarningsEvent[];
  /** When provided, the calendar sheet is confined to this element's bounds
   *  (e.g. the right-hand 3/4 column of the watchlist split view) instead of
   *  covering the full viewport. The element must have `position: relative`
   *  (or similar) so absolutely-positioned children resolve against it. */
  containerRef?: RefObject<HTMLElement | null>;
}) {
  const [open, setOpen]         = useState(false);
  const [closing, setClosing]   = useState(false);
  const [selected, setSelected] = useState<EarningsEvent | null>(null);
  const [origin, setOrigin]     = useState({ x: 0, y: 0 });

  const scrollRef      = useRef<HTMLDivElement>(null);
  const currentMonthRef = useRef<HTMLDivElement | null>(null);

  const today = todayStr();

  // Lock the stock page's scroll while the calendar is open — only the
  // calendar's own list should move.
  useLayoutEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => { document.body.style.overflow = prev; };
  }, [open]);

  // Center the current month in view the moment the calendar opens.
  useLayoutEffect(() => {
    if (!open || closing) return;
    const container = scrollRef.current;
    const target = currentMonthRef.current;
    if (container && target) {
      container.scrollTop = target.offsetTop - (container.clientHeight / 2) + (target.clientHeight / 2);
    }
  }, [open, closing]);

  const eventsByDate = useMemo(() => {
    const m = new Map<string, EarningsEvent>();
    earnings.forEach(e => m.set(e.date, e));
    return m;
  }, [earnings]);

  // 12 months back from this month, through the furthest known scheduled
  // report (capped ~6 months out so we never render an unbounded tail).
  const { months, now } = useMemo(() => {
    const now = new Date();
    const start = new Date(now.getFullYear(), now.getMonth() - 11, 1);
    let end = new Date(now.getFullYear(), now.getMonth(), 1);
    const maxEnd = new Date(now.getFullYear(), now.getMonth() + 6, 1);

    earnings.forEach(e => {
      const d = new Date(`${e.date}T00:00:00`);
      const monthStart = new Date(d.getFullYear(), d.getMonth(), 1);
      if (monthStart > end && monthStart <= maxEnd) end = monthStart;
    });

    const list: Date[] = [];
    const cursor = new Date(start);
    while (cursor <= end) {
      list.push(new Date(cursor));
      cursor.setMonth(cursor.getMonth() + 1);
    }
    return { months: list, now };
  }, [earnings]);

  function openCalendar(e: React.MouseEvent<HTMLButtonElement>) {
    const rect = e.currentTarget.getBoundingClientRect();
    setOrigin({ x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 });
    setClosing(false);
    setOpen(true);
  }

  function closeCalendar() {
    setClosing(true);
    setTimeout(() => { setOpen(false); setClosing(false); }, 300);
  }

  // Sheet is anchored to the bottom of its box at 88% tall — express the
  // button's tap point as a transform-origin relative to the sheet's own
  // box, so the open animation visibly grows out from the button. When
  // constrained to a container, "its box" is that container; otherwise
  // it's the viewport.
  const boxHeight = containerRef?.current?.clientHeight
    ?? (typeof window !== "undefined" ? window.innerHeight : 0);
  const sheetTop = boxHeight * 0.12;
  const transformOrigin = `${origin.x}px ${origin.y - sheetTop}px`;
  const portalTarget = containerRef?.current ?? (typeof document !== "undefined" ? document.body : null);

  return (
    <>
      <button
        type="button"
        onClick={openCalendar}
        aria-label="Earnings calendar"
        className="flex h-7 w-7 items-center justify-center text-accent active:opacity-60"
      >
        <CalendarDays className="h-[18px] w-[18px]" />
      </button>

      {open && portalTarget && createPortal(
        <div
          className={containerRef ? "absolute inset-0 z-[9999] flex items-end justify-center" : "fixed inset-0 z-[9999] flex items-end justify-center"}
          style={{ background: "rgba(0,0,0,0.7)", backdropFilter: "blur(6px)", WebkitBackdropFilter: "blur(6px)" }}
        >
          <div
            className="w-full rounded-t-2xl border-t border-border-subtle flex flex-col bg-black"
            style={{
              height: containerRef ? "88%" : "88vh",
              transformOrigin,
              animation: closing
                ? "calendarSink 0.3s cubic-bezier(0.4,0,1,1) forwards"
                : "calendarRise 0.32s cubic-bezier(0.22,1,0.36,1) both"
            }}
          >
            <div className="flex items-center gap-3 px-4 pt-4 pb-3 shrink-0">
              <button
                onClick={closeCalendar}
                className="flex items-center gap-1.5 rounded-lg bg-accent px-3 py-1.5 text-sm font-semibold text-black"
              >
                <ChevronLeft className="h-4 w-4" />
                Back
              </button>
              <p className="text-sm font-semibold text-accent">Earnings Calendar</p>
            </div>

            <div className="grid grid-cols-7 px-4 pb-2 shrink-0">
              {WEEKDAYS.map((d, i) => (
                <p key={i} className="text-center text-xs font-semibold uppercase tracking-wider text-text-muted">{d}</p>
              ))}
            </div>

            <div ref={scrollRef} className="flex-1 overflow-y-auto px-4 pb-8 overscroll-contain">
              {months.map(monthDate => {
                const isCurrent = monthDate.getFullYear() === now.getFullYear() && monthDate.getMonth() === now.getMonth();
                return (
                  <MonthGrid
                    key={`${monthDate.getFullYear()}-${monthDate.getMonth()}`}
                    monthDate={monthDate}
                    eventsByDate={eventsByDate}
                    onSelect={setSelected}
                    today={today}
                    isCurrent={isCurrent}
                    monthRef={isCurrent ? (el => { currentMonthRef.current = el; }) : undefined}
                  />
                );
              })}
            </div>
          </div>
        </div>,
        portalTarget
      )}

      {selected && portalTarget && createPortal(
        <div
          className={containerRef ? "absolute inset-0 z-[10000] flex items-center justify-center p-4" : "fixed inset-0 z-[10000] flex items-center justify-center p-4"}
          style={{ background: "rgba(0,0,0,0.2)", backdropFilter: "blur(3px)", WebkitBackdropFilter: "blur(3px)" }}
          onClick={(e) => { if (e.target === e.currentTarget) setSelected(null); }}
        >
          <EarningsDetailCard event={selected} earnings={earnings} onBack={() => setSelected(null)} />
        </div>,
        portalTarget
      )}

      <style>{`
        @keyframes calendarRise {
          from { transform: scale(0.08); opacity: 0; }
          to   { transform: scale(1);    opacity: 1; }
        }
        @keyframes calendarSink {
          from { transform: scale(1);    opacity: 1; }
          to   { transform: scale(0.08); opacity: 0; }
        }
        @keyframes detailFadeIn {
          from { opacity: 0; transform: scale(0.96) translateY(6px); }
          to   { opacity: 1; transform: scale(1)    translateY(0);   }
        }
        .earnings-detail-glass {
          background: linear-gradient(155deg, rgba(255,255,255,0.10), rgba(255,255,255,0.02) 40%, rgba(0,0,0,0.35));
        }
        html.light-mode .earnings-detail-glass {
          background: linear-gradient(155deg, rgba(255,255,255,0.72), rgba(255,255,255,0.58) 40%, rgba(255,255,255,0.42));
        }
        html.light-mode .earnings-detail-glass,
        html.light-mode .earnings-detail-glass .text-text-primary,
        html.light-mode .earnings-detail-glass .text-text-muted {
          color: #000;
        }
      `}</style>
    </>
  );
}
