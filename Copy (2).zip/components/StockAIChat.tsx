"use client";

import { useEffect, useRef, useState, useCallback } from "react";
import { Send, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";
import { AIStarLoader } from "@/components/AIStarLoader";
import { AIFormattedText } from "@/components/AIFormattedText";
import type { StockDetail } from "@/types/stock";
import { OptionalSvgIcon } from "@/components/OptionalSvgIcon";

// ─── Types ────────────────────────────────────────────────────────────────
interface Message {
  role: "user" | "model";
  text: string;
}

interface StockAIChatProps {
  stock: StockDetail;
  currentPrice: number;
  sentiment: { score: number; drivers: string[] };
  metrics: Record<string, number | string | null> | undefined;
}

// ─── Build system context from stock data ─────────────────────────────────
function buildStockContext(
  stock: StockDetail,
  currentPrice: number,
  sentiment: { score: number; drivers: string[] },
  metrics: Record<string, number | string | null> | undefined,
): string {
  const q = stock.quote;

  const metricsStr = metrics
    ? Object.entries(metrics)
        .filter(([, v]) => v !== null && v !== undefined)
        .slice(0, 16)
        .map(([k, v]) => `${k}: ${v}`)
        .join(", ")
    : "N/A";

  const newsStr = stock.news
    .slice(0, 6)
    .map(n => `- ${n.headline} (${n.source}, ${n.url})`)
    .join("\n");

  const analystStr = stock.priceTarget
    ? `Analyst price target: mean $${stock.priceTarget.targetMean?.toFixed(2) ?? "N/A"}, high $${stock.priceTarget.targetHigh?.toFixed(2) ?? "N/A"}, low $${stock.priceTarget.targetLow?.toFixed(2) ?? "N/A"}`
    : "No analyst price target data.";

  const recStr = stock.recommendations?.length
    ? `Recommendations (latest): buy=${stock.recommendations[0].buy}, hold=${stock.recommendations[0].hold}, sell=${stock.recommendations[0].sell}, strongBuy=${stock.recommendations[0].strongBuy}, strongSell=${stock.recommendations[0].strongSell}`
    : "No recommendation data.";

  return `Your name is Warrent. You are an AI financial analyst assistant embedded in a stock research app. If asked your name, say Warrent. You are viewing the individual stock page for ${stock.profile.name ?? stock.symbol} (${stock.symbol}).

Be concise, professional, and non-personal. Do not give personal investment advice. Use the data below to answer questions accurately. Be intuitive and clear: answer directly first, explain unfamiliar financial terms in plain language, and connect figures to what they mean. Use short, complete sentences and avoid unexplained jargon or unnecessary detail.

ANSWER FORMAT: For substantive answers, start with a short Markdown title using #, then use brief ## section headings and concise - bullet points to organize the key takeaways. Lead with the direct answer. Keep the structure compact and use only sections that add clarity. For greetings or simple clarifications, answer naturally without forcing sections.
COLOR TAGS: Wrap the current stock's company name in [[company]]...[[/company]] (bold). Wrap other companies in [[peer]]...[[/peer]] (comparison orange). Wrap people's names in [[person]]...[[/person]] (yellow). Do not highlight product names, technology names, or AI. Use green/red tags only around numeric stock-price changes: [[+]]...[[/+]] for an explicitly upward move and [[-]]...[[/-]] for an explicitly downward move. Include only the number, %, currency sign, and/or + or - sign inside those tags, never surrounding words. Don't color unrelated financial values. In comparison questions, the primary stock is [[company]] and the other stock is [[peer]]. Keep tags balanced and don't nest them.
PRICE CHARTS: Use the stock chart widget frequently when discussing price changes, performance, volatility, trends, or price-related events. Choose the relevant period and put [[graph:price:PERIOD]] on its own line. When supported graph data identifies a relevant event, add a [[mark:...]] annotation with the exact date and price so it appears on the chart. In comparison mode, use [[graph:comparePrice:PERIOD]]. Never invent dates, prices, or events; omit the chart if relevant data isn't available.

STOCK DATA:
- Company: ${stock.profile.name ?? stock.symbol} (${stock.symbol})
- Industry: ${stock.profile.finnhubIndustry ?? "N/A"}
- Exchange: ${stock.profile.exchange ?? "N/A"}
- Current Price: $${currentPrice.toFixed(2)}
- Day Change: ${q.d?.toFixed(2) ?? "N/A"} (${q.dp?.toFixed(2) ?? "N/A"}%)
- Day High: $${q.h?.toFixed(2) ?? "N/A"}, Day Low: $${q.l?.toFixed(2) ?? "N/A"}
- Previous Close: $${q.pc?.toFixed(2) ?? "N/A"}
- Market Cap: $${stock.profile.marketCapitalization ? (stock.profile.marketCapitalization / 1000).toFixed(2) + "B" : "N/A"}
- Sentiment Score: ${sentiment.score}/100
- Key Metrics: ${metricsStr}
- ${analystStr}
- ${recStr}

RECENT NEWS:
${newsStr}

Answer questions about this stock using the above data. Always write complete sentences — never stop mid-sentence. Keep answers concise (under 150 words) unless the user asks for more detail.`;
}

// ─── Gemini API call (proxied through /api/ai so the key stays server-side) ─
async function callGemini(
  systemPrompt: string,
  history: Message[],
  userText: string,
  signal: AbortSignal,
): Promise<string> {
  const contents = [
    { role: "user",  parts: [{ text: systemPrompt }] },
    { role: "model", parts: [{ text: "Understood. I have the stock data and am ready to answer questions." }] },
    ...history.map(m => ({ role: m.role, parts: [{ text: m.text }] })),
    { role: "user", parts: [{ text: userText }] },
  ];

  const res = await fetch("/api/ai", {
    method: "POST",
    signal,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents,
      generationConfig: { temperature: 0.4, maxOutputTokens: 1024 },
    }),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({})) as { error?: string };
    throw new Error(err.error ?? String(res.status));
  }

  const data = await res.json() as {
    candidates?: Array<{ content?: { parts?: Array<{ text?: string }> } }>;
  };

  return data.candidates?.[0]?.content?.parts
    ?.map(p => p.text ?? "")
    .join("")
    .trim() ?? "No response received.";
}

// ─── Chat panel ───────────────────────────────────────────────────────────
export function StockAIChat(props: StockAIChatProps) {
  const [open, setOpen]         = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput]       = useState("");
  const [loading, setLoading]   = useState(false);
  const [keyboardH, setKeyboardH] = useState(0);
  const abortRef                = useRef<AbortController | null>(null);
  const scrollRef               = useRef<HTMLDivElement>(null);
  const inputRef                = useRef<HTMLInputElement>(null);
  // Track if a scroll is in progress (to distinguish tap vs scroll on backdrop)
  const backdropScrollRef       = useRef(false);

  const systemPrompt = buildStockContext(
    props.stock, props.currentPrice, props.sentiment, props.metrics
  );

  // Detect keyboard height via visualViewport
  useEffect(() => {
    if (!open) return;
    function update() {
      if (!window.visualViewport) return;
      const keyH = window.innerHeight - window.visualViewport.height - window.visualViewport.offsetTop;
      setKeyboardH(Math.max(0, keyH));
    }
    window.visualViewport?.addEventListener("resize", update);
    window.visualViewport?.addEventListener("scroll", update);
    update();
    return () => {
      window.visualViewport?.removeEventListener("resize", update);
      window.visualViewport?.removeEventListener("scroll", update);
    };
  }, [open]);

  // Auto-scroll to bottom when messages change
  useEffect(() => {
    if (!scrollRef.current) return;
    scrollRef.current.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, loading]);

  // Lock body scroll while open
  useEffect(() => {
    if (!open) return;
    document.body.style.overflow = "hidden";
    return () => { document.body.style.overflow = ""; };
  }, [open]);

  function dismiss() {
    abortRef.current?.abort();
    setOpen(false);
    setMessages([]);
    setInput("");
    setLoading(false);
    setKeyboardH(0);
  }

  const handleSend = useCallback(async () => {
    const text = input.trim();
    if (!text || loading) return;
    setInput("");
    const userMsg: Message = { role: "user", text };
    setMessages(prev => [...prev, userMsg]);
    setLoading(true);

    abortRef.current?.abort();
    const ctrl = new AbortController();
    abortRef.current = ctrl;

    try {
      const reply = await callGemini(systemPrompt, messages.concat(userMsg), text, ctrl.signal);
      setMessages(prev => [...prev, { role: "model", text: reply }]);
    } catch (e) {
      if ((e as Error).name !== "AbortError") {
        const msg = (e as Error).message ?? "";
        let friendly = "Sorry, something went wrong. Please try again.";
        if (msg.includes("429")) friendly = "Rate limit reached. Please wait a moment and try again.";
        else if (msg.includes("401")) friendly = "Authentication error. Please check the API key.";
        setMessages(prev => [...prev, { role: "model", text: friendly }]);
      }
    } finally {
      setLoading(false);
    }
  }, [input, loading, messages, systemPrompt]);

  // Input pill bottom: sits above keyboard (or safe area)
  const inputBottom = keyboardH > 0
    ? `${keyboardH}px`
    : `calc(env(safe-area-inset-bottom) + 0.5rem)`;

  return (
    <>
      {/* AI trigger button — right side of top bar */}
      <button
        onClick={() => { setOpen(true); setTimeout(() => inputRef.current?.focus(), 100); }}
        className="ai-aberration flex items-center justify-center h-8 w-8 rounded-lg bg-accent/10 border border-accent/40 text-accent transition-all active:scale-90"
        aria-label="Ask AI about this stock"
      >
        <OptionalSvgIcon name="ai" className="ai-button-icon h-5 w-5" />
      </button>

      {open && (
        <>
          {/* ── Backdrop: blur + dim. Tap = dismiss, scroll = pass-through ── */}
          <div
            className="fixed inset-0 z-40"
            style={{ backdropFilter: "blur(2px)", WebkitBackdropFilter: "blur(2px)", background: "rgba(0,0,0,0.15)" }}
            onTouchStart={() => { backdropScrollRef.current = false; }}
            onTouchMove={() => { backdropScrollRef.current = true; }}
            onTouchEnd={() => {
              // Only dismiss on a true tap (no scroll movement)
              if (!backdropScrollRef.current) dismiss();
            }}
            onClick={dismiss}
          />

          {/* ── Chat message list ─────────────────────────────────────── */}
          <div
            ref={scrollRef}
            className="fixed inset-x-0 z-41 overflow-y-auto"
            style={{
              top: 0,
              bottom: keyboardH > 0
                ? `calc(${keyboardH}px + 3rem)`
                : `calc(env(safe-area-inset-bottom) + 3.5rem)`,
              paddingTop: "6rem",
              paddingBottom: "1rem",
              paddingLeft: "1rem",
              paddingRight: "1rem",
              pointerEvents: "none", // let taps fall through to backdrop
            }}
          >
            <div style={{ pointerEvents: "auto" }} /* only message bubbles catch events */>
              {messages.length === 0 && (
                <div className="flex justify-center mb-4">
                  <span className="text-xs text-white/50 bg-black/40 rounded-full px-3 py-1.5 backdrop-blur-sm">
                    Ask me anything about {props.stock.symbol}
                  </span>
                </div>
              )}

              <div className="flex flex-col gap-3">
                {messages.map((m, i) => (
                  <div key={i} className={cn("flex", m.role === "user" ? "justify-end" : "justify-start")}>
                    {m.role === "model" && (
                      <span className="h-6 w-6 rounded-full bg-accent flex items-center justify-center shrink-0 mr-2 mt-0.5">
                        <Sparkles className="h-3 w-3 text-on-accent" />
                      </span>
                    )}
                    <div
                      className={cn(
                        "smoked-glass-surface max-w-[78%] rounded-3xl border border-white/15 px-4 py-2.5 text-sm leading-relaxed shadow-lg",
                        m.role === "user" ? "font-medium" : "ai-response-bubble text-white/90"
                      )}
                      style={{
                        animation: "bubbleIn 0.2s ease both",
                        background: m.role === "user"
                          ? "linear-gradient(145deg, rgba(6,22,18,0.48), rgba(5,15,15,0.62) 56%, rgba(3,10,10,0.54))"
                          : "linear-gradient(145deg, rgba(8,20,20,0.48), rgba(5,15,15,0.62) 56%, rgba(3,10,10,0.54))",
                        color: "rgba(245,248,248,0.94)",
                        backdropFilter: "blur(24px) saturate(180%)",
                        WebkitBackdropFilter: "blur(24px) saturate(180%)",
                        borderColor: m.role === "model" ? "var(--color-accent)" : undefined,
                        boxShadow: m.role === "model" ? "0 0 12px color-mix(in srgb, var(--AI_COLOR) 48%, transparent), 0 0 3px color-mix(in srgb, var(--AI_COLOR) 70%, transparent), 0 24px 60px rgba(0,0,0,0.24), 0 5px 18px rgba(0,0,0,0.12), inset 0 0 16px rgba(0,0,0,0.18)" : "0 24px 60px rgba(0,0,0,0.24), 0 5px 18px rgba(0,0,0,0.12), inset 0 0 16px rgba(0,0,0,0.18)"
                      }}
                    >
                      {m.role === "model" ? <AIFormattedText text={m.text} /> : m.text}
                    </div>
                  </div>
                ))}

                {loading && (
                  <div className="flex justify-start">
                    <span className="h-6 w-6 rounded-full bg-accent flex items-center justify-center shrink-0 mr-2 mt-0.5">
                      <Sparkles className="h-3 w-3 text-on-accent" />
                    </span>
                    <div className="smoked-glass-surface ai-response-bubble rounded-3xl border border-accent px-4 py-3 flex items-center" style={{ background: "linear-gradient(145deg, rgba(8,20,20,0.48), rgba(5,15,15,0.62) 56%, rgba(3,10,10,0.54))", backdropFilter: "blur(24px) saturate(180%)", WebkitBackdropFilter: "blur(24px) saturate(180%)", boxShadow: "0 0 12px color-mix(in srgb, var(--AI_COLOR) 48%, transparent), 0 0 3px color-mix(in srgb, var(--AI_COLOR) 70%, transparent), 0 24px 60px rgba(0,0,0,0.24), 0 5px 18px rgba(0,0,0,0.12), inset 0 0 16px rgba(0,0,0,0.18)" }}>
                      <AIStarLoader size="md" />
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* ── Input pill — floats above keyboard ───────────────────── */}
          <div
            className="fixed inset-x-0 z-50 px-3 transition-all duration-200"
            style={{ bottom: inputBottom }}
          >
            <div className="smoked-glass-surface ai-typing-bar flex items-center gap-2 rounded-full border border-white/15 px-4 py-2 shadow-2xl" style={{ background: "linear-gradient(145deg, rgba(8,20,20,0.48), rgba(5,15,15,0.62) 56%, rgba(3,10,10,0.54))", backdropFilter: "blur(24px) saturate(180%)", WebkitBackdropFilter: "blur(24px) saturate(180%)", boxShadow: "0 24px 60px rgba(0,0,0,0.24), 0 5px 18px rgba(0,0,0,0.12), inset 0 0 16px rgba(0,0,0,0.18)" }}>
              <input
                ref={inputRef}
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); handleSend(); } }}
                placeholder="Ask about this stock…"
                className="flex-1 bg-transparent text-sm text-white placeholder:text-white/35 outline-none"
              />
              <button
                onClick={handleSend}
                disabled={!input.trim() || loading}
                className={cn(
                  "h-7 w-7 rounded-full flex items-center justify-center shrink-0 transition-all",
                  input.trim() && !loading
                    ? "bg-accent text-on-accent active:scale-90"
                    : "bg-white/10 text-white/30"
                )}
              >
                <Send className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>
        </>
      )}

      <style>{`
        @keyframes bubbleIn {
          from { opacity: 0; transform: scale(0.94) translateY(6px); }
          to   { opacity: 1; transform: scale(1)    translateY(0);   }
        }
      `}</style>
    </>
  );
}
