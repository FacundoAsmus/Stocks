"use client";

import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { useRouter } from "next/navigation";
import { ChevronLeft } from "lucide-react";

import { AddToWatchlistButton } from "@/components/AddToWatchlistButton";
import { AnalystSection } from "@/components/AnalystSection";
import { FundamentalsGrid } from "@/components/FundamentalsGrid";
import { FilingIndicators } from "@/components/FilingIndicators";
import { MarketSentiment } from "@/components/MarketSentiment";
import { PriceChart } from "@/components/PriceChart";
import { CompanyDescription } from "@/components/CompanyDescription";
import { NewsSummary } from "@/components/NewsSummary";
import { NewsCard } from "@/components/NewsCard";
import { EarningsCalendarButton } from "@/components/mobile/EarningsCalendarButton";
import { SECTOR_ETFS } from "@/components/market/EtfList";
import { StockAIChat } from "@/components/mobile/StockAIChat";
import { StockPriceAlertButton } from "@/components/StockPriceAlertButton";
import { cn } from "@/lib/utils";
import { isUsEquityMarketOpen } from "@/lib/usMarketHours";
import { subscribeToMarketRefresh } from "@/lib/marketRefresh";
import type { StockDetail } from "@/types/stock";

interface MobileStockPageProps {
  stock: StockDetail;
  currentPrice: number;
  sentiment: { score: number; drivers: string[] };
  metrics: Record<string, number | string | null> | undefined;
}

// Plays the search-close animation (fullscreen → tiny circle in bottom-right).

export function MobileStockPage(props: MobileStockPageProps) {
  const [liveData, setLiveData] = useState(props);
  const { stock, currentPrice, sentiment, metrics } = liveData;
  const router = useRouter();
  const pageRef = useRef<HTMLDivElement>(null);
  const [fromSearch,       setFromSearch]       = useState(false);
  const [searchOrigin,     setSearchOrigin]     = useState<string>("/");
  // ETFs don't file earnings reports the way individual companies do, so an
  // earnings calendar doesn't apply to them.
  const isEtf = SECTOR_ETFS.some(e => e.symbol === stock.symbol);
  const [mounted, setMounted] = useState(false);
  useEffect(() => { setMounted(true); }, []);

  useEffect(() => {
    const flag = sessionStorage.getItem("nav-from-search");
    if (flag) {
      setFromSearch(true);
      sessionStorage.removeItem("nav-from-search");
      setSearchOrigin(sessionStorage.getItem("search-origin") ?? "/");
    }
    const el = pageRef.current;
    if (el) {
      el.classList.add("page-enter-rise");
      el.addEventListener("animationend", () => el.classList.remove("page-enter-rise"), { once: true });
    }
  }, []);

  // Reset scroll to the top whenever the viewed stock changes — not just on
  // first mount. Next.js reuses this same page component instance (rather
  // than remounting it) when navigating directly from one stock page to
  // another, so a mount-only effect misses that case and the page opens
  // wherever the previous stock happened to be scrolled to.
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [stock.symbol]);

  useEffect(() => {
    setLiveData({ stock: props.stock, currentPrice: props.currentPrice, sentiment: props.sentiment, metrics: props.metrics });
  }, [props.stock, props.currentPrice, props.sentiment, props.metrics]);

  useEffect(() => {
    let inFlight = false;
    let controller: AbortController | null = null;
    const refresh = () => {
      if (inFlight || !isUsEquityMarketOpen()) return;
      inFlight = true;
      controller = new AbortController();
      fetch(`/api/stock-detail?symbol=${encodeURIComponent(props.stock.symbol)}&refresh=1`, { cache: "no-store", signal: controller.signal })
        .then(async response => {
          const payload = await response.json() as MobileStockPageProps & { error?: string };
          if (!response.ok) throw new Error(payload.error ?? "Unable to refresh stock data.");
          setLiveData(payload);
          window.dispatchEvent(new CustomEvent("stock-data-refreshed", { detail: { symbol: props.stock.symbol } }));
        })
        .catch(() => undefined)
        .finally(() => { inFlight = false; });
    };
    refresh();
    const unsubscribe = subscribeToMarketRefresh(refresh);
    return () => { unsubscribe(); controller?.abort(); };
  }, [props.stock.symbol]);

  function handleBack() {
    const el = pageRef.current;
    if (el) {
      el.classList.add("page-exit-sink");
      setTimeout(() => {
        if (fromSearch) router.push(searchOrigin as "/" | "/watchlist");
        else router.back();
      }, 380);
    } else {
      if (fromSearch) router.push(searchOrigin as "/" | "/watchlist");
      else router.back();
    }
  }

  return (
    <>
      {/* AI Chat — self-contained floating pill + overlay, mounted always */}
      <StockAIChat
        stock={stock}
        currentPrice={currentPrice}
        sentiment={sentiment}
        metrics={metrics}
      />

      <div
        className="sticky top-0 z-40 flex items-center justify-between gap-2 px-4 pb-3"
        style={{
          paddingTop: "calc(0.75rem + env(safe-area-inset-top))",
        }}
      >
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            backdropFilter: "blur(14px)",
            WebkitBackdropFilter: "blur(14px)",
            maskImage: "linear-gradient(to bottom, black, transparent)",
            WebkitMaskImage: "linear-gradient(to bottom, black, transparent)",
          }}
        />
        {/* Invisible — exists only to hold the same layout height as the
            real button below, so page content doesn't jump. */}
        <span className="invisible flex items-center justify-center h-[2.45rem] w-[2.45rem] rounded-full" aria-hidden>
          <ChevronLeft className="h-5 w-5" />
        </span>
        <StockPriceAlertButton symbol={stock.symbol} name={stock.profile.name ?? stock.symbol} currentPrice={currentPrice} mobile mobileHeader />
      </div>

      {/* The real, clickable Back button — portaled straight onto
          document.body (same pattern StockAIChat already uses reliably)
          so it's never nested inside the blurred header's own stacking
          context. That local nesting is what kept letting the blur end up
          rendered over the button despite z-index/isolate/transform
          attempts from inside the header itself. */}
      {mounted && createPortal(
        <button
          onClick={handleBack}
          aria-label="Back"
          className="fixed flex items-center justify-center h-[2.45rem] w-[2.45rem] text-accent"
          style={{
            top: "calc(0.75rem + env(safe-area-inset-top))",
            left: "1rem",
            zIndex: 500,
            background: "transparent",
          }}
        >
          <ChevronLeft className="h-5 w-5" />
        </button>,
        document.body
      )}

      <div ref={pageRef} className="pb-36" style={{ opacity: 1 }} data-stock-page="">

        <div className="flex items-center gap-3 px-4 pt-5 pb-3">
          {stock.profile.logo ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={stock.profile.logo} alt=""
              className="h-12 w-12 rounded-3xl border border-white/10 bg-white/5 object-contain shrink-0"
              onError={(e) => {
                e.currentTarget.style.display = "none";
                e.currentTarget.nextElementSibling?.classList.remove("hidden");
              }} />
          ) : null}
          <span className={cn(
            "h-12 w-12 flex items-center justify-center rounded-3xl border border-border-subtle bg-panel-muted font-bold shrink-0",
            stock.profile.logo && "hidden",
            isEtf ? "text-sm text-text-primary" : "text-sm text-text-primary"
          )}>
            {isEtf ? "ETF" : stock.symbol.replace("^", "").slice(0, 2)}
          </span>
          <div className="flex-1 min-w-0">
            <h1 className="text-xl font-bold text-text-primary leading-tight truncate">{stock.profile.name ?? stock.symbol}</h1>
          </div>
          <AddToWatchlistButton symbol={stock.symbol} name={stock.profile.name ?? stock.symbol} compact />
        </div>

        <div className="px-2">
          <PriceChart
            symbol={stock.symbol}
            currentPrice={currentPrice}
            currentChangePercent={stock.quote.dp ?? 0}
            previousClose={stock.quote.pc ?? undefined}
            heightClassName="h-[260px]"
            hideCursorDateTooltip
          />
        </div>

        <div className="flex flex-col gap-4 px-2 mt-4">
          <MarketSentiment score={sentiment.score} drivers={sentiment.drivers} />

          {!isEtf && (
            <AnalystSection
              recommendations={stock.recommendations}
              priceTarget={stock.priceTarget}
              currentPrice={currentPrice}
            />
          )}

          <FundamentalsGrid
            metrics={metrics}
            marketCap={stock.profile.marketCapitalization}
            currentPrice={currentPrice}
            earnings={stock.earnings}
            isEtf={isEtf}
          />

          {!isEtf && <FilingIndicators symbol={stock.symbol} compact />}

          {!isEtf && (
            <div className="flex justify-end -mt-2">
              <EarningsCalendarButton earnings={stock.earnings} />
            </div>
          )}

          {stock.news.length > 0 && (
            <section>
              <p className="text-xs font-semibold uppercase tracking-widest text-accent mb-1">News</p>
              <h2 className="mb-3 text-2xl font-semibold text-text-primary">Latest headlines</h2>
              <NewsSummary symbol={stock.symbol} articles={stock.news} />
              <div className="grid grid-cols-2 gap-3">
                {stock.news.slice(0, 8).map(article => (
                  <NewsCard key={article.id} article={article} />
                ))}
              </div>
            </section>
          )}

          <CompanyDescription symbol={stock.symbol} />
        </div>
      </div>
    </>
  );
}
