"use client";

import { useEffect, useLayoutEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { Reorder, useDragControls } from "framer-motion";
import { Area, AreaChart, ResponsiveContainer, YAxis } from "recharts";

import { LoadingScreen } from "@/components/EmptyWatchlist";
import { SECTOR_ETFS } from "@/components/market/EtfList";
import { MarketIcon } from "@/components/MarketIcon";
import { formatPercent } from "@/lib/format";
import { DEFAULT_WATCHLIST } from "@/lib/constants";
import { subscribeToMarketRefresh } from "@/lib/marketRefresh";
import { revealSparklineOnDataChange } from "@/lib/sparklineReveal";
import { WheelPrice } from "@/components/PriceChart";
import { cn } from "@/lib/utils";
import { OptionalSvgIcon } from "@/components/OptionalSvgIcon";
import type { StockSummary } from "@/types/stock";

const STORAGE_KEY = "market-lens-watchlist";

function readWatchlist(): string[] {
  if (typeof window === "undefined") return DEFAULT_WATCHLIST;
  const stored = window.localStorage.getItem(STORAGE_KEY);
  if (!stored) {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(DEFAULT_WATCHLIST));
    return DEFAULT_WATCHLIST;
  }
  try {
    const parsed = JSON.parse(stored);
    return Array.isArray(parsed) ? parsed : DEFAULT_WATCHLIST;
  } catch {
    return DEFAULT_WATCHLIST;
  }
}

function writeWatchlist(symbols: string[]) {
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(symbols));
  window.dispatchEvent(new Event("watchlist-updated"));
  window.dispatchEvent(new StorageEvent("storage", { key: STORAGE_KEY }));
}

function MiniSparkline({ stock }: { stock: StockSummary }) {
  const isPos = (stock.changePercent ?? 0) >= 0;
  const currentPrice = stock.price ?? 0;
  const yesterdayClose = currentPrice - (stock.change ?? 0);
  const data = stock.sparkline?.length
    ? [{ close: yesterdayClose, time: 0 }, ...stock.sparkline]
    : [{ time: 0, close: yesterdayClose }, { time: 1, close: currentPrice }];
  const graphDataKey = `${stock.price ?? ""}:${data.map((point) => `${point.time}:${point.close}`).join("|")}`;
  const graphRef = useRef<HTMLDivElement>(null);
  useLayoutEffect(() => {
    revealSparklineOnDataChange(graphRef.current, stock.symbol, graphDataKey);
  }, [stock.symbol, graphDataKey]);
  return (
    <div ref={graphRef} className="h-10 w-20 shrink-0 pointer-events-none">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data} margin={{ left: 0, right: 0, top: 2, bottom: 2 }}>
          <YAxis domain={["dataMin", "dataMax"]} hide width={0} />
          <Area
            type="monotone"
            dataKey="close"
            stroke={isPos ? "#00c805" : "#ff3003"}
            fill="transparent"
            strokeWidth={2}
            strokeLinecap="round"
            dot={false}
            isAnimationActive={false}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}

function RowContent({ stock }: { stock: StockSummary }) {
  const isPos = (stock.changePercent ?? 0) >= 0;
  const isEtf = SECTOR_ETFS.some((e) => e.symbol === stock.symbol);
  const hasStockLogo = !!stock.logo && !isEtf;
  return (
    <>
      {hasStockLogo ? (
        <img
          src={stock.logo}
          alt=""
          className="h-9 w-9 rounded-3xl border border-white/10 bg-white/5 object-contain shrink-0 pointer-events-none"
          onError={(e) => {
            e.currentTarget.style.display = "none";
            const fallback = e.currentTarget.nextElementSibling as HTMLElement | null;
            if (fallback) fallback.style.display = "inline-flex";
          }}
        />
      ) : null}
      <MarketIcon className={cn("h-9 w-9 shrink-0 rounded-3xl object-contain pointer-events-none", hasStockLogo && "hidden")} />
      <span className="flex-1 min-w-0 pointer-events-none">
        <span className="block text-sm font-bold text-text-primary truncate">{stock.symbol}</span>
      </span>
      <MiniSparkline stock={stock} />
      <span className="ml-3 shrink-0 pointer-events-none">
        <span
          className={cn(
            "watchlist-change-badge inline-block text-sm font-bold text-black px-3 py-1 rounded-3xl",
            isPos ? "is-positive bg-positive" : "is-negative bg-negative"
          )}
        >
          <WheelPrice value={formatPercent(stock.changePercent)} size="badge" colorClass="text-black" compact />
        </span>
      </span>
    </>
  );
}

const REVEAL_WIDTH = 76;
const OVERDRAG_MAX = 28;

function withResistance(raw: number) {
  if (raw >= -REVEAL_WIDTH) return raw;
  const excess = -REVEAL_WIDTH - raw;
  const damped = OVERDRAG_MAX * (1 - Math.exp(-excess / OVERDRAG_MAX));
  return -REVEAL_WIDTH - damped;
}

const SETTLE_TRANSITION = "transform 0.3s cubic-bezier(0.16, 1, 0.3, 1)";

function WatchlistRow({
  stock,
  onRemove,
  isRemoving,
}: {
  stock: StockSummary;
  onRemove: (s: string) => void;
  isRemoving: boolean;
}) {
  const router = useRouter();
  const innerRef = useRef<HTMLDivElement>(null);
  const dragControls = useDragControls();

  const dragXRef = useRef(0);
  const revealedRef = useRef(false);
  const startRef = useRef<{ x: number; y: number; startDragX: number; decided: boolean } | null>(null);

  // Long press refs & state
  const longPressTimer = useRef<NodeJS.Timeout | null>(null);
  const pointerStartPos = useRef<{ x: number; y: number } | null>(null);
  const activePointerEvent = useRef<PointerEvent | null>(null);

  const [isDragging, setIsDragging] = useState(false);
  const isDraggingRef = useRef(false);

  function applyX(x: number, animate: boolean) {
    const el = innerRef.current;
    if (!el) return;
    el.style.transition = animate ? SETTLE_TRANSITION : "none";
    el.style.transform = `translateX(${x}px)`;
  }

  function close() {
    dragXRef.current = 0;
    revealedRef.current = false;
    applyX(0, true);
  }

  // Non-passive Touch listener to intercept scroll when reorder activates
  useEffect(() => {
    function preventTouchScroll(e: TouchEvent) {
      if (isDraggingRef.current) {
        if (e.cancelable) e.preventDefault();
      }
    }

    window.addEventListener("touchmove", preventTouchScroll, { passive: false });
    return () => {
      window.removeEventListener("touchmove", preventTouchScroll);
    };
  }, []);

  // Handle horizontal swipe-to-delete & long-press reorder
  useEffect(() => {
    const el = innerRef.current;
    if (!el) return;

    function clearTimer() {
      if (longPressTimer.current) {
        clearTimeout(longPressTimer.current);
        longPressTimer.current = null;
      }
    }

    function onPointerDown(e: PointerEvent) {
      if (e.pointerType === "mouse" && e.button !== 0) return;

      startRef.current = { x: e.clientX, y: e.clientY, startDragX: dragXRef.current, decided: false };
      pointerStartPos.current = { x: e.clientX, y: e.clientY };
      activePointerEvent.current = e;

      clearTimer();

      // Trigger drag reorder after holding for 250ms
      longPressTimer.current = setTimeout(() => {
        if (navigator.vibrate) {
          try {
            navigator.vibrate(20);
          } catch {
            /* ignore */
          }
        }

        isDraggingRef.current = true;
        setIsDragging(true);

        if (activePointerEvent.current) {
          dragControls.start(activePointerEvent.current, { snapToCursor: false });
        }
      }, 250);
    }

    function onPointerMove(e: PointerEvent) {
      activePointerEvent.current = e;

      if (isDraggingRef.current) {
        if (e.cancelable) e.preventDefault();
        return;
      }

      // If finger moves > 6px before 250ms, cancel long press
      if (pointerStartPos.current) {
        const dx = Math.abs(e.clientX - pointerStartPos.current.x);
        const dy = Math.abs(e.clientY - pointerStartPos.current.y);
        if (dx > 6 || dy > 6) {
          clearTimer();
        }
      }

      // Horizontal swipe reveal handling
      const start = startRef.current;
      if (!start) return;
      const dx = e.clientX - start.x;
      const dy = e.clientY - start.y;

      if (!start.decided) {
        if (Math.abs(dx) < 8 && Math.abs(dy) < 8) return;
        start.decided = true;
        if (Math.abs(dx) <= Math.abs(dy) * 1.15) {
          startRef.current = null;
          return;
        }
      }

      if (e.cancelable) e.preventDefault();
      const raw = start.startDragX + dx;
      const next = raw > 0 ? 0 : withResistance(raw);
      dragXRef.current = next;
      applyX(next, false);
    }

    function onPointerEnd() {
      clearTimer();
      activePointerEvent.current = null;

      if (!startRef.current) return;
      const shouldReveal = dragXRef.current < -REVEAL_WIDTH / 2;
      const target = shouldReveal ? -REVEAL_WIDTH : 0;
      dragXRef.current = target;
      revealedRef.current = shouldReveal;
      applyX(target, true);
      startRef.current = null;
    }

    el.addEventListener("pointerdown", onPointerDown, { passive: true });
    el.addEventListener("pointermove", onPointerMove, { passive: false });
    el.addEventListener("pointerup", onPointerEnd, { passive: true });
    el.addEventListener("pointercancel", onPointerEnd, { passive: true });

    return () => {
      clearTimer();
      el.removeEventListener("pointerdown", onPointerDown);
      el.removeEventListener("pointermove", onPointerMove);
      el.removeEventListener("pointerup", onPointerEnd);
      el.removeEventListener("pointercancel", onPointerEnd);
    };
  }, [dragControls]);

  useEffect(() => {
    function onScroll() {
      if (revealedRef.current) close();
    }
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleDragEnd = () => {
    isDraggingRef.current = false;
    setIsDragging(false);
  };

  return (
    <Reorder.Item
      value={stock.symbol}
      as="div"
      dragListener={false}
      dragControls={dragControls}
      layout="position"
      initial={false}
      animate={isRemoving ? { height: 0, opacity: 0, scale: 0.96, marginTop: 0, marginBottom: 0 } : { height: "auto", opacity: 1, scale: 1 }}
      className="relative overflow-hidden rounded-2xl border-b border-border-subtle/70 last:border-0 bg-black select-none"
      whileDrag={{
        scale: 1.03,
        boxShadow: "0 16px 40px rgba(0,0,0,0.55)",
        zIndex: 50,
      }}
      transition={isRemoving ? { duration: 0.48, ease: [0.22, 1, 0.36, 1] } : { type: "spring", stiffness: 500, damping: 40 }}
      onDragEnd={handleDragEnd}
      style={{
        touchAction: isDragging ? "none" : "pan-y",
        WebkitUserSelect: "none",
        WebkitTouchCallout: "none",
      }}
    >
      <div className="relative">
        <div
          className="absolute inset-y-0 right-0 flex items-center justify-center"
          style={{ width: REVEAL_WIDTH }}
        >
          <button
            onClick={() => onRemove(stock.symbol)}
            aria-label={`Remove ${stock.symbol}`}
            className="flex items-center justify-center text-accent active:scale-90 transition-transform"
          >
            <OptionalSvgIcon name="star" selected fallbackToBaseWhenSelected className="h-5 w-5" />
          </button>
        </div>

        <div
          ref={innerRef}
          className="flex items-center gap-1 pl-4 pr-4 py-3.5 bg-black"
          style={{
            transform: "translateX(0px)",
            willChange: "transform",
            WebkitTouchCallout: "none",
            WebkitUserSelect: "none",
            userSelect: "none",
          }}
          suppressHydrationWarning
        >
          <div
            className="flex items-center gap-3 flex-1 min-w-0 cursor-grab active:cursor-grabbing"
            onClick={() => {
              if (isDragging) return;
              if (revealedRef.current) {
                close();
                return;
              }
              router.push(`/stock/${stock.symbol}`);
            }}
          >
            <RowContent stock={stock} />
          </div>
        </div>
      </div>
    </Reorder.Item>
  );
}

export function MobileWatchlist() {
  const [symbols, setSymbols] = useState<string[]>([]);
  const [stocks, setStocks] = useState<Map<string, StockSummary>>(new Map());
  const [loading, setLoading] = useState(true);
  const [watchlistInitialized, setWatchlistInitialized] = useState(false);
  const [removingSymbols, setRemovingSymbols] = useState<Set<string>>(() => new Set());
  const removalTimersRef = useRef<Map<string, ReturnType<typeof setTimeout>>>(new Map());
  const symbolQuery = [...symbols].sort().join(",");

  useEffect(() => () => {
    removalTimersRef.current.forEach(timer => clearTimeout(timer));
    removalTimersRef.current.clear();
  }, []);

  useEffect(() => {
    function sync() {
      setSymbols(readWatchlist());
      setWatchlistInitialized(true);
    }
    sync();
    window.addEventListener("watchlist-updated", sync);
    window.addEventListener("storage", sync);
    return () => {
      window.removeEventListener("watchlist-updated", sync);
      window.removeEventListener("storage", sync);
    };
  }, []);

  useEffect(() => {
    if (!symbolQuery) {
      if (watchlistInitialized) setLoading(false);
      return;
    }
    const ctrl = new AbortController();
    setLoading(true);
    fetch(`/api/stocks?symbols=${encodeURIComponent(symbolQuery)}&refresh=1`, { signal: ctrl.signal, cache: "no-store" })
      .then((r) => r.json() as Promise<{ stocks?: StockSummary[] }>)
      .then((d) => {
        const fetched = d.stocks ?? [];
        setStocks((prev) => {
          const next = new Map(prev);
          fetched.forEach((s) => next.set(s.symbol, s));
          return next;
        });
      })
      .catch(() => {})
      .finally(() => {
        if (!ctrl.signal.aborted) setLoading(false);
      });
    return () => ctrl.abort();
  }, [symbolQuery, watchlistInitialized]);

  useEffect(() => {
    if (!symbolQuery) return;
    let controller: AbortController | null = null;
    const refresh = () => {
      controller?.abort();
      const requestController = new AbortController();
      controller = requestController;
      fetch(`/api/stocks?symbols=${encodeURIComponent(symbolQuery)}&refresh=1`, { signal: requestController.signal, cache: "no-store" })
        .then((response) => response.ok ? response.json() as Promise<{ stocks?: StockSummary[] }> : null)
        .then((data) => {
          if (!data?.stocks || requestController.signal.aborted) return;
          setStocks((previous) => {
            const next = new Map(previous);
            data.stocks?.forEach((stock) => next.set(stock.symbol, stock));
            return next;
          });
        })
        .catch(() => undefined);
    };
    const unsubscribe = subscribeToMarketRefresh(refresh);
    return () => { unsubscribe(); controller?.abort(); };
  }, [symbolQuery]);

  function handleRemove(symbol: string) {
    if (removalTimersRef.current.has(symbol)) return;
    setRemovingSymbols(current => new Set(current).add(symbol));
    const timer = setTimeout(() => {
      removalTimersRef.current.delete(symbol);
      const updated = readWatchlist().filter((s) => s !== symbol);
      setSymbols(updated);
      writeWatchlist(updated);
      setRemovingSymbols(current => {
        const next = new Set(current);
        next.delete(symbol);
        return next;
      });
    }, 500);
    removalTimersRef.current.set(symbol, timer);
  }

  function handleReorder(newOrder: string[]) {
    if (newOrder.length !== symbols.length) return;
    setSymbols(newOrder);
    writeWatchlist(newOrder);
  }

  const orderedStocks = symbols.map((s) => stocks.get(s)).filter(Boolean) as StockSummary[];

  if (!watchlistInitialized || (loading && !orderedStocks.length)) return <LoadingScreen label="Loading your watchlist" />;

  return (
    <div className="pb-24">
      <div
        className="sticky top-0 z-30 px-4 pb-4 flex items-end justify-between gap-3"
        style={{ paddingTop: "calc(1.5rem + env(safe-area-inset-top))" }}
      >
        <div
          className="absolute inset-x-0 top-0 -z-10 pointer-events-none"
          style={{
            height: "calc(100% + 3.6rem)",
            backdropFilter: "blur(14px)",
            WebkitBackdropFilter: "blur(14px)",
            maskImage: "linear-gradient(to bottom, black, transparent)",
            WebkitMaskImage: "linear-gradient(to bottom, black, transparent)",
          }}
        />
        <div>
          <h1 className="text-4xl font-bold text-text-primary">Your Stocks</h1>
          <p className="mt-1 text-xs font-semibold uppercase tracking-widest text-accent">Watchlist</p>
        </div>
      </div>

      {orderedStocks.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-24 gap-3 text-center">
          <p className="text-lg font-semibold text-text-primary">Your watchlist is empty</p>
          <p className="text-sm text-text-muted">Search for stocks to add them.</p>
        </div>
      ) : (
        <Reorder.Group
          as="div"
          axis="y"
          values={orderedStocks.map((s) => s.symbol)}
          onReorder={handleReorder}
          className="mx-2 mt-[0.95rem] rounded-xl bg-black"
        >
          {orderedStocks.map((stock) => (
            <WatchlistRow key={stock.symbol} stock={stock} onRemove={handleRemove} isRemoving={removingSymbols.has(stock.symbol)} />
          ))}
        </Reorder.Group>
      )}
    </div>
  );
}
