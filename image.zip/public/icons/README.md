# Optional UI SVG icons

Upload SVG files into this folder using the names below. Icons are tinted by the UI and sized by their component. If a file is missing, its icon is omitted without leaving a placeholder.

## Navigation

- `market.svg`, `market-selected.svg`
- `watchlist.svg`, `watchlist-selected.svg`
- `settings.svg`, `settings-selected.svg`

The same files are used on desktop and phone. Each layout controls its own size and selected tint.

## Site logo

- `site-logo.png` — daytime/light-mode site logo.
- `site-logo-dark.png` — nighttime/dark-mode site logo. The Market page requests this file in dark mode and falls back to `site-logo.png` until the dark version is added.

Both logos are displayed as rectangular images with the same rounded corners as the alert bubble.

## Market heatmap groups

Use the group id for the unselected and selected versions:

- `broad.svg`, `broad-selected.svg`
- `tech.svg`, `tech-selected.svg`
- `semiconductors.svg`, `semiconductors-selected.svg`
- `financials.svg`, `financials-selected.svg`
- `energy.svg`, `energy-selected.svg`
- `health-care.svg`, `health-care-selected.svg`
- `industrials.svg`, `industrials-selected.svg`
- `consumer-discretionary.svg`, `consumer-discretionary-selected.svg`
- `consumer-staples.svg`, `consumer-staples-selected.svg`
- `materials.svg`, `materials-selected.svg`
- `real-estate.svg`, `real-estate-selected.svg`
- `utilities.svg`, `utilities-selected.svg`
- `metals.svg`, `metals-selected.svg`
- `treasury-bonds.svg`, `treasury-bonds-selected.svg`

## Stock page sections

- `info.svg` — Indicator description title icon
- `stock-sentiment.svg`
- `indicators.svg`
- `capex.svg`
- `r-and-d.svg`
- `free-cash-flow.svg`
- `capex.svg` is also used for Revenue, Debt, Net Margin, R&D, and Free cash flow headings.
- `growth.svg` — Growth financial-chart category
- `financial-health.svg` — Financial health chart category
- `cash-flows.svg` — Cash flows chart category
- `news.svg`
- `description.svg`
- `calendar.svg`
- `ai.svg`
- `alerts.svg`
- `filled-bell.svg`
- `tools.svg`
- `star.svg`, `star-selected.svg`
- `star-crossed.svg`
- `cancel-alert.svg`
- `close.svg`

## Empty lists

- `empty-list.svg` — shown with the red empty-state message when the desktop watchlist or AI chat list has no items.

## Settings

- `horizontal-crosshair.svg`
- `candlestick-chart.svg`
- `volume-chart.svg`
- `color-bars.svg`
- `alert-price-lines.svg`
- `theme-dark.svg`
- `theme-light.svg`
- `theme-system.svg`

## Analyst and stock tools

- `analyst.svg` — Analyst section heading (desktop and comparison)
- `tools-ma-7.svg` — MA(7) action in the desktop Function menu
- `tools-ma-25.svg` — MA(25) action in the desktop Function menu
- `tools-ma-99.svg` — MA(99) action in the desktop Function menu
- `tools-line.svg` — Draw price line action in the right-click chart tools menu
- `tools-vertical-line.svg` — Draw a vertical line in the right-click chart tools menu
- `tools-rectangle.svg` — Draw a rectangle in the right-click chart tools menu
- `tools-diagonal.svg` — Draw a diagonal line in the right-click chart tools menu
- `tools-erase.svg` — Erase chart drawings in the right-click chart tools menu
- `compare.svg` — Compare-stock action in desktop watchlist search results and recents
- `server-error.svg` — AI server-error notice shown after the automatic retry fails
- `back.svg` — Back control on the phone individual stock page
- `send.svg` — Send action in AI chat input buttons
- `icon-error.svg` — Red fallback displayed whenever a requested UI icon file is missing
