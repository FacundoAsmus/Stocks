"use client";

import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { motion } from "framer-motion";
import { Sparkles } from "lucide-react";
import { Area, ComposedChart, Line, LineChart, ReferenceArea, ReferenceDot, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { formatCompact, formatCurrency, formatNumber, formatPercent } from "@/lib/format";
import { formatEarningsForAIContext, getNextReport, todayStr } from "@/lib/earnings";
import { AIStarLoader } from "@/components/AIStarLoader";
import { OptionalSvgIcon } from "@/components/OptionalSvgIcon";
import { AIUnavailableNotice } from "@/components/AIUnavailableNotice";
import { requestAIChat } from "@/lib/aiChatRequest";
import { getRandomAIWelcome } from "@/lib/aiWelcome";
import { GlossyCloseIcon, GlossyIconButton } from "@/components/GlossyIconButton";
import { WheelPrice, tooltipLabel } from "@/components/PriceChart";
import { COMPARISON_COLORS, mergeComparisonCandles, type ComparisonRow } from "@/components/desktop/ComparisonPriceChart";
import type { CandlePoint, ChartPeriod, StockDetail } from "@/types/stock";

interface Message { role: "user" | "model"; text: string; animating?: boolean }

// Context bundle the data-pill / graph widgets are computed from.
interface GraphCtx {
  stock: StockDetail;
  currentPrice: number;
  sentiment: { score: number; drivers: string[] };
  metrics: Record<string, number | string | null> | undefined;
  comparisonStock?: {
    stock: StockDetail;
    currentPrice: number;
    sentiment: { score: number; drivers: string[] };
    metrics: Record<string, number | string | null> | undefined;
  };
  isLightMode: boolean;
}

// Split AI text on [[+]]positive[[/+]] and [[-]]negative[[/-]] tags and render coloured spans
function ColorizedText({ text }: { text: string }) {
  const parts: { str: string; type: "neutral" | "pos" | "neg" }[] = [];
  const regex = /(\[\[\+\]\])([\s\S]*?)(\[\[\/\+\]\])|(\[\[-\]\])(.*?)(\[\[\/-\]\])/g;
  let last = 0, m: RegExpExecArray | null;
  while ((m = regex.exec(text)) !== null) {
    if (m.index > last) parts.push({ str: text.slice(last, m.index), type: "neutral" });
    if (m[1]) parts.push({ str: m[2], type: "pos" });
    else       parts.push({ str: m[5], type: "neg" });
    last = m.index + m[0].length;
  }
  if (last < text.length) parts.push({ str: text.slice(last), type: "neutral" });
  return (
    <>
      {parts.map((p, i) =>
        p.type === "pos" ? (
          <span key={i} style={{ color: "#00c805", fontWeight: 600 }}>{p.str}</span>
        ) : p.type === "neg" ? (
          <span key={i} style={{ color: "#ff3003", fontWeight: 600 }}>{p.str}</span>
        ) : (
          <span key={i}>{p.str}</span>
        )
      )}
    </>
  );
}

// ─────────────────────────────────────────────────────────────────────────
// Inline data pills & graphs — the AI calls these out with [[data:KEY]] and
// [[graph:TYPE]] tags in its response text, the same way it wraps numbers in
// [[+]]/[[-]] for coloring. Each tag becomes its own block in the message:
// text before it stays above, text after it flows below.
// ─────────────────────────────────────────────────────────────────────────

const DATA_KEYS = [
  "marketCap", "peRatio", "forwardPe", "eps",
  "dividendYield", "beta", "high52", "low52", "avgVolume", "priceTarget",
] as const;
type DataKey = typeof DATA_KEYS[number];

const GRAPH_TYPES = [
  "price:1D", "price:1W", "price:1M", "price:3M", "price:5M", "price:6M", "price:1Y", "price:2Y", "price:5Y", "price:ALL",
  "ma7", "ma25", "ma99", "volume", "capex", "rnd", "freeCashFlow", "earnings", "eps", "analyst", "sentiment", "targets",
  "comparePrice:1D", "comparePrice:1W", "comparePrice:1M", "comparePrice:3M", "comparePrice:5M", "comparePrice:6M", "comparePrice:1Y", "comparePrice:2Y", "comparePrice:5Y", "comparePrice:ALL",
  "compareData:marketCap", "compareData:peRatio", "compareData:forwardPe", "compareData:eps", "compareData:dividendYield", "compareData:beta", "compareData:high52", "compareData:low52", "compareData:avgVolume", "compareData:priceTarget",
  "compareGraph:capex", "compareGraph:rnd", "compareGraph:freeCashFlow",
  "calendar",
] as const;
type GraphType = typeof GRAPH_TYPES[number];

// ─────────────────────────────────────────────────────────────────────────
// Chart annotations — the AI marks up a price graph with pure financial
// meaning (a date, a price, a label) and NEVER coordinates. The frontend
// (GraphPrice, via recharts' Reference* components) converts date/price
// into actual x/y pixel positions. Three kinds, capped per response:
//   [[mark:...]]   up to 3  — one point-in-time event (dot + vertical line)
//   [[level:...]]  up to 2  — a horizontal support/resistance/level line
//   [[region:...]] up to 1  — a shaded date-range band
// ─────────────────────────────────────────────────────────────────────────

interface MarkAnnotation   { type: "mark";   date: string; price: number; label: string; color: "positive" | "negative" | "neutral"; series?: "primary" | "secondary" }
interface LevelAnnotation  { type: "level";  price: number; label: string; levelType: "support" | "resistance" | "level"; series?: "primary" | "secondary" }
interface RegionAnnotation { type: "region"; start: string; end: string; label: string; tone: "positive" | "negative" | "neutral" }
type Annotation = MarkAnnotation | LevelAnnotation | RegionAnnotation;

const MARK_LIMIT = 3;
const LEVEL_LIMIT = 2;
const REGION_LIMIT = 1;

const MARK_TAG_RE   = /\[\[mark:([\s\S]*?)\]\]/g;
const LEVEL_TAG_RE  = /\[\[level:([\s\S]*?)\]\]/g;
const REGION_TAG_RE = /\[\[region:([\s\S]*?)\]\]/g;

// "graph=1M; date=2025-07-03; price=183.42; label=Q2 Earnings; color=neutral"
// → { graph: "1M", date: "2025-07-03", price: "183.42", label: "Q2 Earnings", color: "neutral" }
function parseAnnotationFields(raw: string): Record<string, string> {
  const out: Record<string, string> = {};
  for (const chunk of raw.split(";")) {
    const eq = chunk.indexOf("=");
    if (eq === -1) continue;
    const key = chunk.slice(0, eq).trim();
    const val = chunk.slice(eq + 1).trim();
    if (key && val) out[key] = val;
  }
  return out;
}

const TONE_VALUES = ["positive", "negative", "neutral"] as const;
function asTone(v: string | undefined): "positive" | "negative" | "neutral" {
  return (TONE_VALUES as readonly string[]).includes(v ?? "") ? (v as "positive" | "negative" | "neutral") : "neutral";
}

// Strips every annotation tag out of the raw text (they never render as
// their own text/block — they only ever attach to the one price graph in
// the message) and returns what's left to parse normally, plus the parsed
// annotation list (capped per-kind, first calls win).
function extractAnnotations(text: string): { cleaned: string; annotations: Annotation[] } {
  const annotations: Annotation[] = [];

  let cleaned = text.replace(MARK_TAG_RE, (_, raw: string) => {
    if (annotations.filter(a => a.type === "mark").length >= MARK_LIMIT) return "";
    const f = parseAnnotationFields(raw);
    const price = Number(f.price);
    if (!f.date || !f.label || Number.isNaN(price)) return "";
    annotations.push({ type: "mark", date: f.date, price, label: f.label, color: asTone(f.color), series: f.series === "secondary" ? "secondary" : f.series === "primary" ? "primary" : undefined });
    return "";
  });

  cleaned = cleaned.replace(LEVEL_TAG_RE, (_, raw: string) => {
    if (annotations.filter(a => a.type === "level").length >= LEVEL_LIMIT) return "";
    const f = parseAnnotationFields(raw);
    const price = Number(f.price);
    if (!f.label || Number.isNaN(price)) return "";
    const levelType = f.type === "support" || f.type === "resistance" ? f.type : "level";
    annotations.push({ type: "level", price, label: f.label, levelType, series: f.series === "secondary" ? "secondary" : f.series === "primary" ? "primary" : undefined });
    return "";
  });

  cleaned = cleaned.replace(REGION_TAG_RE, (_, raw: string) => {
    if (annotations.filter(a => a.type === "region").length >= REGION_LIMIT) return "";
    const f = parseAnnotationFields(raw);
    if (!f.start || !f.end || !f.label) return "";
    annotations.push({ type: "region", start: f.start, end: f.end, label: f.label, tone: asTone(f.tone) });
    return "";
  });

  return { cleaned, annotations };
}

type Segment =
  | { kind: "text"; value: string }
  | { kind: "pill"; key: DataKey }
  | { kind: "graph"; graphType: GraphType; annotations?: Annotation[] }
  | { kind: "news"; index: number };

const TAG_RE = /\[\[data:([a-zA-Z0-9_]+)\]\]|\[\[graph:([a-zA-Z0-9_:]+)\]\]|\[\[news:(\d+)\]\]/g;

// Parses AI text into an ordered list of text runs + widget calls. Enforces
// "one of a kind per message" — a repeated tag for the same key/type is
// silently dropped (the first call wins). Chart annotations are stripped
// out first and (if a price graph is present) attached to it directly.
function parseSegments(text: string): Segment[] {
  const { cleaned, annotations } = extractAnnotations(text);
  const segments: Segment[] = [];
  const seenPills = new Set<string>();
  const seenGraphs = new Set<string>();
  let last = 0;
  let m: RegExpExecArray | null;
  TAG_RE.lastIndex = 0;
  while ((m = TAG_RE.exec(cleaned)) !== null) {
    if (m.index > last) segments.push({ kind: "text", value: cleaned.slice(last, m.index) });
    if (m[1] && DATA_KEYS.includes(m[1] as DataKey) && !seenPills.has(m[1])) {
      segments.push({ kind: "pill", key: m[1] as DataKey });
      seenPills.add(m[1]);
    } else if (m[2] && GRAPH_TYPES.includes(m[2] as GraphType) && !seenGraphs.has(m[2])) {
      const seg: Segment = { kind: "graph", graphType: m[2] as GraphType };
      if ((m[2].startsWith("price") || m[2].startsWith("comparePrice")) && annotations.length) seg.annotations = annotations;
      segments.push(seg);
      seenGraphs.add(m[2]);
    } else if (m[3] !== undefined) {
      const idx = parseInt(m[3]);
      segments.push({ kind: "news", index: idx });
    }
    last = TAG_RE.lastIndex;
  }
  if (last < cleaned.length) segments.push({ kind: "text", value: cleaned.slice(last) });
  return segments;
}

function toNum(v: number | string | null | undefined): number | null {
  if (typeof v === "number") return v;
  if (typeof v === "string") { const n = Number(v); return Number.isNaN(n) ? null : n; }
  return null;
}

function computeDataPoint(key: DataKey, ctx: GraphCtx): { label: string; value: string; tone: "positive" | "negative" | "neutral" } {
  const m = ctx.metrics;
  switch (key) {
    case "marketCap": {
      const mc = ctx.stock.profile.marketCapitalization;
      return { label: "Market Cap", value: formatCompact((mc ?? 0) * 1_000_000), tone: "neutral" };
    }
    case "peRatio": {
      const pe = toNum(m?.peTTM ?? m?.peNormalizedAnnual);
      return { label: "P/E Ratio", value: pe !== null ? formatNumber(pe) : "N/A", tone: pe === null ? "neutral" : pe <= 15 ? "positive" : pe >= 30 ? "negative" : "neutral" };
    }
    case "forwardPe": {
      const fpe = toNum(m?.forwardPE);
      return { label: "Forward P/E", value: fpe !== null ? formatNumber(fpe) : "N/A", tone: fpe === null ? "neutral" : fpe <= 15 ? "positive" : fpe >= 28 ? "negative" : "neutral" };
    }
    case "eps": {
      const eps = toNum(m?.epsNormalizedAnnual ?? m?.epsTTM);
      return { label: "EPS", value: formatCurrency(eps), tone: eps === null ? "neutral" : eps > 0 ? "positive" : "negative" };
    }
    case "dividendYield": {
      const dy = toNum(m?.dividendYieldIndicatedAnnual);
      return { label: "Dividend Yield", value: formatPercent(dy), tone: dy !== null && dy >= 3 ? "positive" : "neutral" };
    }
    case "beta": {
      const b = toNum(m?.beta);
      return { label: "Beta", value: formatNumber(b), tone: b === null ? "neutral" : b < 0.8 ? "positive" : b > 1.4 ? "negative" : "neutral" };
    }
    case "high52": {
      const h = toNum(m?.["52WeekHigh"]);
      return { label: "52W High", value: formatCurrency(h), tone: "neutral" };
    }
    case "low52": {
      const l = toNum(m?.["52WeekLow"]);
      return { label: "52W Low", value: formatCurrency(l), tone: "neutral" };
    }
    case "avgVolume": {
      const v = toNum(m?.["10DayAverageTradingVolume"]);
      return { label: "Avg Volume", value: formatCompact(v ? v * 1_000_000 : null), tone: "neutral" };
    }
    case "priceTarget": {
      const t = ctx.stock.priceTarget?.targetMean;
      const tone: "positive" | "negative" | "neutral" = t && ctx.currentPrice
        ? (t > ctx.currentPrice ? "positive" : t < ctx.currentPrice ? "negative" : "neutral")
        : "neutral";
      return { label: "Avg Price Target", value: t ? formatCurrency(t) : "N/A", tone };
    }
  }
}

// A small pill — fits inline content width only, so it can never push past
// the chat bubble's own max-width. Fades/rises in on mount.
function DataPill({ dataKey, ctx, identityColor, symbol }: { dataKey: DataKey; ctx: GraphCtx; identityColor?: string; symbol?: string }) {
  const [mounted, setMounted] = useState(false);
  useEffect(() => {
    const raf = requestAnimationFrame(() => setMounted(true));
    return () => cancelAnimationFrame(raf);
  }, []);
  const point = computeDataPoint(dataKey, ctx);
  const color = identityColor ?? (point.tone === "positive" ? "#00c805" : point.tone === "negative" ? "#ff3003" : "#9a9aa2");
  return (
    <div style={{
      display: "inline-flex", alignItems: "center", gap: 8,
      maxWidth: "100%",
      padding: "8px 14px",
      borderRadius: 999,
      border: `2px solid ${color}`,
      backgroundColor: "transparent",
      boxShadow: `0 0 10px ${color}70`,
      opacity: mounted ? 1 : 0,
      transform: mounted ? "translateY(0) scale(1)" : "translateY(4px) scale(0.96)",
      transition: "opacity 0.22s ease, transform 0.22s ease",
    }}>
      <span style={{ height: 7, width: 7, borderRadius: "50%", backgroundColor: color, flexShrink: 0 }} />
      <span style={{ fontSize: 11, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.04em", color: "#9a9aa2", whiteSpace: "nowrap" }}>
        {symbol ? `${symbol} · ${point.label}` : point.label}
      </span>
      <span style={{ fontSize: 15, fontWeight: 700, color, whiteSpace: "nowrap" }}>{point.value}</span>
    </div>
  );
}

// Sweeping shimmer shown while a graph is "generating".
function GraphShimmer() {
  return (
    <div style={{ position: "absolute", inset: 0, borderRadius: 8, overflow: "hidden", backgroundColor: "transparent" }}>
      <div className="ai-graph-shimmer" style={{
        position: "absolute", inset: 0, width: "60%",
      }} />
    </div>
  );
}

// Shared frame every graph renders inside — bounded so its width/height can
// never exceed the message bubble that contains it.
// The individual stock page's own chart (PriceChart) sits in a fluid-width
// column at a fixed 320px height, so its own on-screen aspect ratio (width
// ÷ height) lands in roughly this range across normal desktop widths — this
// is the ratio we match here so the AI's inline graph doesn't look stretched
// on wide chat panels.
const DESKTOP_GRAPH_ASPECT_RATIO = 3.2;
const MOBILE_GRAPH_ASPECT_RATIO = 1.46;

function GraphFrame({ title, value, ready, tall, children }: { title?: string; value?: React.ReactNode; ready: boolean; children: React.ReactNode; isLightMode?: boolean; tall?: boolean }) {
  const measureRef = useRef<HTMLDivElement>(null);
  const minHeight = tall ? 150 : 108;
  const maxHeight = tall ? 260 : 220;
  const [height, setHeight] = useState(minHeight);

  // Width is left exactly as the surrounding layout already sizes it (chat
  // bubble / panel width is untouched) — only the height adapts to keep the
  // chart's proportions consistent as that width changes across screen sizes.
  useEffect(() => {
    const el = measureRef.current;
    if (!el) return;
    const measure = () => {
      const width = el.getBoundingClientRect().width;
      if (!width) return;
      // Match the desktop watchlist chart on large screens and the taller
      // individual-stock chart on phones.
      const ratio = window.innerWidth < 1024 ? MOBILE_GRAPH_ASPECT_RATIO : DESKTOP_GRAPH_ASPECT_RATIO;
      const proportional = width / ratio;
      setHeight(Math.min(maxHeight, Math.max(minHeight, proportional)));
    };
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    return () => ro.disconnect();
  }, [minHeight, maxHeight]);

  return (
    <div ref={measureRef} style={{
      width: "100%",
      maxWidth: "100%",
      boxSizing: "border-box",
      padding: "0 0 4px",
      overflow: "hidden",
    }}>
      {title && <p style={{ fontSize: 11, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.05em", color: "var(--color-accent)", margin: "0 0 4px" }}>{title}</p>}
      {value !== undefined && <div style={{ marginBottom: 6, color: "var(--color-text-primary)", lineHeight: 1 }}>{typeof value === "string" ? <WheelPrice value={value} size="xs" /> : value}</div>}
      <div style={{ position: "relative", height, width: "100%" }}>
        {!ready && <GraphShimmer />}
        <div style={{ height: "100%", width: "100%", opacity: ready ? 1 : 0, transition: "opacity 0.25s ease" }}>
          {children}
        </div>
      </div>
    </div>
  );
}

function sentimentColor(score: number) {
  if (score <= 20) return "#dc2626";
  if (score <= 40) return "#f97316";
  if (score <= 60) return "#facc15";
  if (score <= 80) return "#a3e635";
  return "#34d399";
}

function GraphSentiment({ ctx }: { ctx: GraphCtx }) {
  const { isLightMode } = ctx;
  const [ready, setReady] = useState(false);
  const [pct, setPct] = useState(0);
  const score = ctx.sentiment.score;
  useEffect(() => {
    const t = setTimeout(() => {
      setReady(true);
      requestAnimationFrame(() => requestAnimationFrame(() => setPct(score)));
    }, 550);
    return () => clearTimeout(t);
  }, [score]);
  const color = sentimentColor(score);
  return (
    <GraphFrame title="Sentiment Score" ready={ready} isLightMode={isLightMode}>
      <div style={{ display: "flex", flexDirection: "column", justifyContent: "center", height: "100%", gap: 4 }}>
        <div style={{ display: "flex", alignItems: "baseline", gap: 8 }}>
          <span style={{ fontSize: 28, fontWeight: 700, color }}>{score}</span>
          <span style={{ fontSize: 13, color: "#9a9aa2" }}>/ 100</span>
        </div>
        <div style={{ height: 8, borderRadius: 999, backgroundColor: "rgba(255,255,255,0.08)", overflow: "hidden" }}>
          <div style={{ height: "100%", width: `${pct}%`, backgroundColor: color, boxShadow: `0 0 10px ${color}70`, transition: "width 0.8s cubic-bezier(0.22,1,0.36,1)", borderRadius: 999 }} />
        </div>
      </div>
    </GraphFrame>
  );
}

function GraphAnalyst({ ctx }: { ctx: GraphCtx }) {
  const { isLightMode } = ctx;
  const [ready, setReady] = useState(false);
  const [progress, setProgress] = useState(0);
  useEffect(() => {
    const t = setTimeout(() => {
      setReady(true);
      requestAnimationFrame(() => requestAnimationFrame(() => setProgress(1)));
    }, 550);
    return () => clearTimeout(t);
  }, []);
  const latest = ctx.stock.recommendations?.[0];
  const total = latest ? latest.strongBuy + latest.buy + latest.hold + latest.sell + latest.strongSell : 0;
  const rows: [string, number, string][] = latest ? [
    ["Strong Buy", latest.strongBuy, "#34d399"],
    ["Buy", latest.buy, "#a3e635"],
    ["Hold", latest.hold, "#facc15"],
    ["Sell", latest.sell, "#f97316"],
    ["Strong Sell", latest.strongSell, "#dc2626"],
  ] : [];
  return (
    <GraphFrame title="Analyst Recommendations" ready={ready} isLightMode={isLightMode}>
      {total === 0 ? (
        <div style={{ display: "flex", alignItems: "center", height: "100%", fontSize: 13, color: "#9a9aa2" }}>
          No analyst coverage available.
        </div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", justifyContent: "center", gap: 6, height: "100%" }}>
          {rows.map(([label, count, color]) => (
            <div key={label} style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <span style={{ fontSize: 10, width: 62, color: "#9a9aa2", flexShrink: 0 }}>{label}</span>
              <div style={{ flex: 1, height: 6, borderRadius: 999, backgroundColor: "rgba(255,255,255,0.08)", overflow: "hidden" }}>
                <div style={{
                  height: "100%",
                  width: `${progress * Math.max((count / total) * 100, count ? 4 : 0)}%`,
                  backgroundColor: color,
                  boxShadow: `0 0 10px ${color}70`,
                  transition: "width 0.8s cubic-bezier(0.22,1,0.36,1)",
                  borderRadius: 999,
                }} />
              </div>
              <span style={{ fontSize: 11, width: 16, textAlign: "right", color: isLightMode ? "#000" : "#f0f0f2", flexShrink: 0 }}>{count}</span>
            </div>
          ))}
        </div>
      )}
    </GraphFrame>
  );
}

function GraphTargets({ ctx }: { ctx: GraphCtx }) {
  const { isLightMode } = ctx;
  const [ready, setReady] = useState(false);
  useEffect(() => {
    const t = setTimeout(() => setReady(true), 550);
    return () => clearTimeout(t);
  }, []);
  const pt = ctx.stock.priceTarget;
  const hasData = pt?.targetLow != null && pt?.targetHigh != null && pt.targetHigh > pt.targetLow;
  return (
    <GraphFrame title="Analyst Price Targets" ready={ready} isLightMode={isLightMode}>
      {!hasData ? (
        <div style={{ display: "flex", alignItems: "center", height: "100%", fontSize: 13, color: "#9a9aa2" }}>
          No price target data available.
        </div>
      ) : (() => {
        const low = pt.targetLow as number;
        const high = pt.targetHigh as number;
        const mean = pt.targetMean ?? (low + high) / 2;
        const span = Math.max(high - low, 0.01);
        const pct = (v: number) => Math.min(100, Math.max(0, ((v - low) / span) * 100));
        return (
          <div style={{ display: "flex", flexDirection: "column", justifyContent: "center", gap: 18, height: "100%" }}>
            <div style={{ position: "relative", height: 6, borderRadius: 999, backgroundColor: "rgba(128,128,128,0.18)" }}>
              <div style={{ position: "absolute", left: `${pct(mean)}%`, top: -4, width: 2, height: 14, backgroundColor: "#9a9aa2", transform: "translateX(-50%)" }} />
              <div style={{
                position: "absolute", left: `${pct(ctx.currentPrice)}%`, top: -6, width: 12, height: 12,
                borderRadius: "50%", backgroundColor: "#00c805", border: "2px solid #000", transform: "translateX(-50%)",
              }} />
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11, color: "#9a9aa2" }}>
              <span>Low {formatCurrency(low)}</span>
              <span>Mean {formatCurrency(mean)}</span>
              <span>High {formatCurrency(high)}</span>
            </div>
          </div>
        );
      })()}
    </GraphFrame>
  );
}

// Finds the candle whose date is closest to a target date string — this is
// the ONLY thing that turns an AI-given date into a chart position; the AI
// itself never sees or picks pixel/x coordinates.
function nearestCandleDate(points: CandlePoint[], targetDate: string): string | null {
  const target = new Date(targetDate).getTime();
  if (Number.isNaN(target)) return null;
  let best: CandlePoint | null = null;
  let bestDiff = Infinity;
  for (const p of points) {
    const diff = Math.abs(new Date(p.date).getTime() - target);
    if (diff < bestDiff) { bestDiff = diff; best = p; }
  }
  return best?.date ?? null;
}

const ANNOTATION_COLOR: Record<"positive" | "negative" | "neutral", string> = {
  positive: "#00c805",
  negative: "#ff3003",
  neutral:  "#9a9aa2",
};

// Point annotations are always neutral grey — never colored red/green, even
// though the tag itself still accepts a color field for backwards
// compatibility. Only levels (support/resistance) and regions use tone color.
const MARK_COLOR = "#9a9aa2";

// Recharts' label prop receives the dot's own pixel box for a ReferenceDot,
// letting us offset the label text away from the marker without ever
// touching data/pixel coordinates ourselves in the annotation language.
function markLabelRenderer(text: string, xSide: "left" | "right", ySide: "above" | "below") {
  function MarkLabel(props: { viewBox?: { x?: number; y?: number; width?: number; height?: number } }) {
    const vb = props.viewBox;
    if (!vb || vb.x == null || vb.y == null) return <g />;
    const cx = vb.x + (vb.width ?? 0) / 2;
    const cy = vb.y + (vb.height ?? 0) / 2;
    const dx = xSide === "left" ? -7 : 7;
    const dy = ySide === "above" ? -8 : 15;
    return (
      <text
        x={cx + dx}
        y={cy + dy}
        textAnchor={xSide === "left" ? "end" : "start"}
        fontSize={9}
        fontWeight={600}
        fill={MARK_COLOR}
      >
        {text}
      </text>
    );
  }
  return MarkLabel;
}

const MA_COLORS: Record<number, string> = { 7: "#f59e0b", 25: "#ec4899", 99: "#8b5cf6" };

function computeMovingAverage(points: CandlePoint[], windowDays: number): (number | null)[] {
  const dayMs = 24 * 60 * 60 * 1000;
  const result: (number | null)[] = new Array(points.length).fill(null);
  if (!points.length) return result;
  const firstTime = points[0].time * 1000;
  let start = 0;
  let sum = 0;
  for (let i = 0; i < points.length; i += 1) {
    sum += points[i].close;
    const windowStart = points[i].time * 1000 - windowDays * dayMs;
    while (start < i && points[start].time * 1000 < windowStart) sum -= points[start++].close;
    result[i] = points[i].time * 1000 - firstTime >= windowDays * dayMs ? sum / (i - start + 1) : null;
  }
  return result;
}

function GraphPrice({ ctx, period = "1M", annotations, maWindow }: { ctx: GraphCtx; period?: string; annotations?: Annotation[]; maWindow?: 7 | 25 | 99 }) {
  const [ready, setReady] = useState(false);
  const [points, setPoints] = useState<CandlePoint[] | null>(null);
  const [failed, setFailed] = useState(false);
  const [hoverPrice, setHoverPrice] = useState<number | null>(null);
  const [dotCY, setDotCY] = useState<number | null>(null);
  const [isTouching, setIsTouching] = useState(false);
  const [touchOverlay, setTouchOverlay] = useState<{ xPct: number; yPct: number } | null>(null);
  const [proMode, setProMode] = useState(() => typeof window !== "undefined" && localStorage.getItem("pro-mode") === "1");
  const chartRef = useRef<HTMLDivElement>(null);
  const blockScrollRef = useRef<((event: TouchEvent) => void) | null>(null);
  const { isLightMode } = ctx;

  const periodLabel: Record<string, string> = {
    "1D":"Today","1W":"1 Week","1M":"1 Month","3M":"3 Months",
    "5M":"5 Months","6M":"6 Months","1Y":"1 Year","2Y":"2 Years","5Y":"5 Years","ALL":"All Time",
  };

  useEffect(() => {
    let cancelled = false;
    const minDelay = new Promise(resolve => setTimeout(resolve, 550));
    (async () => {
      try {
        const res = await fetch(`/api/candles?symbol=${encodeURIComponent(ctx.stock.symbol)}&period=${period}`);
        const data = await res.json() as { candles?: CandlePoint[]; error?: string };
        await minDelay;
        if (cancelled) return;
        if (data.candles?.length) {
          // For 1D: prepend previous day's close as the first point (same as PriceChart + watchlist)
          if (period === "1D" && ctx.stock.quote.pc && ctx.stock.quote.pc > 0) {
            const prevPoint: CandlePoint = { close: ctx.stock.quote.pc, date: data.candles[0].date, time: data.candles[0].time - 1 };
            setPoints([prevPoint, ...data.candles]);
          } else {
            setPoints(data.candles);
          }
        } else setFailed(true);
      } catch {
        await minDelay;
        if (!cancelled) setFailed(true);
      } finally {
        if (!cancelled) setReady(true);
      }
    })();
    return () => { cancelled = true; };
  }, [ctx.stock.symbol, period, ctx.stock.quote.pc]);

  useEffect(() => {
    const sync = () => setProMode(localStorage.getItem("pro-mode") === "1");
    window.addEventListener("pro-mode-changed", sync);
    window.addEventListener("storage", sync);
    return () => { window.removeEventListener("pro-mode-changed", sync); window.removeEventListener("storage", sync); };
  }, []);

  // Mirror the individual phone chart: a finger locks page scrolling for the
  // duration of the gesture and drives its own snapped crosshair/dot overlay.
  useEffect(() => {
    const element = chartRef.current;
    if (!element || !points?.length) return;
    const updateFromClientX = (clientX: number) => {
      const rect = element.getBoundingClientRect();
      const xPct = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
      const index = Math.round(xPct * (points.length - 1));
      const point = points[Math.max(0, Math.min(points.length - 1, index))];
      const prices = points.map(item => item.close);
      const min = Math.min(...prices);
      const max = Math.max(...prices);
      setHoverPrice(point.close);
      setTouchOverlay({ xPct, yPct: max === min ? 0.5 : 1 - (point.close - min) / (max - min) });
    };
    const endTouch = () => {
      document.removeEventListener("touchmove", moveTouch);
      document.removeEventListener("touchend", endTouch);
      document.removeEventListener("touchcancel", endTouch);
      if (blockScrollRef.current) {
        document.removeEventListener("touchmove", blockScrollRef.current);
        blockScrollRef.current = null;
      }
      setIsTouching(false);
      setTouchOverlay(null);
      setHoverPrice(null);
    };
    const moveTouch = (event: TouchEvent) => updateFromClientX(event.touches[0].clientX);
    const startTouch = (event: TouchEvent) => {
      setIsTouching(true);
      updateFromClientX(event.touches[0].clientX);
      document.addEventListener("touchmove", moveTouch, { passive: true });
      document.addEventListener("touchend", endTouch);
      document.addEventListener("touchcancel", endTouch);
      const block = (moveEvent: TouchEvent) => moveEvent.preventDefault();
      blockScrollRef.current = block;
      document.addEventListener("touchmove", block, { passive: false });
    };
    element.addEventListener("touchstart", startTouch, { passive: true });
    return () => {
      element.removeEventListener("touchstart", startTouch);
      endTouch();
    };
  }, [points]);

  const positive = !points || points.length < 2 ? true : points[points.length - 1].close >= points[0].close;
  const lineColor = positive ? "#00c805" : "#ff3003";
  const hasAnnotations = !!annotations?.length;

  // Shared domain used to decide "near the top/bottom edge" for label
  // placement — mirrors what ifOverflow="extendDomain" would settle on.
  let priceDomainMin = 0, priceDomainMax = 0;
  if (points?.length) {
    const values = points.map(p => p.close);
    if (annotations) {
      for (const a of annotations) {
        if (a.type === "mark" || a.type === "level") values.push(a.price);
      }
    }
    priceDomainMin = Math.min(...values);
    priceDomainMax = Math.max(...values);
  }
  const priceSpan = Math.max(priceDomainMax - priceDomainMin, 0.0001);

  const chartPoints = maWindow && points
    ? points.map((point, index) => ({ ...point, movingAverage: computeMovingAverage(points, maWindow)[index] ?? undefined }))
    : points;
  const displayedPrice = hoverPrice ?? points?.[points.length - 1]?.close ?? null;

  return (
    <GraphFrame title={maWindow ? `Price — ${periodLabel[period] ?? period} · MA ${maWindow}` : `Price — ${periodLabel[period] ?? period}`} value={formatCurrency(displayedPrice)} ready={ready} isLightMode={isLightMode} tall={hasAnnotations}>
      {failed || !points?.length ? (
        <div style={{ display: "flex", alignItems: "center", height: "100%", fontSize: 13, color: "#9a9aa2" }}>
          Price history unavailable.
        </div>
      ) : (
            <div ref={chartRef} className={positive ? "stock-chart-positive" : "stock-chart-negative"} style={{ position: "relative", height: "100%" }} onMouseLeave={() => { if (!isTouching) { setHoverPrice(null); setDotCY(null); } }}>
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={chartPoints ?? []} margin={{ top: hasAnnotations ? 14 : 4, right: 4, bottom: 0, left: 4 }}>
            <defs>
              <linearGradient id="miniAiChartFill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={lineColor} stopOpacity={0.22} />
                <stop offset="100%" stopColor={lineColor} stopOpacity={0} />
              </linearGradient>
            </defs>
            <XAxis dataKey="date" hide />
            <YAxis domain={["dataMin", "dataMax"]} hide />
            <Tooltip
              cursor={typeof window !== "undefined" && "ontouchstart" in window ? false : { stroke: "rgba(128,128,128,0.5)", strokeWidth: 1 }}
              content={<></>}
            />
            <Area
              type="monotone" dataKey="close" stroke={lineColor} fill="url(#miniAiChartFill)" strokeWidth={2} dot={false} isAnimationActive={false}
              activeDot={(props: Record<string, unknown>) => {
                const { cx, cy, payload } = props as { cx?: number; cy?: number; payload?: CandlePoint };
                if (cx == null || cy == null || !payload || (typeof window !== "undefined" && "ontouchstart" in window)) return <g />;
                if (hoverPrice !== payload.close) setHoverPrice(payload.close);
                if (proMode && dotCY !== cy) setDotCY(cy);
                return <circle cx={cx} cy={cy} r={4} fill={lineColor} stroke={isLightMode ? "#fff" : "#000"} strokeWidth={1.5} />;
              }}
            />
            {maWindow && (
              <Line type="monotone" dataKey="movingAverage" stroke={MA_COLORS[maWindow]} strokeWidth={2.5} dot={false} activeDot={false} connectNulls isAnimationActive={false} />
            )}

            {annotations?.filter((a): a is RegionAnnotation => a.type === "region").map((a, i) => {
              const x1 = nearestCandleDate(points, a.start);
              const x2 = nearestCandleDate(points, a.end);
              if (!x1 || !x2) return null;
              const color = ANNOTATION_COLOR[a.tone];
              return (
                <ReferenceArea
                  key={`region-${i}`}
                  x1={x1} x2={x2}
                  fill={color} fillOpacity={0.12}
                  stroke={color} strokeOpacity={0.3}
                  label={{ value: a.label, position: "insideTop", fontSize: 9, fontWeight: 600, fill: color }}
                  ifOverflow="extendDomain"
                />
              );
            })}

            {annotations?.filter((a): a is LevelAnnotation => a.type === "level").map((a, i) => {
              const color = a.levelType === "support" ? "#00c805" : a.levelType === "resistance" ? "#ff3003" : "#9a9aa2";
              // Keep the label off the chart edge the same way marks do —
              // if the level sits near the top/bottom, hug the opposite side.
              const yProp = (a.price - priceDomainMin) / priceSpan;
              const position = yProp >= 0.8 ? "insideBottomRight" : yProp <= 0.2 ? "insideTopRight" : "insideBottomRight";
              return (
                <ReferenceLine
                  key={`level-${i}`}
                  y={a.price}
                  stroke={color}
                  strokeDasharray="4 3"
                  strokeWidth={1.25}
                  ifOverflow="extendDomain"
                  label={{ value: a.label, position, fontSize: 9, fontWeight: 600, fill: color }}
                />
              );
            })}

            {/* Point annotations — always neutral grey. Vertical line has no
                label of its own; the dot carries a custom-positioned label
                chosen to avoid the chart edges and the price line itself. */}
            {annotations?.filter((a): a is MarkAnnotation => a.type === "mark").map((a, i) => {
              const x = nearestCandleDate(points, a.date);
              if (!x) return null;
              return (
                <ReferenceLine
                  key={`mark-line-${i}`}
                  x={x}
                  stroke={MARK_COLOR}
                  strokeDasharray="2 3"
                  strokeWidth={1}
                  ifOverflow="extendDomain"
                />
              );
            })}
            {annotations?.filter((a): a is MarkAnnotation => a.type === "mark").map((a, i) => {
              const x = nearestCandleDate(points, a.date);
              if (!x) return null;

              // Horizontal: hug whichever side has room — near the right
              // edge, the label goes left of the line, and vice versa.
              const idx = points.findIndex(p => p.date === x);
              const xProp = points.length > 1 ? idx / (points.length - 1) : 0.5;
              const xSide: "left" | "right" = xProp >= 0.72 ? "left" : "right";

              // Vertical: keep the label off the price line — if the point
              // sits in the top half of the chart, drop the label below it,
              // and if it sits in the bottom half, lift the label above it.
              const yProp = (a.price - priceDomainMin) / priceSpan;
              const ySide: "above" | "below" = yProp >= 0.5 ? "below" : "above";

              return (
                <ReferenceDot
                  key={`mark-dot-${i}`}
                  x={x} y={a.price}
                  r={3.5}
                  fill={MARK_COLOR}
                  stroke={isLightMode ? "#fff" : "#000"}
                  strokeWidth={1.5}
                  ifOverflow="extendDomain"
                  label={markLabelRenderer(a.label, xSide, ySide)}
                />
              );
            })}
          </ComposedChart>
        </ResponsiveContainer>
        {proMode && dotCY !== null && <div aria-hidden style={{ position: "absolute", left: 0, right: 0, top: dotCY, height: 1, background: "rgba(128,128,128,0.5)", pointerEvents: "none" }} />}
        {isTouching && touchOverlay && (() => {
          const xPct = touchOverlay.xPct * 100;
          const chartMarginTopPx = hasAnnotations ? 14 : 4;
          const height = chartRef.current?.getBoundingClientRect().height ?? 1;
          const dotTopPct = ((chartMarginTopPx + touchOverlay.yPct * (height - chartMarginTopPx)) / height) * 100;
          return <div className="absolute inset-0 pointer-events-none" aria-hidden>
            <div data-crosshair-v="" style={{ position: "absolute", left: `${xPct}%`, top: 0, bottom: 0, width: 1, background: "rgba(128,128,128,0.5)" }} />
            {proMode && <div data-crosshair-h="" style={{ position: "absolute", left: 0, right: 0, top: `${dotTopPct}%`, height: 1, background: "rgba(128,128,128,0.5)" }} />}
            <div style={{ position: "absolute", left: `${xPct}%`, top: `${dotTopPct}%`, width: 12, height: 12, transform: "translate(-50%, -50%)", borderRadius: "50%", border: `2px solid ${isLightMode ? "#fff" : "#000"}`, background: lineColor }} />
          </div>;
        })()}
        </div>
      )}
    </GraphFrame>
  );
}

function NewsCard({ index, ctx }: { index: number; ctx: GraphCtx }) {
  if (ctx.comparisonStock) return null;
  const article = ctx.stock.news?.[index];
  if (!article) return null;
  return (
    <a href={article.url} target="_blank" rel="noreferrer" aria-label={article.headline}
      onClick={event => event.stopPropagation()}
      className="my-2 block aspect-video w-full max-w-[192px] overflow-hidden rounded-3xl border border-white/15 bg-panel-muted">
      {article.image ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={article.image} alt="" loading="lazy" decoding="async" className="h-full w-full object-cover" />
      ) : <span className="block h-full w-full bg-panel-muted" />}
    </a>
  );
}

type FilingIndicator = { year: number; capex: number | null; researchAndDevelopment: number | null; freeCashFlow: number | null };
type FilingMetric = "capex" | "researchAndDevelopment" | "freeCashFlow";

function indicatorColor(percentage: number) {
  const stops: [number, [number, number, number]][] = [[0, [220, 38, 38]], [25, [249, 115, 22]], [50, [250, 204, 21]], [75, [163, 230, 53]], [100, [52, 211, 153]]];
  const highIndex = stops.findIndex(([stop]) => percentage <= stop);
  const high = stops[Math.max(1, highIndex === -1 ? stops.length - 1 : highIndex)];
  const low = stops[stops.indexOf(high) - 1];
  const progress = (percentage - low[0]) / (high[0] - low[0] || 1);
  return `rgb(${Math.round(low[1][0] + (high[1][0] - low[1][0]) * progress)}, ${Math.round(low[1][1] + (high[1][1] - low[1][1]) * progress)}, ${Math.round(low[1][2] + (high[1][2] - low[1][2]) * progress)})`;
}

function GraphFilingMetric({ ctx, title, field }: { ctx: GraphCtx; title: string; field: FilingMetric }) {
  const [ready, setReady] = useState(false);
  const [indicators, setIndicators] = useState<FilingIndicator[] | null>(null);
  const [hoveredValue, setHoveredValue] = useState<number | null>(null);
  useEffect(() => {
    const controller = new AbortController();
    fetch(`/api/filing-indicators?symbol=${encodeURIComponent(ctx.stock.symbol)}`, { signal: controller.signal })
      .then(res => res.ok ? res.json() as Promise<{ indicators?: FilingIndicator[] }> : { indicators: [] })
      .then(data => { if (!controller.signal.aborted) setIndicators(data.indicators ?? []); })
      .catch(() => { if (!controller.signal.aborted) setIndicators([]); })
      .finally(() => { if (!controller.signal.aborted) setReady(true); });
    return () => controller.abort();
  }, [ctx.stock.symbol]);

  const values = indicators?.map(item => item[field]) ?? [];
  const max = Math.max(...values.filter((value): value is number => value !== null).map(value => Math.abs(value)), 1);
  const latestValue = [...values].reverse().find((value): value is number => value !== null) ?? null;
  const hasNegative = values.some(value => (value ?? 0) < 0);
  const baseline = hasNegative ? "45%" : "14%";
  return (
    <GraphFrame title={title} value={hoveredValue === null ? (latestValue === null ? "N/A" : `$${formatCompact(latestValue)}`) : `$${formatCompact(hoveredValue)}`} ready={ready} tall>
      {!indicators?.some(item => item[field] !== null) ? <div style={{ display: "flex", alignItems: "center", height: "100%", color: "#9a9aa2", fontSize: 13 }}>SEC filing data unavailable.</div> : (
        <div style={{ position: "relative", height: "100%", borderTop: "1px solid var(--color-border-subtle)", borderBottom: "1px solid var(--color-border-subtle)" }}>
          <div style={{ position: "absolute", left: 0, right: 0, ...(hasNegative ? { top: baseline } : { bottom: baseline }), borderTop: "1px solid var(--color-border-subtle)" }} />
          <div style={{ display: "grid", gridTemplateColumns: `repeat(${indicators.length}, minmax(0, 1fr))`, height: "100%" }}>
            {indicators.map(item => {
              const value = item[field];
              const percentage = value === null ? 0 : Math.abs(value) / max * 100;
              const height = value === null ? 0 : Math.max(percentage * (hasNegative ? 0.4 : 0.78), 3);
              const color = indicatorColor(value === null ? 50 : value < 0 ? 50 - Math.abs(value) / max * 50 : 50 + value / max * 50);
              return <div key={item.year} style={{ position: "relative", borderLeft: "1px solid var(--color-border-subtle)", cursor: value === null ? "default" : "pointer" }} onMouseEnter={() => { if (value !== null) setHoveredValue(value); }} onMouseLeave={() => setHoveredValue(null)} title={value === null ? `${item.year}: unavailable` : `${item.year}: $${formatCompact(value)}`}>
                {value !== null && <div style={{ position: "absolute", left: "37.5%", width: "25%", maxWidth: 20, borderRadius: 2, ...(value < 0 ? { top: baseline } : { bottom: hasNegative ? "55%" : baseline }), height: `${height}%`, backgroundColor: color, boxShadow: `0 0 10px ${color.replace("rgb(", "rgba(").replace(")", ", 0.42)")}` }} />}
                <span style={{ position: "absolute", bottom: 2, left: "50%", transform: "translateX(-50%)", fontSize: 10, fontWeight: 600, color: "var(--color-accent)" }}>{item.year}</span>
              </div>;
            })}
          </div>
        </div>
      )}
    </GraphFrame>
  );
}

function GraphEarningsMetric({ ctx, metric, title }: { ctx: GraphCtx; metric: "revenue" | "eps"; title: string }) {
  const [ready, setReady] = useState(false);
  const [hoveredValue, setHoveredValue] = useState<number | null>(null);
  useEffect(() => { const timer = setTimeout(() => setReady(true), 550); return () => clearTimeout(timer); }, []);
  const points = [...ctx.stock.earnings].sort((a, b) => a.date.localeCompare(b.date)).slice(-8).map(event => ({ event, value: metric === "revenue" ? event.revenueActual ?? event.revenueEstimate : event.epsActual ?? event.epsEstimate, estimate: event.date >= new Date().toISOString().slice(0, 10) }));
  const values = points.map(point => point.value).filter((value): value is number => value !== null);
  const maximum = Math.max(...values.map(value => Math.abs(value)), 1);
  const latestValue = [...points].reverse().find((point): point is typeof point & { value: number } => point.value !== null)?.value ?? null;
  const hasNegative = values.some(value => value < 0);
  const baseline = hasNegative ? "45%" : "14%";
  return (
    <GraphFrame title={title} value={hoveredValue === null ? (latestValue === null ? "N/A" : metric === "revenue" ? `$${formatCompact(latestValue)}` : formatCurrency(latestValue)) : metric === "revenue" ? `$${formatCompact(hoveredValue)}` : formatCurrency(hoveredValue)} ready={ready} tall>
      {!values.length ? <div style={{ display: "flex", alignItems: "center", height: "100%", color: "#9a9aa2", fontSize: 13 }}>Earnings data unavailable.</div> : (
        <div style={{ position: "relative", height: "100%", borderTop: "1px solid var(--color-border-subtle)", borderBottom: "1px solid var(--color-border-subtle)" }}>
          <div style={{ position: "absolute", left: 0, right: 0, ...(hasNegative ? { top: baseline } : { bottom: baseline }), borderTop: "1px solid var(--color-border-subtle)" }} />
          <div style={{ display: "grid", gridTemplateColumns: `repeat(${points.length}, minmax(0, 1fr))`, height: "100%" }}>
            {points.map(({ event, value, estimate }) => {
              const height = value === null ? 0 : Math.max(Math.abs(value) / maximum * (hasNegative ? 40 : 78), 3);
              const color = indicatorColor(value === null ? 50 : value < 0 ? 50 - Math.abs(value) / maximum * 50 : 50 + value / maximum * 50);
              const label = metric === "revenue" ? `$${formatCompact(value)}` : formatCurrency(value);
              return <div key={event.date} style={{ position: "relative", borderLeft: "1px solid var(--color-border-subtle)", cursor: value === null ? "default" : "pointer" }} onMouseEnter={() => { if (value !== null) setHoveredValue(value); }} onMouseLeave={() => setHoveredValue(null)} title={`Q${event.quarter} ${event.year}: ${label}${estimate ? " estimate" : " actual"}`}>
                {value !== null && <div style={{ position: "absolute", left: "37.5%", width: "25%", maxWidth: 20, borderRadius: 2, ...(value < 0 ? { top: baseline } : { bottom: hasNegative ? "55%" : baseline }), height: `${height}%`, backgroundColor: estimate ? "rgb(var(--accent-rgb) / 0.15)" : color, border: estimate ? "1px solid var(--color-accent)" : undefined, boxShadow: estimate ? undefined : `0 0 10px ${color.replace("rgb(", "rgba(").replace(")", ", 0.42)")}` }} />}
                <span style={{ position: "absolute", bottom: 2, left: "50%", transform: "translateX(-50%)", fontSize: 10, fontWeight: 600, color: "var(--color-accent)" }}>Q{event.quarter}</span>
              </div>;
            })}
          </div>
        </div>
      )}
    </GraphFrame>
  );
}

function GraphVolume({ ctx }: { ctx: GraphCtx }) {
  const [ready, setReady] = useState(false);
  const [points, setPoints] = useState<CandlePoint[]>([]);
  useEffect(() => {
    const controller = new AbortController();
    fetch(`/api/candles?symbol=${encodeURIComponent(ctx.stock.symbol)}&period=1M`, { signal: controller.signal })
      .then(res => res.ok ? res.json() as Promise<{ candles?: CandlePoint[] }> : { candles: [] })
      .then(data => { if (!controller.signal.aborted) setPoints(data.candles ?? []); })
      .catch(() => { if (!controller.signal.aborted) setPoints([]); })
      .finally(() => { if (!controller.signal.aborted) setReady(true); });
    return () => controller.abort();
  }, [ctx.stock.symbol]);
  const volumes = points.map(point => point.volume ?? 0).filter(volume => volume > 0);
  const average = volumes.length ? volumes.reduce((sum, volume) => sum + volume, 0) / volumes.length : null;
  const maximum = Math.max(...volumes, 1);
  return <GraphFrame title="Volume — 1 Month" value={average === null ? "N/A" : formatCompact(average)} ready={ready}>
    {!volumes.length ? <div style={{ display: "flex", alignItems: "center", height: "100%", color: "#9a9aa2", fontSize: 13 }}>Volume data unavailable.</div> : (
      <div style={{ display: "flex", alignItems: "end", gap: 1, height: "100%" }} aria-label="One month of trading volume">
        {points.map((point, index) => {
          const volume = point.volume ?? 0;
          const up = point.close >= (point.open ?? point.close);
          return <div key={`${point.time}-${index}`} style={{ flex: 1, minWidth: 1, height: `${Math.max(2, volume / maximum * 100)}%`, background: up ? "rgba(0,200,5,0.24)" : "rgba(255,70,58,0.22)" }} />;
        })}
      </div>
    )}
  </GraphFrame>;
}

function ComparisonDataWidget({ dataKey, ctx }: { dataKey: DataKey; ctx: GraphCtx }) {
  if (!ctx.comparisonStock) return null;
  const secondaryCtx: GraphCtx = { ...ctx, ...ctx.comparisonStock, comparisonStock: undefined };
  return (
    <div style={{ display: "flex", flexWrap: "wrap", alignItems: "center", gap: 8, width: "100%" }}>
      <DataPill dataKey={dataKey} ctx={ctx} identityColor={COMPARISON_COLORS.primary} symbol={ctx.stock.symbol} />
      <DataPill dataKey={dataKey} ctx={secondaryCtx} identityColor={COMPARISON_COLORS.secondary} symbol={ctx.comparisonStock.stock.symbol} />
    </div>
  );
}

function ComparisonPriceGraph({ ctx, period, annotations }: { ctx: GraphCtx; period: string; annotations?: Annotation[] }) {
  const secondary = ctx.comparisonStock;
  const [rows, setRows] = useState<ComparisonRow[]>([]);
  const [ready, setReady] = useState(false);
  const [failed, setFailed] = useState(false);
  const [hoveredRow, setHoveredRow] = useState<ComparisonRow | null>(null);
  useEffect(() => {
    if (!secondary) return;
    const controller = new AbortController();
    setReady(false);
    setFailed(false);
    setRows([]);
    setHoveredRow(null);
    const load = async () => {
      try {
        const fetchPeriod = async (symbol: string) => {
          const response = await fetch(`/api/candles?symbol=${encodeURIComponent(symbol)}&period=${period}`, { signal: controller.signal });
          const data = await response.json() as { candles?: CandlePoint[] };
          if (!response.ok) throw new Error("Unable to load comparison candles");
          return data.candles ?? [];
        };
        const [primaryCandles, secondaryCandles] = await Promise.all([fetchPeriod(ctx.stock.symbol), fetchPeriod(secondary.stock.symbol)]);
        if (controller.signal.aborted) return;
        const merged = mergeComparisonCandles(primaryCandles, secondaryCandles);
        setRows(merged);
        setFailed(!merged.length);
      } catch {
        if (!controller.signal.aborted) setFailed(true);
      } finally {
        if (!controller.signal.aborted) setReady(true);
      }
    };
    load();
    return () => controller.abort();
  }, [ctx.stock.symbol, secondary?.stock.symbol, period]);

  if (!secondary) return null;
  const active = hoveredRow ?? rows[rows.length - 1] ?? null;
  const winnerIsPrimary = active ? active.aPct >= active.bPct : true;
  const vals = rows.flatMap(row => [row.aPct, row.bPct]);
  const low = Math.min(0, ...vals), high = Math.max(0, ...vals);
  const padding = Math.max((high - low) * 0.06, 0.5);
  const domain: [number, number] = [low - padding, high + padding];
  const periodLabel: Record<string, string> = { "1D": "Today", "1W": "1 Week", "1M": "1 Month", "3M": "3 Months", "5M": "5 Months", "6M": "6 Months", "1Y": "1 Year", "2Y": "2 Years", "5Y": "5 Years", ALL: "All Time" };
  const nearestRow = (date: string) => {
    const target = Date.parse(date);
    if (!Number.isFinite(target) || !rows.length) return null;
    return rows.reduce((nearest, row) => Math.abs(row.time * 1000 - target) < Math.abs(nearest.time * 1000 - target) ? row : nearest, rows[0]);
  };
  const seriesBase = (series: "primary" | "secondary") => series === "secondary" ? rows[0]?.bPrice : rows[0]?.aPrice;
  return <div style={{ width: "100%", maxWidth: "100%" }}>
    <div style={{ marginBottom: 8, display: "flex", flexDirection: "column", gap: 4 }}>
      <p className="min-w-0 truncate text-4xl font-semibold tracking-normal text-purple-400">{ctx.stock.profile.name ?? ctx.stock.symbol}</p>
      <p className="min-w-0 truncate text-4xl font-semibold tracking-normal text-orange-400">{secondary.stock.profile.name ?? secondary.stock.symbol}</p>
    </div>
    {ready && active && <>
      <div className="mb-1 flex items-end gap-3">
        {([
          { series: winnerIsPrimary ? "a" : "b", value: winnerIsPrimary ? active.aPct : active.bPct, large: true },
          { series: winnerIsPrimary ? "b" : "a", value: winnerIsPrimary ? active.bPct : active.aPct, large: false },
        ] as const).map(({ series, value, large }) => (
          <motion.div key={series} layout initial={false} transition={{ layout: { duration: 0.34, ease: [0.22, 1, 0.36, 1] } }} className="flex items-end">
            <WheelPrice value={formatPercent(value)} size={large ? "lg" : "sm"} colorClass={series === "a"
              ? large ? "text-purple-400 transition-colors duration-300" : "text-purple-400/50 transition-colors duration-300"
              : large ? "text-orange-400 transition-colors duration-300" : "text-orange-400/50 transition-colors duration-300"} />
          </motion.div>
        ))}
      </div>
      <p className="mb-2 text-sm text-text-muted">{tooltipLabel(active.date, period as ChartPeriod)}</p>
    </>}
    <GraphFrame ready={ready} tall={!!annotations?.length}>
      {failed || !rows.length ? <div style={{ display: "flex", alignItems: "center", height: "100%", color: "#9a9aa2", fontSize: 13 }}>Comparison price history unavailable.</div> : (
        <div className="comparison-stock-chart h-full w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={rows} margin={{ top: annotations?.length ? 14 : 4, right: 4, bottom: 0, left: 4 }} onMouseMove={(state: unknown) => {
              const index = (state as { activeTooltipIndex?: number })?.activeTooltipIndex;
              setHoveredRow(index === undefined ? null : rows[Number(index)] ?? null);
            }} onMouseLeave={() => setHoveredRow(null)}>
              <XAxis dataKey="date" hide />
              <YAxis type="number" domain={domain} hide />
              <Tooltip content={() => null} cursor={{ stroke: "rgba(128,128,128,0.5)", strokeWidth: 1 }} />
              <ReferenceLine y={0} stroke="rgba(150,150,150,0.55)" strokeDasharray="4 4" />
              <Line className="comparison-series-a" type="monotone" dataKey="aPct" stroke={COMPARISON_COLORS.primary} strokeWidth={2.5} dot={false} isAnimationActive={false} activeDot={(rawProps: unknown) => {
                const props = rawProps as { cx?: number; cy?: number; payload?: ComparisonRow };
                if (props.cx == null || props.cy == null || !props.payload || props.payload.aPct < props.payload.bPct) return <g />;
                return <circle cx={props.cx} cy={props.cy} r={5} fill={COMPARISON_COLORS.primary} stroke="#000" strokeWidth={2} />;
              }} />
              <Line className="comparison-series-b" type="monotone" dataKey="bPct" stroke={COMPARISON_COLORS.secondary} strokeWidth={2.5} dot={false} isAnimationActive={false} activeDot={(rawProps: unknown) => {
                const props = rawProps as { cx?: number; cy?: number; payload?: ComparisonRow };
                if (props.cx == null || props.cy == null || !props.payload || props.payload.bPct <= props.payload.aPct) return <g />;
                return <circle cx={props.cx} cy={props.cy} r={5} fill={COMPARISON_COLORS.secondary} stroke="#000" strokeWidth={2} />;
              }} />
              {annotations?.filter((item): item is RegionAnnotation => item.type === "region").map((item, index) => {
                const start = nearestRow(item.start), end = nearestRow(item.end);
                if (!start || !end) return null;
                const color = ANNOTATION_COLOR[item.tone];
                return <ReferenceArea key={`compare-region-${index}`} x1={start.date} x2={end.date} fill={color} fillOpacity={0.12} stroke={color} strokeOpacity={0.3} label={{ value: item.label, position: "insideTop", fontSize: 9, fontWeight: 600, fill: color }} />;
              })}
              {annotations?.filter((item): item is LevelAnnotation => item.type === "level").map((item, index) => {
                const base = seriesBase(item.series ?? "primary");
                if (!base) return null;
                const levelPct = (item.price / base - 1) * 100;
                const color = item.levelType === "support" ? "#00c805" : item.levelType === "resistance" ? "#ff3003" : "#9a9aa2";
                return <ReferenceLine key={`compare-level-${index}`} y={levelPct} stroke={color} strokeDasharray="4 3" label={{ value: item.label, position: "insideTopRight", fontSize: 9, fill: color }} />;
              })}
              {annotations?.filter((item): item is MarkAnnotation => item.type === "mark").map((item, index) => {
                const row = nearestRow(item.date);
                const series = item.series ?? "primary";
                if (!row) return null;
                const base = seriesBase(series);
                if (!base) return null;
                const y = (item.price / base - 1) * 100;
                return <ReferenceDot key={`compare-mark-${index}`} x={row.date} y={y} r={3.5} fill={MARK_COLOR} stroke={ctx.isLightMode ? "#fff" : "#000"} strokeWidth={1.5} label={markLabelRenderer(item.label, "right", y > (domain[0] + domain[1]) / 2 ? "below" : "above")} />;
              })}
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}
    </GraphFrame>
  </div>;
}

type ComparisonFilingPoint = { year: number; capex: number | null; researchAndDevelopment: number | null; freeCashFlow: number | null };
type ComparisonFilingField = "capex" | "researchAndDevelopment" | "freeCashFlow";

function ComparisonFilingGraph({ ctx, title, field }: { ctx: GraphCtx; title: string; field: ComparisonFilingField }) {
  const secondary = ctx.comparisonStock;
  const [primaryRows, setPrimaryRows] = useState<ComparisonFilingPoint[]>([]);
  const [secondaryRows, setSecondaryRows] = useState<ComparisonFilingPoint[]>([]);
  const [ready, setReady] = useState(false);
  const [hovered, setHovered] = useState<{ year: number; series: "primary" | "secondary"; value: number } | null>(null);
  useEffect(() => {
    if (!secondary) return;
    const controller = new AbortController();
    setReady(false);
    setHovered(null);
    const fetchIndicators = (symbol: string) => fetch(`/api/filing-indicators?symbol=${encodeURIComponent(symbol)}`, { signal: controller.signal })
      .then(response => response.ok ? response.json() as Promise<{ indicators?: ComparisonFilingPoint[] }> : { indicators: [] })
      .then(data => data.indicators ?? []);
    Promise.all([fetchIndicators(ctx.stock.symbol), fetchIndicators(secondary.stock.symbol)]).then(([a, b]) => {
      if (!controller.signal.aborted) { setPrimaryRows(a); setSecondaryRows(b); }
    }).catch(() => {
      if (!controller.signal.aborted) { setPrimaryRows([]); setSecondaryRows([]); }
    }).finally(() => { if (!controller.signal.aborted) setReady(true); });
    return () => controller.abort();
  }, [ctx.stock.symbol, secondary?.stock.symbol]);
  if (!secondary) return null;
  const years = [...new Set([...primaryRows, ...secondaryRows].map(item => item.year))].sort((a, b) => a - b);
  const pairs = years.map(year => ({ year, a: primaryRows.find(item => item.year === year)?.[field] ?? null, b: secondaryRows.find(item => item.year === year)?.[field] ?? null }));
  const values = pairs.flatMap(pair => [pair.a, pair.b]).filter((value): value is number => value !== null);
  const maximum = Math.max(1, ...values.map(value => Math.abs(value)));
  const hasNegative = values.some(value => value < 0);
  const baseline = hasNegative ? 45 : 14;
  const latestA = [...pairs].reverse().find(pair => pair.a !== null)?.a ?? null;
  const display = hovered ?? (latestA === null ? null : { year: pairs[pairs.length - 1]?.year ?? 0, series: "primary" as const, value: latestA });
  if (!ready || !years.length || values.length === 0) return null;
  const displayedColor = display?.series === "secondary" ? "text-orange-400" : "text-purple-400";
  return <section className="rounded-xl bg-transparent p-5">
    <p className="mb-3 text-sm font-semibold uppercase tracking-[0.18em] text-accent">{title}</p>
    <div className="mb-5 text-text-primary">
      <WheelPrice value={display ? `$${formatCompact(display.value)}` : "N/A"} size="xs" compact colorClass={displayedColor} />
    </div>
    <div className="relative h-64 border-y border-border-subtle">
      <div className="absolute inset-x-0 border-t border-border-subtle" style={hasNegative ? { top: `${baseline}%` } : { bottom: `${baseline}%` }} />
      <div className="flex h-full">
        {pairs.map(pair => <div key={pair.year} className="relative min-w-0 flex-1 border-l border-border-subtle first:border-l-0">
          {([ ["primary", pair.a, COMPARISON_COLORS.primary], ["secondary", pair.b, COMPARISON_COLORS.secondary] ] as const).map(([series, value, color]) => {
            if (value === null) return null;
            const height = Math.max((Math.abs(value) / maximum) * 100 * (hasNegative ? 0.4 : 0.78), 3);
            const negative = value < 0;
            return <div key={series} className="absolute w-1/4 max-w-5 -translate-x-1/2 rounded-sm" style={{ left: series === "primary" ? "35%" : "65%", ...(negative ? { top: `${baseline}%` } : { bottom: hasNegative ? "55%" : `${baseline}%` }), height: `${height}%`, backgroundColor: color, boxShadow: series === "primary" ? "0 0 10px rgba(168, 85, 247, 0.55)" : "0 0 10px rgba(249, 115, 22, 0.55)" }} title={`${pair.year}: ${formatCurrency(value)}`} onMouseEnter={() => setHovered({ year: pair.year, series, value })} onMouseLeave={() => setHovered(null)} />;
          })}
          <span className="absolute bottom-1 left-1/2 -translate-x-1/2 text-[10px] font-semibold text-text-muted">{pair.year}</span>
        </div>)}
      </div>
    </div>
  </section>;
}

function EarningsCalendarWidget({ ctx }: { ctx: GraphCtx }) {
  const earnings = ctx.stock.earnings;
  const report = getNextReport(earnings) ?? [...earnings].sort((a, b) => b.date.localeCompare(a.date))[0] ?? null;
  const [year, month] = (report?.date ?? todayStr()).split("-").map(Number);
  const monthDate = new Date(year, month - 1, 1);
  const monthLabel = new Intl.DateTimeFormat("en-US", { month: "long" }).format(monthDate);
  const daysInMonth = new Date(year, month, 0).getDate();
  const mondayFirstOffset = (monthDate.getDay() + 6) % 7;
  const cells: (number | null)[] = [
    ...Array(mondayFirstOffset).fill(null),
    ...Array.from({ length: daysInMonth }, (_, index) => index + 1),
  ];
  const today = todayStr();
  const reportDate = report?.date ?? "";

  return <div aria-label={`${ctx.stock.symbol} earnings calendar for ${monthLabel}`} className="w-full max-w-[300px] rounded-3xl border p-5" style={{ borderColor: "rgba(145,150,150,0.62)", background: "transparent", boxShadow: "0 0 12px rgba(145,150,150,0.2), inset 0 0 8px rgba(145,150,150,0.05)" }}>
    <p className="mb-3 text-left text-xs font-bold uppercase tracking-widest" style={{ color: "var(--color-accent)" }}>{monthLabel}</p>
    <div className="grid grid-cols-7 gap-y-0.5">
      {["M", "T", "W", "T", "F", "S", "S"].map((weekday, index) => <p key={index} className="text-center text-[10px] font-bold uppercase text-text-muted">{weekday}</p>)}
      {cells.map((day, index) => {
        if (day === null) return <div key={`blank-${index}`} className="h-7" />;
        const date = `${year}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
        const isToday = date === today;
        const isPast = date < today;
        const isReportDate = date === reportDate;
        return <div key={date} className="flex h-7 items-center justify-center">
          {isReportDate ? (
            <span title={`Q${report?.quarter} ${report?.year} report date`} className="flex h-5 w-5 items-center justify-center rounded-full bg-accent text-xs font-bold text-on-accent">{day}</span>
          ) : (
            <span className={`text-xs font-bold ${isToday ? "text-accent" : isPast ? "text-text-muted" : "text-text-primary"}`}>{day}</span>
          )}
        </div>;
      })}
    </div>
  </div>;
}

function GraphWidget({ graphType, annotations, ctx }: { graphType: GraphType; annotations?: Annotation[]; ctx: GraphCtx }) {
  if (graphType.startsWith("comparePrice:")) return <ComparisonPriceGraph ctx={ctx} period={graphType.split(":")[1] ?? "1M"} annotations={annotations} />;
  if (graphType.startsWith("compareData:")) return <ComparisonDataWidget ctx={ctx} dataKey={graphType.split(":")[1] as DataKey} />;
  if (graphType === "compareGraph:capex") return <ComparisonFilingGraph ctx={ctx} title="CapEx Comparison" field="capex" />;
  if (graphType === "compareGraph:rnd") return <ComparisonFilingGraph ctx={ctx} title="R&D Comparison" field="researchAndDevelopment" />;
  if (graphType === "compareGraph:freeCashFlow") return <ComparisonFilingGraph ctx={ctx} title="Free Cash Flow Comparison" field="freeCashFlow" />;
  if (graphType.startsWith("price")) {
    const period = graphType.includes(":") ? graphType.split(":")[1] : "1M";
    return <GraphPrice ctx={ctx} period={period} annotations={annotations} />;
  }
  switch (graphType) {
    case "ma7": return <GraphPrice ctx={ctx} period="1Y" maWindow={7} />;
    case "ma25": return <GraphPrice ctx={ctx} period="1Y" maWindow={25} />;
    case "ma99": return <GraphPrice ctx={ctx} period="1Y" maWindow={99} />;
    case "volume": return <GraphVolume ctx={ctx} />;
    case "capex": return <GraphFilingMetric ctx={ctx} title="CapEx" field="capex" />;
    case "rnd": return <GraphFilingMetric ctx={ctx} title="R&D" field="researchAndDevelopment" />;
    case "freeCashFlow": return <GraphFilingMetric ctx={ctx} title="Free Cash Flow" field="freeCashFlow" />;
    case "earnings": return <GraphEarningsMetric ctx={ctx} metric="revenue" title="Earnings (Revenue)" />;
    case "eps": return <GraphEarningsMetric ctx={ctx} metric="eps" title="EPS" />;
    case "analyst":   return <GraphAnalyst ctx={ctx} />;
    case "sentiment": return <GraphSentiment ctx={ctx} />;
    case "targets":   return <GraphTargets ctx={ctx} />;
    case "calendar":  return <EarningsCalendarWidget ctx={ctx} />;
    default:          return null;
  }
}

function Cursor() {
  return (
    <span className="ai-stream-cursor" style={{
      display: "inline-block",
      width: "2px",
      height: "1em",
      marginLeft: "2px",
      verticalAlign: "text-bottom",
      borderRadius: "1px",
    }} />
  );
}

// Renders a parsed message: text runs flow normally, pills/graphs each get
// their own block so any text written after them appears underneath.
function MessageSegments({ segments, ctx, trailingCursor }: { segments: Segment[]; ctx: GraphCtx; trailingCursor: boolean }) {
  const cleaned = segments.filter(s => s.kind !== "text" || s.value.length > 0);
  if (cleaned.length === 0) return trailingCursor ? <Cursor /> : null;
  const arranged: Array<Segment | { kind: "news-row"; indexes: number[] }> = [];
  for (let index = 0; index < cleaned.length; index += 1) {
    const segment = cleaned[index];
    if (segment.kind !== "news") {
      arranged.push(segment);
      continue;
    }
    const indexes = [segment.index];
    while (index + 2 < cleaned.length) {
      const separator = cleaned[index + 1];
      const next = cleaned[index + 2];
      if (separator.kind !== "text" || separator.value.trim() || next.kind !== "news") break;
      indexes.push(next.index);
      index += 2;
    }
    arranged.push(indexes.length > 1 ? { kind: "news-row", indexes } : segment);
  }
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
      {arranged.map((seg, i) => {
        const isLast = i === arranged.length - 1;
        if (seg.kind === "text") {
          return (
            <span key={i}>
              <ColorizedText text={seg.value} />
              {isLast && trailingCursor && <Cursor />}
            </span>
          );
        }
        if (seg.kind === "pill") {
          return (
            <div key={i}>
              <DataPill dataKey={seg.key} ctx={ctx} />
              {isLast && trailingCursor && <Cursor />}
            </div>
          );
        }
        if (seg.kind === "news-row") {
          return (
            <div key={i} className="my-2 grid w-full min-w-[240px] max-w-[400px] grid-cols-2 gap-2">
              {seg.indexes.map(index => <NewsCard key={index} index={index} ctx={ctx} />)}
              {isLast && trailingCursor && <Cursor />}
            </div>
          );
        }
        if (seg.kind === "news") {
          return (
            <div key={i}>
              <NewsCard index={seg.index} ctx={ctx} />
              {isLast && trailingCursor && <Cursor />}
            </div>
          );
        }
        return (
          <div key={i}>
            <GraphWidget graphType={seg.graphType} annotations={seg.annotations} ctx={ctx} />
            {isLast && trailingCursor && <Cursor />}
          </div>
        );
      })}
    </div>
  );
}

// Market hours helper (ET)
function getMarketInfo(): { isOpen: boolean; status: string; timeToEvent: string } {
  const now = new Date();
  const et = new Date(now.toLocaleString("en-US", { timeZone: "America/New_York" }));
  const day = et.getDay(); // 0=Sun,6=Sat
  const h = et.getHours(), m = et.getMinutes();
  const minOfDay = h * 60 + m;
  const openMin = 9 * 60 + 30;   // 9:30 AM ET
  const closeMin = 16 * 60;       // 4:00 PM ET
  const isWeekday = day >= 1 && day <= 5;
  const isOpen = isWeekday && minOfDay >= openMin && minOfDay < closeMin;

  function minsToHHMM(mins: number) {
    const hh = Math.floor(mins / 60), mm = mins % 60;
    return hh > 0 ? `${hh}h ${mm}m` : `${mm}m`;
  }

  let timeToEvent = "";
  if (isOpen) {
    timeToEvent = `closes in ${minsToHHMM(closeMin - minOfDay)}`;
  } else if (isWeekday && minOfDay < openMin) {
    timeToEvent = `opens in ${minsToHHMM(openMin - minOfDay)}`;
  } else {
    // Find next Monday (or next day) open
    const daysUntilMon = ((8 - day) % 7) || 7;
    const nextOpen = day === 6 ? 2 : day === 0 ? 1 : daysUntilMon;
    timeToEvent = `opens in ~${nextOpen} day${nextOpen > 1 ? "s" : ""}`;
  }
  return { isOpen, status: isOpen ? "Open" : "Closed", timeToEvent };
}

// Deterministic market statistics computed straight from candle data — the
// AI explains these, it never calculates them itself. Also gives the AI
// grounded, exact dates it can safely reference in [[mark:...]] tags.
function computeMarketStats(candles: CandlePoint[]): string | null {
  if (!candles || candles.length < 5) return null;

  const closes  = candles.map(c => c.close);
  const dates   = candles.map(c => c.date.slice(0, 10));
  const volumes = candles.map(c => c.volume ?? 0);
  const fmtPct  = (n: number) => `${n >= 0 ? "+" : ""}${n.toFixed(2)}%`;

  let largestGain = { pct: -Infinity, date: "" };
  let largestLoss = { pct: Infinity, date: "" };
  for (let i = 1; i < closes.length; i++) {
    const pct = (closes[i] - closes[i - 1]) / closes[i - 1] * 100;
    if (pct > largestGain.pct) largestGain = { pct, date: dates[i] };
    if (pct < largestLoss.pct) largestLoss = { pct, date: dates[i] };
  }

  let highestClose = { price: -Infinity, date: "" };
  let lowestClose   = { price: Infinity, date: "" };
  closes.forEach((c, i) => {
    if (c > highestClose.price) highestClose = { price: c, date: dates[i] };
    if (c < lowestClose.price)  lowestClose   = { price: c, date: dates[i] };
  });

  let highestVolume = { volume: -Infinity, date: "" };
  volumes.forEach((v, i) => { if (v > highestVolume.volume) highestVolume = { volume: v, date: dates[i] }; });
  const avgVolume = volumes.reduce((a, b) => a + b, 0) / volumes.length;

  const movingAvg = (n: number) => closes.length < n ? null : closes.slice(-n).reduce((a, b) => a + b, 0) / n;
  const ma20 = movingAvg(20);
  const ma50 = movingAvg(50);

  let peak = closes[0], maxDrawdown = 0;
  for (const c of closes) {
    if (c > peak) peak = c;
    maxDrawdown = Math.min(maxDrawdown, (c - peak) / peak * 100);
  }

  const percentReturn = (closes[closes.length - 1] - closes[0]) / closes[0] * 100;

  let trend: "Uptrend" | "Downtrend" | "Sideways" = "Sideways";
  if (ma20 !== null && ma50 !== null) {
    if (ma20 > ma50 * 1.01) trend = "Uptrend";
    else if (ma20 < ma50 * 0.99) trend = "Downtrend";
  }

  const periodHigh = Math.max(...closes);
  const periodLow  = Math.min(...closes);
  const lastClose  = closes[closes.length - 1];
  const distFromHigh = (lastClose - periodHigh) / periodHigh * 100;
  const distFromLow  = (lastClose - periodLow)  / periodLow  * 100;

  const tail = closes.slice(-21);
  const recentReturns: number[] = [];
  for (let i = 1; i < tail.length; i++) recentReturns.push((tail[i] - tail[i - 1]) / tail[i - 1] * 100);
  const meanRet = recentReturns.reduce((a, b) => a + b, 0) / (recentReturns.length || 1);
  const variance = recentReturns.reduce((a, b) => a + (b - meanRet) ** 2, 0) / (recentReturns.length || 1);
  const stdev = Math.sqrt(variance);

  const lines = [
    `Largest Daily Gain: ${fmtPct(largestGain.pct)} on ${largestGain.date}`,
    `Largest Daily Loss: ${fmtPct(largestLoss.pct)} on ${largestLoss.date}`,
    `Highest Close: $${highestClose.price.toFixed(2)} on ${highestClose.date}`,
    `Lowest Close: $${lowestClose.price.toFixed(2)} on ${lowestClose.date}`,
    highestVolume.volume > 0 ? `Highest Volume Day: ${(highestVolume.volume / 1_000_000).toFixed(1)}M shares on ${highestVolume.date}` : null,
    avgVolume > 0 ? `Average Volume: ${(avgVolume / 1_000_000).toFixed(1)}M shares/day` : null,
    ma20 !== null ? `20-Day Moving Average: $${ma20.toFixed(2)}` : null,
    ma50 !== null ? `50-Day Moving Average: $${ma50.toFixed(2)}` : null,
    `Max Drawdown: ${maxDrawdown.toFixed(2)}%`,
    `Current Trend: ${trend}`,
    `Percentage Return (over fetched period): ${fmtPct(percentReturn)}`,
    `Distance from Period High: ${fmtPct(distFromHigh)}`,
    `Distance from Period Low: ${fmtPct(distFromLow)}`,
    `Recent Volatility (20-day stdev of daily returns): ${stdev.toFixed(2)}%`,
  ].filter((l): l is string => l !== null);

  return lines.join("\n");
}

// Fetch key candle stats for a period (async, called server-side in context builder)
async function fetchPeriodStats(symbol: string, period: string): Promise<string | null> {
  try {
    const res = await fetch(`/api/candles?symbol=${encodeURIComponent(symbol)}&period=${period}`, { cache: "no-store" });
    const data = await res.json() as { candles?: { close: number; date: string }[] };
    const candles = data.candles;
    if (!candles || candles.length < 2) return null;
    const closes = candles.map(c => c.close);
    const dates = candles.map(c => c.date.slice(0, 10));
    const first = closes[0], last = closes[closes.length - 1];
    // Find the exact date of this period's high/low directly from its own
    // candle set — never borrow a date computed over a different period.
    let highIdx = 0, lowIdx = 0;
    closes.forEach((c, i) => {
      if (c > closes[highIdx]) highIdx = i;
      if (c < closes[lowIdx]) lowIdx = i;
    });
    const high = closes[highIdx], low = closes[lowIdx];
    const chg = ((last - first) / first * 100).toFixed(2);
    const sign = parseFloat(chg) >= 0 ? "+" : "";
    return `${period}: ${sign}${chg}% | High $${high.toFixed(2)} on ${dates[highIdx]} | Low $${low.toFixed(2)} on ${dates[lowIdx]} | Start $${first.toFixed(2)} | End $${last.toFixed(2)}`;
  } catch {
    return null;
  }
}

// Fetches a full year of daily candles so computeMarketStats has enough
// history for 50-day moving averages, drawdown, and 52-week distances.
async function fetchCandlesForStats(symbol: string): Promise<CandlePoint[] | null> {
  try {
    const res = await fetch(`/api/candles?symbol=${encodeURIComponent(symbol)}&period=1Y`, { cache: "no-store" });
    const data = await res.json() as { candles?: CandlePoint[] };
    return data.candles?.length ? data.candles : null;
  } catch {
    return null;
  }
}

const ARTICLE_EXTRACT_TIMEOUT_MS = 7000;
// How many of the most recent news items we bother fully fetching + reading
// (rather than just listing the headline/summary). Kept small since most
// financial news sites paywall or block scraping, and each attempt costs a
// full page fetch — cap the blast radius and let the rest fall back to the
// existing blurb.
const ARTICLES_TO_READ = 3;

// Server-side fetch + Readability extraction of one article's full text.
// Returns null on any failure (paywall, timeout, blocked, non-HTML, etc.)
// so the caller can silently fall back to the headline/summary blurb.
async function fetchArticleExtract(url: string): Promise<{ title: string | null; text: string } | null> {
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), ARTICLE_EXTRACT_TIMEOUT_MS);
    try {
      const res = await fetch(`/api/article-extract?url=${encodeURIComponent(url)}`, {
        cache: "no-store",
        signal: controller.signal,
      });
      if (!res.ok) return null;
      const data = await res.json() as { title?: string | null; text?: string; error?: string };
      if (!data.text) return null;
      return { title: data.title ?? null, text: data.text };
    } finally {
      clearTimeout(timeout);
    }
  } catch {
    return null;
  }
}

// buildStockContext now async so it can prefetch graph data
export async function buildStockContextAsync(
  stock: StockDetail,
  currentPrice: number,
  sentiment: { score: number; drivers: string[] },
  metrics: Record<string, number | string | null> | undefined,
  includeNews = true
): Promise<string> {
  const market = getMarketInfo();
  const now = new Date();

  const lines: string[] = [
    `Date/Time: ${now.toLocaleDateString("en-US", { weekday: "long", year: "numeric", month: "long", day: "numeric" })} ${now.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", timeZone: "America/New_York" })} ET`,
    `Market: ${market.status} (${market.timeToEvent})`,
    `Stock: ${stock.profile.name ?? stock.symbol} (${stock.symbol})`,
    `Exchange: ${stock.profile.exchange ?? "N/A"}`,
    `Industry: ${stock.profile.finnhubIndustry ?? "N/A"}`,
    `Current Price: $${currentPrice.toFixed(2)}`,
    `Day Change: ${stock.quote.dp?.toFixed(2) ?? "N/A"}%`,
    `Previous Close: $${stock.quote.pc?.toFixed(2) ?? "N/A"}`,
    `52W High: $${stock.quote.h?.toFixed(2) ?? "N/A"} | 52W Low: $${stock.quote.l?.toFixed(2) ?? "N/A"}`,
    `Sentiment Score: ${sentiment.score}/100 (${sentiment.drivers.join(", ")})`,
  ];

  if (metrics) {
    const ml = Object.entries(metrics).filter(([, v]) => v !== null).map(([k, v]) => `${k}: ${v}`);
    if (ml.length) lines.push(`Fundamentals: ${ml.join(" | ")}`);
  }
  const a = stock.recommendations?.[0];
  if (a) lines.push(`Analyst: Strong Buy ${a.strongBuy} | Buy ${a.buy} | Hold ${a.hold} | Sell ${a.sell} | Strong Sell ${a.strongSell}`);
  if (stock.priceTarget?.targetMean) lines.push(`Avg Price Target: $${stock.priceTarget.targetMean.toFixed(2)}`);

  const earningsBlock = formatEarningsForAIContext(stock.earnings);
  if (earningsBlock) lines.push(earningsBlock);

  // Fetch graph stats for key periods, a year of daily candles for
  // deterministic market statistics, and full article text for the most
  // recent news items — all in parallel so total wait time is bounded by
  // the slowest single fetch, not their sum.
  const periods = ["1D","1W","1M","3M","5M","6M","1Y","2Y","5Y","ALL"];
  const newsItems = includeNews ? stock.news?.slice(0, 8) ?? [] : [];
  const [stats, statsCandles, articleExtracts] = await Promise.all([
    Promise.all(periods.map(p => fetchPeriodStats(stock.symbol, p))),
    fetchCandlesForStats(stock.symbol),
    Promise.all(newsItems.slice(0, ARTICLES_TO_READ).map(n => n.url ? fetchArticleExtract(n.url) : null)),
  ]);
  const validStats = stats.filter(Boolean);
  if (validStats.length) lines.push(`Graph Data:\n${validStats.join("\n")}`);

  if (statsCandles) {
    const marketStats = computeMarketStats(statsCandles);
    if (marketStats) {
      lines.push(`Market Statistics — trailing 1 year only (already computed — cite these directly, do not recalculate; use these exact dates/prices for [[mark:...]] annotations). For questions scoped to a specific period (e.g. "last 5 months"), use that period's own line under Graph Data instead — it has the exact high/low dates for that exact window:\n${marketStats}`);
    }
  }

  if (newsItems.length) {
    const h = newsItems.map((n, i) => {
      const extract = articleExtracts[i];
      if (extract?.text) {
        return `[${i}] ${n.headline} (${n.source})\n    Full Article Text (extracted from the source page — you have actually read this one): ${extract.text}`;
      }
      return `[${i}] ${n.headline} (${n.source})${n.summary ? `\n    Summary only (full article was not readable — treat as a brief blurb, do not claim to have read the full piece): ${n.summary}` : ""}`;
    }).join("\n");
    lines.push(`Recent News (use [[news:INDEX]] to show one):\n${h}`);
  }
  return lines.join("\n");
}

function buildStockContext(
  stock: StockDetail,
  currentPrice: number,
  sentiment: { score: number; drivers: string[] },
  metrics: Record<string, number | string | null> | undefined,
  includeNews = true
): string {
  // Sync fallback used on first render — async version is fetched on open
  const market = getMarketInfo();
  const now = new Date();
  const lines: string[] = [
    `Date/Time: ${now.toLocaleDateString("en-US", { weekday: "long", year: "numeric", month: "long", day: "numeric" })} ${now.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", timeZone: "America/New_York" })} ET`,
    `Market: ${market.status} (${market.timeToEvent})`,
    `Stock: ${stock.profile.name ?? stock.symbol} (${stock.symbol})`,
    `Exchange: ${stock.profile.exchange ?? "N/A"}`,
    `Industry: ${stock.profile.finnhubIndustry ?? "N/A"}`,
    `Current Price: $${currentPrice.toFixed(2)}`,
    `Day Change: ${stock.quote.dp?.toFixed(2) ?? "N/A"}%`,
    `Previous Close: $${stock.quote.pc?.toFixed(2) ?? "N/A"}`,
    `52W High: $${stock.quote.h?.toFixed(2) ?? "N/A"} | 52W Low: $${stock.quote.l?.toFixed(2) ?? "N/A"}`,
    `Sentiment Score: ${sentiment.score}/100 (${sentiment.drivers.join(", ")})`,
  ];
  if (metrics) {
    const ml = Object.entries(metrics).filter(([, v]) => v !== null).map(([k, v]) => `${k}: ${v}`);
    if (ml.length) lines.push(`Fundamentals: ${ml.join(" | ")}`);
  }
  const a = stock.recommendations?.[0];
  if (a) lines.push(`Analyst: Strong Buy ${a.strongBuy} | Buy ${a.buy} | Hold ${a.hold} | Sell ${a.sell} | Strong Sell ${a.strongSell}`);
  if (stock.priceTarget?.targetMean) lines.push(`Avg Price Target: $${stock.priceTarget.targetMean.toFixed(2)}`);
  const earningsBlock = formatEarningsForAIContext(stock.earnings);
  if (earningsBlock) lines.push(earningsBlock);
  if (includeNews && stock.news?.length) {
    const h = stock.news.slice(0, 8).map((n, i) =>
      `[${i}] ${n.headline} (${n.source})${n.summary ? `\n    Summary: ${n.summary}` : ""}`
    ).join("\n");
    lines.push(`Recent News (use [[news:INDEX]] to show one):\n${h}`);
  }
  return lines.join("\n");
}

// Streams AI text character by character with an iridescent cursor.
// Widget tags ([[data:...]] / [[graph:...]]) only render once they've fully
// streamed in, then hold steady while the rest of the message keeps typing.
function AnimatedMessageBody({ text, ctx, onDone }: { text: string; ctx: GraphCtx; onDone: () => void }) {
  const [count, setCount] = useState(0);
  const isDone = count >= text.length;

  useEffect(() => {
    setCount(0);
    const iv = setInterval(() => {
      setCount(c => {
        if (c >= text.length) { clearInterval(iv); onDone(); return c; }
        return c + 1;
      });
    }, 6);
    return () => clearInterval(iv);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [text]);

  const slice = text.slice(0, count);
  const segments = parseSegments(slice);

  return <MessageSegments segments={segments} ctx={ctx} trailingCursor={!isDone} />;
}

function StaticMessageBody({ text, ctx }: { text: string; ctx: GraphCtx }) {
  const segments = parseSegments(text);
  return <MessageSegments segments={segments} ctx={ctx} trailingCursor={false} />;
}

interface Props {
  stock: StockDetail;
  currentPrice: number;
  sentiment: { score: number; drivers: string[] };
  metrics: Record<string, number | string | null> | undefined;
  /** Adds a second stock's data to the AI context without including either stock's news. */
  comparisonStock?: {
    stock: StockDetail;
    currentPrice: number;
    sentiment: { score: number; drivers: string[] };
    metrics: Record<string, number | string | null> | undefined;
  };
  /** If provided, open state is controlled externally (e.g. desktop's own button) instead of the built-in floating pill. */
  externalOpen?: boolean;
  onOpenChange?: (open: boolean) => void;
  /** Hide the built-in floating pill trigger — used when an external button opens the chat instead. */
  hideTrigger?: boolean;
  /**
   * Desktop watchlist split view: when provided, every bit of this
   * component that would otherwise measure the full browser window (the
   * blur backdrop, the message column, and the pill's expanded width)
   * measures this element's bounding box instead. Since this element is the
   * right-hand 3/4 detail column — flush with the right and bottom edges of
   * the window already — the same "expand from a small circle into a full
   * bar, blur what's behind it" animation plays exactly as it does on
   * mobile, just confined to that column instead of the whole screen, so it
   * never covers the 1/4 list on the left.
   */
  containerRef?: React.RefObject<HTMLElement | null>;
}

export function StockAIChat({ stock, currentPrice, sentiment, metrics, comparisonStock, externalOpen, onOpenChange, hideTrigger, containerRef }: Props) {
  const [mounted, setMounted] = useState(false);
  const [internalOpen, setInternalOpen] = useState(false);
  const isControlled = externalOpen !== undefined;
  const open = isControlled ? externalOpen : internalOpen;
  function setOpen(v: boolean) {
    if (isControlled) onOpenChange?.(v);
    else setInternalOpen(v);
  }
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput]       = useState("");
  const [loading, setLoading]   = useState(false);
  const [serverError, setServerError] = useState(false);
  const [vp, setVp] = useState({ top: 0, left: 0, width: 0, height: 0 });
  const scrollRef   = useRef<HTMLDivElement>(null);
  const inputRef    = useRef<HTMLInputElement>(null);
  const touchStart  = useRef<{ x: number; y: number; time: number } | null>(null);
  const welcomedStockRef = useRef<string | null>(null);
  const buildCurrentContext = async () => {
    if (!comparisonStock) {
      return buildStockContextAsync(stock, currentPrice, sentiment, metrics);
    }
    const [primary, secondary] = await Promise.all([
      buildStockContextAsync(stock, currentPrice, sentiment, metrics, false),
      buildStockContextAsync(comparisonStock.stock, comparisonStock.currentPrice, comparisonStock.sentiment, comparisonStock.metrics, false),
    ]);
    return `Comparison mode. Compare both stocks using the data below. News is intentionally omitted.\n\nStock 1 — ${stock.profile.name ?? stock.symbol} (${stock.symbol}):\n${primary}\n\nStock 2 — ${comparisonStock.stock.profile.name ?? comparisonStock.stock.symbol} (${comparisonStock.stock.symbol}):\n${secondary}`;
  };
  const buildCurrentContextFallback = () => comparisonStock
    ? `Comparison mode. Compare both stocks using the data below. News is intentionally omitted.\n\nStock 1 — ${stock.profile.name ?? stock.symbol} (${stock.symbol}):\n${buildStockContext(stock, currentPrice, sentiment, metrics, false)}\n\nStock 2 — ${comparisonStock.stock.profile.name ?? comparisonStock.stock.symbol} (${comparisonStock.stock.symbol}):\n${buildStockContext(comparisonStock.stock, comparisonStock.currentPrice, comparisonStock.sentiment, comparisonStock.metrics, false)}`
    : buildStockContext(stock, currentPrice, sentiment, metrics);
  const [stockContext, setStockContext] = useState(() => buildCurrentContextFallback());

  // Desktop reuses one long-lived instance of this component across every
  // stock the user selects in the split view (mobile instead mounts a fresh
  // page/instance per stock, so this never ran there before). Reset the
  // conversation whenever the underlying stock changes; leave `open` alone
  // so the panel doesn't slam shut just because the user picked a new row.
  useEffect(() => {
    setMessages([]);
    setInput("");
    setServerError(false);
    setStockContext(buildCurrentContextFallback());
    if (open) {
      let active = true;
      buildCurrentContext().then(ctx => { if (active) setStockContext(ctx); });
      return () => { active = false; };
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [stock.symbol, comparisonStock?.stock.symbol]);

  // On first open, fetch full context with graph data (async)
  useEffect(() => {
    if (!open) return;
    let active = true;
    buildCurrentContext().then(ctx => { if (active) setStockContext(ctx); });
    return () => { active = false; };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, stock.symbol, comparisonStock?.stock.symbol]);

  useEffect(() => {
    if (!open || welcomedStockRef.current === stock.symbol) return;
    setLoading(true);
    const timer = window.setTimeout(() => {
      setMessages([{ role: "model", text: getRandomAIWelcome(), animating: true }]);
      setLoading(false);
      welcomedStockRef.current = stock.symbol;
    }, 500);
    return () => {
      window.clearTimeout(timer);
      setLoading(false);
    };
  }, [open, stock.symbol]);
  const isLightMode = typeof document !== "undefined" && document.documentElement.classList.contains("light-mode");
  const graphCtx: GraphCtx = { stock, currentPrice, sentiment, metrics, comparisonStock, isLightMode };

  // Render via a portal straight into <body> — bypasses ancestor elements
  // (like <main>) that can pick up a transient CSS `transform` from page
  // transition animations. A transformed ancestor becomes a new containing
  // block for any `position: fixed` descendant, which silently breaks fixed
  // positioning. Portaling to <body> guarantees this can never happen, the
  // same way the always-reliable search button lives outside <main> too.
  useEffect(() => setMounted(true), []);

  // Track visual viewport — only needed on mobile (iOS keyboard shrinking).
  // On desktop (width >= 1024) skip entirely to avoid unnecessary rerenders.
  // When `containerRef` is given (desktop split view), track THAT element's
  // box instead of the window — this is what confines the whole chat
  // experience (backdrop, messages, and the pill's expanded width below) to
  // the 3/4 detail column instead of the full browser width.
  useEffect(() => {
    function update() {
      if (containerRef?.current) {
        const rect = containerRef.current.getBoundingClientRect();
        setVp({ top: rect.top, left: rect.left, width: rect.width, height: rect.height });
        return;
      }
      if (window.innerWidth >= 1024) {
        // Desktop: use simple full-window dimensions, no polling needed
        setVp({ top: 0, left: 0, width: window.innerWidth, height: window.innerHeight });
        return;
      }
      const vv = window.visualViewport;
      setVp(vv
        ? { top: vv.offsetTop, left: vv.offsetLeft, width: vv.width, height: vv.height }
        : { top: 0, left: 0, width: window.innerWidth, height: window.innerHeight }
      );
    }
    update();
    if (containerRef?.current) {
      const ro = new ResizeObserver(update);
      ro.observe(containerRef.current);
      window.addEventListener("resize", update);
      return () => {
        ro.disconnect();
        window.removeEventListener("resize", update);
      };
    }
    // Only attach expensive visualViewport listeners on mobile
    if (window.innerWidth < 1024) {
      window.visualViewport?.addEventListener("resize", update);
      window.visualViewport?.addEventListener("scroll", update);
    }
    window.addEventListener("resize", update);
    return () => {
      window.visualViewport?.removeEventListener("resize", update);
      window.visualViewport?.removeEventListener("scroll", update);
      window.removeEventListener("resize", update);
    };
  }, [containerRef]);

  // Lock body scroll (without jumping to top) only while chat is open
  useEffect(() => {
    if (!open) return;
    const scrollY = window.scrollY;
    const b = document.body;
    b.style.overflow = "hidden";
    b.style.position = "fixed";
    b.style.top      = `-${scrollY}px`;
    b.style.left     = "0";
    b.style.right    = "0";
    const t = setTimeout(() => inputRef.current?.focus(), 340);
    return () => {
      clearTimeout(t);
      b.style.overflow = b.style.position = b.style.top = b.style.left = b.style.right = "";
      window.scrollTo(0, scrollY);
    };
  }, [open]);

  useEffect(() => {
    if (scrollRef.current)
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages, loading, open]);

  function handleDismiss() {
    setOpen(false);
  }

  async function sendMessage() {
    const text = input.trim();
    if (!text || loading) return;
    setInput("");
    const newMessages: Message[] = [...messages, { role: "user", text }];
    setMessages(newMessages);
    setLoading(true);
    setServerError(false);
    try {
      const reply = await requestAIChat({ messages: newMessages.map(m => ({ role: m.role, text: m.text })), stockContext });
      setMessages(prev => [...prev, { role: "model", text: reply, animating: true }]);
    } catch {
      setServerError(true);
    } finally {
      setLoading(false);
    }
  }

  function markDone(i: number) {
    setMessages(prev => prev.map((m, idx) => idx === i ? { ...m, animating: false } : m));
  }

  // Tap-to-dismiss on empty space: a quick tap (not a scroll/drag) that lands
  // directly on the blank scroll area — not on a message bubble — closes the
  // chat, same as tapping the backdrop above it.
  function onEmptyAreaTouchStart(e: React.TouchEvent) {
    if (e.target !== e.currentTarget) { touchStart.current = null; return; }
    touchStart.current = { x: e.touches[0].clientX, y: e.touches[0].clientY, time: Date.now() };
  }
  function onEmptyAreaTouchEnd(e: React.TouchEvent) {
    if (!touchStart.current) return;
    const dx = Math.abs(e.changedTouches[0].clientX - touchStart.current.x);
    const dy = Math.abs(e.changedTouches[0].clientY - touchStart.current.y);
    const dt = Date.now() - touchStart.current.time;
    if (dx < 8 && dy < 8 && dt < 300) handleDismiss();
    touchStart.current = null;
  }
  function onEmptyAreaClick(e: React.MouseEvent) {
    if (e.target === e.currentTarget) handleDismiss();
  }

  const bgBubbleAI = "linear-gradient(145deg, rgba(8,20,20,0.48), rgba(5,15,15,0.62) 56%, rgba(3,10,10,0.54))";
  const chatControlGlass = "linear-gradient(145deg, rgba(8,20,20,0.48), rgba(5,15,15,0.62) 56%, rgba(3,10,10,0.54))";
  const bubbleBorderUser = "rgba(255,255,255,0.16)";
  const bubbleBorderAI   = "rgba(255,255,255,0.16)";
  const bubbleGlowAI     = "0 24px 60px rgba(0,0,0,0.24), 0 5px 18px rgba(0,0,0,0.12), inset 0 0 16px rgba(0,0,0,0.18)";
  const textColor     = "rgba(245,248,248,0.94)";

  const vpW = vp.width  || (typeof window !== "undefined" ? window.innerWidth  : 0);
  const vpH = vp.height || (typeof window !== "undefined" ? window.innerHeight : 0);

  // How much the keyboard (or Safari's chrome) is eating into the screen —
  // used to keep the pill glued just above it instead of drifting/getting covered.
  const winH = typeof window !== "undefined" ? window.innerHeight : 0;
  const keyboardInset = Math.max(0, winH - vpH - vp.top);
  const isDesktop = typeof window !== "undefined" && window.innerWidth >= 1024;
  const pillBottom = isDesktop
    ? "1.5rem"
    : open && keyboardInset > 8
      ? `${keyboardInset + 12}px`
      : "calc(env(safe-area-inset-bottom) - 0.5rem)";
  // Expanded pill width: the full container width (minus side margins) when
  // confined to the desktop split view's detail column, otherwise the full
  // viewport width as before on mobile.
  const pillOpenWidth = containerRef?.current ? `${Math.max(0, vp.width - 32)}px` : "calc(100vw - 2rem)";

  if (!mounted) return null;

  // This specific instance only exists in the desktop watchlist split view
  // (that's the only caller that passes `containerRef`). It's rendered via
  // createPortal straight into <body>, which means it completely ignores
  // whatever CSS (e.g. the "hidden lg:block" wrapper around its React
  // ancestor) is trying to hide it with — a portal's output isn't actually
  // inside that hidden DOM subtree, so the ancestor's `display: none` never
  // reaches it. That's why the pill was showing up on phone even though the
  // component that renders it is only meant to exist on desktop. Bailing
  // out here, in JS, based on the real viewport width, is what actually
  // prevents it from mounting anything at all on a narrow screen.
  if (containerRef && !isDesktop) return null;

  return createPortal(
    <>
      {containerRef && <div
        aria-hidden="true"
        style={{
          position: "fixed", inset: 0, zIndex: 999,
          background: open ? "rgba(0,0,0,0.16)" : "transparent",
          backdropFilter: open ? "blur(12px) brightness(0.97)" : "none",
          WebkitBackdropFilter: open ? "blur(12px) brightness(0.97)" : "none",
          pointerEvents: open ? "auto" : "none",
          opacity: open ? 1 : 0,
          transition: "opacity 0.25s ease",
        }}
        onClick={handleDismiss}
      />}
      {/* Backdrop + messages — pinned to the exact visual viewport rectangle */}
      <div
        style={{
          position: "fixed",
          top: vp.top, left: vp.left, width: vpW, height: vpH,
          zIndex: 1000,
          opacity: open ? 1 : 0,
          pointerEvents: open ? "auto" : "none",
          transition: "opacity 0.25s ease",
        }}
      >
        <div
          style={{
            position: "absolute", inset: 0,
            zIndex: 0,
            background: open && !containerRef ? "rgba(0,0,0,0.16)" : "transparent",
            transform: "translateZ(0)",
            WebkitTransform: "translateZ(0)",
            
          }}
          onClick={handleDismiss}
        />

        {/* Messages occupy the full overlay. Padding reserves comfortable
            resting room for the app edge and input pill, but does not create
            invisible clipping strips above or below the conversation. */}
        <div
          ref={scrollRef}
          className="ai-chat-messages"
          style={{
            position: "absolute",
            zIndex: 1,
            left: 0, right: 0,
            top: 0,
            bottom: 0,
            overflowY: "auto",
            overscrollBehavior: "contain",
            WebkitOverflowScrolling: "touch",
            touchAction: "pan-y",
            display: "flex",
            flexDirection: "column",
            // A bottom-justified flex scroll container lets overflowing
            // messages escape above its scroll range. Start at the top so
            // the complete conversation stays reachable by scrolling.
            justifyContent: "flex-start",
            minHeight: 0,
            gap: 12,
            padding: "64px 14px 112px",
          }}
          onClick={onEmptyAreaClick}
          onWheel={(event) => event.stopPropagation()}
          onTouchStart={onEmptyAreaTouchStart}
          onTouchEnd={onEmptyAreaTouchEnd}
        >
          {messages.map((msg, i) => (
            <div key={i} style={{ display: "flex", justifyContent: msg.role === "user" ? "flex-end" : "flex-start" }}>
              <div className={`smoked-glass-surface${msg.role === "model" ? " ai-response-bubble" : ""}`} style={{
                maxWidth: "86%",
                wordBreak: "break-word",
                whiteSpace: "pre-wrap",
                padding: "12px 18px",
                borderRadius: 24,
                background: bgBubbleAI,
                border: `1px solid ${msg.role === "model" ? "var(--color-accent)" : bubbleBorderUser}`,
                color: textColor,
                fontSize: 17,
                lineHeight: 1.55,
                fontWeight: msg.role === "user" ? 500 : 400,
              }}>
                {msg.role === "model" && msg.animating
                  ? <AnimatedMessageBody text={msg.text} ctx={graphCtx} onDone={() => markDone(i)} />
                  : msg.role === "model"
                    ? <StaticMessageBody text={msg.text} ctx={graphCtx} />
                    : msg.text}
              </div>
            </div>
          ))}

          {serverError && <AIUnavailableNotice />}

          {loading && (
            <div style={{ display: "flex", justifyContent: "flex-start" }}>
              <div className={`smoked-glass-surface ai-response-bubble${loading ? " ai-thinking" : ""}`} style={{
                padding: "14px 18px",
                borderRadius: 24,
                background: bgBubbleAI,
                border: "1px solid var(--color-accent)",
                display: "flex", alignItems: "center",
              }}>
                <AIStarLoader size="md" />
              </div>
            </div>
          )}
        </div>
      </div>

      {/* The pill — always mounted, same element morphs from a small circle
          (matching the search button exactly) into the full input bar. No
          separate bar/card behind it — this IS the input, elongated. */}
      {!hideTrigger && (
      <div
          className={`smoked-glass-surface${open ? " ai-chat-panel" : ""} fixed rounded-full border border-transparent text-accent overflow-hidden${loading ? " ai-thinking" : ""}`}
        style={{
          zIndex: 1002,
          bottom: pillBottom,
          right: open ? "1rem" : "1.25rem",
          width: open ? pillOpenWidth : "3.5rem",
          height: "3.5rem",
          background: chatControlGlass,
          transition: "width 0.32s cubic-bezier(0.2,0,0,1), right 0.32s cubic-bezier(0.2,0,0,1), bottom 0.2s ease",
        }}
      >
        {/* Closed state: the trigger icon */}
        <button
          className="ai-aberration rounded-full"
          onClick={() => setOpen(true)}
          aria-label="Ask AI"
          style={{
            position: "absolute", inset: 0,
            display: "flex", alignItems: "center", justifyContent: "center",
            opacity: open ? 0 : 1,
            pointerEvents: open ? "none" : "auto",
            transition: "opacity 0.16s ease",
          }}
        >
          <OptionalSvgIcon name="ai" className="ai-button-icon absolute left-1/2 top-1/2 h-8 w-8 -translate-x-1/2 -translate-y-1/2" />
        </button>

        {/* Open state: the actual input row */}
        <div
          style={{
            position: "absolute", inset: 0,
            display: "flex", alignItems: "center", gap: 8,
            padding: "0 8px 0 20px",
            opacity: open ? 1 : 0,
            pointerEvents: open ? "auto" : "none",
            transition: "opacity 0.22s ease",
            transitionDelay: open ? "0.14s" : "0s",
          }}
        >
          <input
            ref={inputRef}
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); } }}
            placeholder={`Ask about ${stock.symbol}…`}
            className="text-white placeholder:text-white/45"
            style={{
              flex: 1,
              background: "transparent",
              border: "none",
              outline: "none",
              fontSize: 16,
              color: textColor,
              caretColor: "var(--color-accent)",
            }}
          />
          {input.trim() ? (
            <button
              onClick={sendMessage}
              disabled={loading}
              className="ai-send-button-glow"
              style={{
                flexShrink: 0, height: 38, width: 38,
                borderRadius: "50%",
                backgroundColor: !loading ? "var(--color-accent)" : "rgb(var(--accent-rgb) / 0.18)",
                color: !loading ? "var(--color-on-accent)" : "rgb(var(--accent-rgb) / 0.35)",
                display: "flex", alignItems: "center", justifyContent: "center",
                border: "none",
                cursor: !loading ? "pointer" : "default",
                transition: "background-color 0.18s, color 0.18s",
              }}
            >
              <OptionalSvgIcon name="send" className="h-4 w-4" colorClassName="text-on-accent" />
            </button>
          ) : (
            <GlossyIconButton aria-label="Close chat" onClick={handleDismiss} size={38}><GlossyCloseIcon /></GlossyIconButton>
          )}
        </div>
      </div>
      )}

      {/* Controlled mode (e.g. desktop): render just the input row inline where hideTrigger is set and open is true, anchored bottom same as mobile pill would be, so typing still works without the floating circle. */}
      {hideTrigger && open && (
        <div
          className={`smoked-glass-surface ai-chat-panel fixed rounded-full border border-transparent text-accent overflow-hidden${loading ? " ai-thinking" : ""}`}
          style={{
            zIndex: 1002,
            bottom: pillBottom,
            right: "1rem",
            width: "calc(100vw - 2rem)",
            maxWidth: "480px",
            height: "3.5rem",
            background: chatControlGlass,
          }}
        >
          <div style={{
            position: "absolute", inset: 0,
            display: "flex", alignItems: "center", gap: 8,
            padding: "0 8px 0 20px",
          }}>
            <input
              ref={inputRef}
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); } }}
              placeholder={`Ask about ${stock.symbol}…`}
              className="text-white placeholder:text-white/45"
              style={{ flex: 1, background: "transparent", border: "none", outline: "none", fontSize: 16, color: textColor, caretColor: "var(--color-accent)" }}
            />
            {input.trim() ? (
              <button
                onClick={sendMessage}
                disabled={loading}
                className="ai-send-button-glow"
                style={{
                  flexShrink: 0, height: 38, width: 38,
                  borderRadius: "50%",
                  backgroundColor: !loading ? "var(--color-accent)" : "rgb(var(--accent-rgb) / 0.18)",
                  color: !loading ? "var(--color-on-accent)" : "rgb(var(--accent-rgb) / 0.35)",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  border: "none",
                  cursor: !loading ? "pointer" : "default",
                }}
              >
                <OptionalSvgIcon name="send" className="h-4 w-4" colorClassName="text-on-accent" />
              </button>
            ) : (
              <GlossyIconButton aria-label="Close chat" onClick={handleDismiss} size={38}><GlossyCloseIcon /></GlossyIconButton>
            )}
          </div>
        </div>
      )}

      <style>{`
      `}</style>
    </>,
    document.body
  );
}
