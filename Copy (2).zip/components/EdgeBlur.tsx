"use client";

interface EdgeBlurProps {
  position?: "top" | "bottom";
  height?: number | string;
  className?: string;
}

// Progressive blur: several stacked layers of increasing blur strength,
// each masked to fade from opaque (at the edge) to transparent (toward the
// content) — so text/images scrolling underneath soften out gradually
// instead of hard-clipping under fixed chrome (the mobile bottom nav pill).
export function EdgeBlur({ position = "bottom", height = 130, className = "" }: EdgeBlurProps) {
  const blurLayers = [1, 2, 3, 6, 12];
  const isTop = position === "top";
  return (
    <div
      className={`fixed inset-x-0 isolate z-20 pointer-events-none ${isTop ? "top-0" : "bottom-0"} ${className}`}
      style={{ height }}
      aria-hidden
    >
      {blurLayers.map((blur) => (
        <div
          key={blur}
          className={`edge-blur-layer edge-blur-layer-${blur} absolute inset-0`}
          style={{
            backdropFilter: `blur(${blur}px)`,
            WebkitBackdropFilter: `blur(${blur}px)`,
            // Top is the exact vertical mirror of the working bottom edge:
            // strongest at the screen edge, then fading into the page.
            maskImage: `linear-gradient(to ${isTop ? "bottom" : "top"}, black, transparent)`,
            WebkitMaskImage: `linear-gradient(to ${isTop ? "bottom" : "top"}, black, transparent)`,
          }}
        />
      ))}
    </div>
  );
}

// Convenience exports for specific positions
export function TopBlur({ height = 130, className = "" }: { height?: number | string; className?: string }) {
  return <EdgeBlur position="top" height={height} className={className} />;
}

export function BottomBlur({ height = 90 }: { height?: number }) {
  return <EdgeBlur position="bottom" height={height} className="bottom-edge-blur" />;
}

// Self-contained blur meant to be the FIRST child of a sticky/positioned
// header (position: sticky already qualifies as a containing block). It
// fills the header's own box exactly — including any safe-area-inset-top
// padding, so it reaches the true top of the screen — and fades from
// opaque at the top to transparent at the header's own bottom edge. Because
// it's a normal DOM child rendered first, the header's actual text/buttons
// simply paint after it in the same box and sit above it automatically —
// no separate global overlay, no z-index race against anything else.
//
// Single backdrop-filter layer (not stacked) — stacking several inside a
// position: sticky, safe-area-padded container caused WebKit to render an
// inconsistent seam right at the safe-area boundary on real devices.
export function HeaderTopBlur() {
  return (
    <div
      className="absolute inset-0 -z-10 pointer-events-none"
      aria-hidden
      style={{
        backdropFilter: "blur(14px)",
        WebkitBackdropFilter: "blur(14px)",
        maskImage: "linear-gradient(to bottom, black 0%, black 55%, transparent 100%)",
        WebkitMaskImage: "linear-gradient(to bottom, black 0%, black 55%, transparent 100%)",
      }}
    />
  );
}
