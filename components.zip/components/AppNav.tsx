"use client";

import Link from "next/link";
import { List, Settings, Moon, Sun, Monitor, X } from "lucide-react";
import { usePathname } from "next/navigation";
import { useEffect, useLayoutEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";

import { cn } from "@/lib/utils";
import { TestPushNotificationButton } from "@/components/TestPushNotificationButton";

type Theme = "dark" | "light" | "system";

function Toggle({ enabled }: { enabled: boolean }) {
  return (
    <span className="shrink-0 h-6 w-11 rounded-full border-2 transition-colors relative"
      style={{ borderColor: enabled ? "var(--color-accent)" : "var(--color-border-subtle)", backgroundColor: enabled ? "var(--color-accent)" : "var(--color-panel-muted)" }}>
      <span className="absolute top-0.5 h-4 w-4 rounded-full bg-white shadow transition-all duration-200"
        style={{ left: enabled ? "calc(100% - 1.125rem)" : "0.125rem" }} />
    </span>
  );
}

function getStoredTheme(): Theme {
  if (typeof window === "undefined") return "dark";
  return (localStorage.getItem("theme") as Theme) ?? "dark";
}

function applyTheme(theme: Theme) {
  const html = document.documentElement;
  const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
  const isDark = theme === "dark" || (theme === "system" && prefersDark);
  html.classList.toggle("light-mode", !isDark);
  localStorage.setItem("theme", theme);
  // Keep Safari's status-bar/dynamic-island color matching the app's actual
  // resolved theme — not the OS's — so a light-mode page never shows a
  // stray gray/dark bar just because the phone itself is set to dark mode.
}

function GlobeIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <circle cx="12" cy="12" r="9" />
      <line x1="12" y1="3" x2="12" y2="21" />
      <line x1="3" y1="12" x2="21" y2="12" />
      <path d="M4.5 7.5 Q12 6 19.5 7.5" />
      <path d="M4.5 16.5 Q12 18 19.5 16.5" />
      <path d="M12 3 Q6.5 12 12 21" />
      <path d="M12 3 Q17.5 12 12 21" />
    </svg>
  );
}

// Desktop settings dropdown
function DesktopSettingsPanel({ onClose, anchorRef }: { onClose: () => void; anchorRef: { current: HTMLButtonElement | null } }) {
  const [theme, setTheme]     = useState<Theme>(getStoredTheme);
  const [proMode, setProMode] = useState(() =>
    typeof window !== "undefined" ? localStorage.getItem("pro-mode") === "1" : false
  );
  const [showVolumeChart, setShowVolumeChart] = useState(() =>
    typeof window !== "undefined" ? localStorage.getItem("pro-volume-chart") !== "0" : true
  );
  const [useCandlesticks, setUseCandlesticks] = useState(() =>
    typeof window !== "undefined" ? localStorage.getItem("chart-style") === "candles" : false
  );
  const [colorVolumeBars, setColorVolumeBars] = useState(() =>
    typeof window !== "undefined" ? localStorage.getItem("pro-volume-color-bars") === "1" : false
  );
  const [showAlertLines, setShowAlertLines] = useState(() =>
    typeof window !== "undefined" ? localStorage.getItem("pro-alert-lines") === "1" : false
  );
  const panelRef = useRef<HTMLDivElement>(null);
  const [position, setPosition] = useState<{ top: number; left: number }>({ top: 0, left: 0 });

  useLayoutEffect(() => {
    const updatePosition = () => {
      const rect = anchorRef.current?.getBoundingClientRect();
      if (!rect) return;
      setPosition({ top: rect.bottom + 8, left: Math.max(12, Math.min(rect.right - 288, window.innerWidth - 300)) });
    };
    function handleClick(e: MouseEvent) {
      const target = e.target as Node;
      if (panelRef.current && !panelRef.current.contains(target) && !anchorRef.current?.contains(target)) onClose();
    }
    updatePosition();
    window.addEventListener("resize", updatePosition);
    window.addEventListener("scroll", updatePosition, true);
    document.addEventListener("mousedown", handleClick);
    return () => {
      window.removeEventListener("resize", updatePosition);
      window.removeEventListener("scroll", updatePosition, true);
      document.removeEventListener("mousedown", handleClick);
    };
  }, [onClose, anchorRef]);

  function changeTheme(t: Theme) {
    setTheme(t);
    applyTheme(t);
  }

  function toggleProMode() {
    const next = !proMode;
    setProMode(next);
    localStorage.setItem("pro-mode", next ? "1" : "0");
    window.dispatchEvent(new Event("pro-mode-changed"));
  }

  function toggleVolumeChart() {
    const next = !showVolumeChart;
    setShowVolumeChart(next);
    localStorage.setItem("pro-volume-chart", next ? "1" : "0");
    window.dispatchEvent(new Event("pro-volume-chart-changed"));
  }

  function toggleCandlesticks() {
    const next = !useCandlesticks;
    setUseCandlesticks(next);
    localStorage.setItem("chart-style", next ? "candles" : "line");
    window.dispatchEvent(new Event("chart-style-changed"));
  }

  function toggleVolumeBarColors() {
    const next = !colorVolumeBars;
    setColorVolumeBars(next);
    localStorage.setItem("pro-volume-color-bars", next ? "1" : "0");
    window.dispatchEvent(new Event("pro-volume-color-bars-changed"));
  }

  function toggleAlertLines() {
    const next = !showAlertLines;
    setShowAlertLines(next);
    localStorage.setItem("pro-alert-lines", next ? "1" : "0");
    window.dispatchEvent(new Event("pro-alert-lines-changed"));
  }

  const themeOptions: { value: Theme; label: string; icon: React.ReactNode }[] = [
    { value: "dark",   label: "Dark",   icon: <Moon className="h-4 w-4" /> },
    { value: "light",  label: "Light",  icon: <Sun  className="h-4 w-4" /> },
    { value: "system", label: "System", icon: <Monitor className="h-4 w-4" /> },
  ];

  return typeof document === "undefined" ? null : createPortal((
    <div
      ref={panelRef}
      className="desktop-alert-glass smoked-glass-surface fixed z-[1201] w-72 overflow-hidden rounded-3xl border border-border-subtle bg-panel shadow-2xl"
      style={{ ...position, background: "linear-gradient(145deg, rgba(8,20,20,0.48), rgba(5,15,15,0.62) 56%, rgba(3,10,10,0.54))", backdropFilter: "blur(24px) saturate(180%)", WebkitBackdropFilter: "blur(24px) saturate(180%)", boxShadow: "0 24px 70px rgba(0,0,0,0.28), 0 6px 22px rgba(0,0,0,0.14), inset 0 0 18px rgba(0,0,0,0.18)", animation: "dropIn 0.15s ease both" }}
    >
      <div className="flex items-center justify-between px-4 py-3 border-b border-border-subtle">
        <h2 className="mt-2 text-3xl font-semibold tracking-normal text-text-primary">Settings</h2>
        <button type="button" aria-label="Close settings" onClick={onClose} className="flex h-9 w-9 items-center justify-center rounded-full bg-accent text-black transition hover:brightness-105 active:scale-95">
          <X className="h-4 w-4" />
        </button>
      </div>

      {/* Appearance */}
      <div className="px-4 py-3 border-b border-border-subtle">
        <p className="text-xs font-semibold uppercase tracking-widest text-accent mb-2">Appearance</p>
        <div className="flex gap-2">
          {themeOptions.map(opt => (
            <button
              key={opt.value}
              onClick={() => changeTheme(opt.value)}
              className={cn(
                "flex-1 flex flex-col items-center gap-1.5 rounded-lg p-2.5 border text-xs font-medium transition-all",
                theme === opt.value
                  ? "bg-accent/10 border-accent text-accent"
                  : "border-border-subtle text-text-muted hover:border-accent/40"
              )}
            >
              {opt.icon}
              {opt.label}
            </button>
          ))}
        </div>
      </div>

      {/* Pro Mode */}
      <div className="px-4 py-3">
        <p className="text-xs font-semibold uppercase tracking-widest text-accent mb-2">Pro Mode</p>
        <button
          onClick={toggleProMode}
          className="w-full flex items-center justify-between gap-3 rounded-lg border border-border-subtle px-3 py-2.5"
        >
          <span className="flex flex-col gap-0.5 text-left">
            <span className="text-sm text-text-primary font-medium">Horizontal crosshair</span>
            <span className="text-xs text-text-muted">Adds horizontal line at hovered price level</span>
          </span>
          <span className="shrink-0 h-6 w-11 rounded-full border-2 transition-colors relative"
            style={{ borderColor: proMode ? "var(--color-accent)" : "var(--color-border-subtle)",
                     backgroundColor: proMode ? "var(--color-accent)" : "var(--color-panel-muted)" }}>
            <span className="absolute top-0.5 h-4 w-4 rounded-full bg-white shadow transition-all duration-200"
              style={{ left: proMode ? "calc(100% - 1.125rem)" : "0.125rem" }} />
          </span>
        </button>
        <button
          onClick={toggleCandlesticks}
          className="mt-2 w-full flex items-center justify-between gap-3 rounded-lg border border-border-subtle px-3 py-2.5"
        >
          <span className="flex flex-col gap-0.5 text-left">
            <span className="text-sm text-text-primary font-medium">Candlestick chart</span>
            <span className="text-xs text-text-muted">Shows open, high, low, and close for each interval</span>
          </span>
          <span className="shrink-0 h-6 w-11 rounded-full border-2 transition-colors relative"
            style={{ borderColor: useCandlesticks ? "var(--color-accent)" : "var(--color-border-subtle)",
                     backgroundColor: useCandlesticks ? "var(--color-accent)" : "var(--color-panel-muted)" }}>
            <span className="absolute top-0.5 h-4 w-4 rounded-full bg-white shadow transition-all duration-200"
              style={{ left: useCandlesticks ? "calc(100% - 1.125rem)" : "0.125rem" }} />
          </span>
        </button>
      </div>

      <div className="px-4 py-3 border-t border-border-subtle">
        <p className="text-xs font-semibold uppercase tracking-widest text-accent mb-2">Pro Features</p>
        <button onClick={toggleVolumeChart} className="w-full flex items-center justify-between gap-3 rounded-lg border border-border-subtle px-3 py-2.5">
          <span className="flex flex-col gap-0.5 text-left"><span className="text-sm text-text-primary font-medium">Volume chart</span><span className="text-xs text-text-muted">Shows trading volume below the timeframes</span></span>
          <Toggle enabled={showVolumeChart} />
        </button>
        <button onClick={toggleVolumeBarColors} disabled={!showVolumeChart} className="mt-2 w-full flex items-center justify-between gap-3 rounded-lg border border-border-subtle px-3 py-2.5 transition-opacity disabled:opacity-35 disabled:cursor-not-allowed">
          <span className="flex flex-col gap-0.5 text-left"><span className="text-sm text-text-primary font-medium">Color bars</span><span className="text-xs text-text-muted">Uses green for up intervals and muted red for down intervals</span></span>
          <Toggle enabled={colorVolumeBars} />
        </button>
        <button onClick={toggleAlertLines} className="mt-2 w-full flex items-center justify-between gap-3 rounded-lg border border-border-subtle px-3 py-2.5">
          <span className="flex flex-col gap-0.5 text-left"><span className="text-sm text-text-primary font-medium">Alert price lines</span><span className="text-xs text-text-muted">Show saved alert levels on stock charts</span></span>
          <Toggle enabled={showAlertLines} />
        </button>
        <TestPushNotificationButton compact />
      </div>

      <style>{`
        @keyframes dropIn {
          from { opacity: 0; transform: translateY(-6px); }
          to   { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  ), document.body);
}

const navItems = [
  { href: "/", label: "Market", icon: "globe" as const },
  { href: "/watchlist", label: "Watchlist", icon: "list" as const },
] as const;

type AppNavProps = {
  /** Lets the watchlist header place Settings beside its search field. */
  variant?: "full" | "links" | "settings";
};

export function AppNav({ variant = "full" }: AppNavProps) {
  const pathname     = usePathname();
  const [settingsOpen, setSettingsOpen] = useState(false);
  const settingsButtonRef = useRef<HTMLButtonElement>(null);

  // Apply stored theme on mount (desktop)
  useEffect(() => {
    applyTheme(getStoredTheme());
  }, []);

  const links = navItems.map((item) => {
        const isActive = item.href === "/" ? pathname === "/" : pathname.startsWith(item.href);
        return (
          <Link
            key={item.href}
            href={item.href}
            className={cn(
              "group flex items-center gap-2 text-base font-semibold text-text-primary transition-all duration-200 hover:-translate-y-1 hover:scale-[1.04]",
              variant === "links" && "rounded-full border border-transparent px-3 py-1.5 hover:border-white/20"
            )}
          >
            <span className={cn(
              "flex h-10 w-10 items-center justify-center rounded-md border transition-all duration-200",
              variant === "links" && "h-7 w-7 rounded-full border-0",
              variant === "links" && isActive && "scale-[1.2]",
              isActive
                ? "border-accent bg-accent text-black"
                : "border-transparent bg-transparent text-accent group-hover:border-transparent"
            )}>
              {item.icon === "globe"
                ? <GlobeIcon className="h-5 w-5" />
                : <List className="h-5 w-5" aria-hidden />
              }
            </span>
            <span>{item.label}</span>
          </Link>
        );
      });

  const settings = (
    <div className="relative">
      <button
        ref={settingsButtonRef}
        onClick={() => setSettingsOpen(o => !o)}
        aria-label="Settings"
        className={cn(
          "group flex items-center gap-2 text-base font-semibold text-text-primary transition-all duration-200 hover:-translate-y-1 hover:scale-[1.04]",
          variant === "settings" && "h-11 w-11 items-center justify-center rounded-full border border-transparent bg-transparent backdrop-blur-xl hover:border-white/20"
        )}
      >
        <span className={cn(
          "flex h-10 w-10 items-center justify-center rounded-md border transition-all duration-200",
          variant === "settings" && "h-8 w-8 rounded-full border-0",
          variant === "settings" && settingsOpen && "scale-[1.2]",
          settingsOpen
            ? "border-accent bg-accent text-black"
            : "border-transparent bg-transparent text-accent group-hover:border-transparent"
        )}>
          <Settings className="h-5 w-5" />
        </span>
        {variant !== "settings" && <span>Settings</span>}
      </button>
      {settingsOpen && <DesktopSettingsPanel anchorRef={settingsButtonRef} onClose={() => setSettingsOpen(false)} />}
    </div>
  );

  if (variant === "links") {
    return <nav className="flex items-center gap-4 relative">{links}</nav>;
  }

  if (variant === "settings") {
    return <nav aria-label="Settings">{settings}</nav>;
  }

  return (
    <nav className="flex items-center gap-4 relative">
      {links}

      {/* Settings button */}
      {settings}
    </nav>
  );
}
