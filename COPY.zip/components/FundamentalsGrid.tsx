"use client";

import { useEffect, useState } from "react";
import { createPortal } from "react-dom";

import { formatCompact, formatCurrency, formatPercent } from "@/lib/format";
import { WheelPrice } from "@/components/PriceChart";
import { OptionalSvgIcon } from "@/components/OptionalSvgIcon";
import { GlossyCloseIcon, GlossyIconButton } from "@/components/GlossyIconButton";

type MetricValue = number | string | null;

type FundamentalItem = {
  label: string;
  value: string;
  tone: "positive" | "neutral" | "negative";
  note: string;
};

const INDICATOR_DESCRIPTIONS: Record<string, string> = {
  "Market Cap": "The market value of the company's outstanding shares. It gives a rough sense of the company's overall size.",
  Beta: "A measure of how much the stock has moved relative to the broader market. Values above 1 have historically moved more than the market; below 1, less.",
  "P/E Ratio": "The share price compared with the company's earnings per share. Investors often use it to compare valuation with earnings and peers.",
  "Forward P/E": "The share price compared with forecast earnings per share. It reflects expectations and can change as estimates are updated.",
  PEG: "The P/E ratio adjusted for expected earnings growth. It combines valuation and growth estimates, so it depends on forecast quality.",
  EPS: "Earnings per share: the company's profit allocated to each outstanding share over the reported period.",
  "Avg. Volume": "The average number of shares traded per day. Higher volume generally means more trading activity.",
  "Dividend Yield": "Annual dividends as a percentage of the share price. The yield can change when the price or dividend changes.",
  "52W Low": "The lowest share price recorded over the past 52 weeks.",
  "52W High": "The highest share price recorded over the past 52 weeks.",
};

function toNumber(value: MetricValue | undefined) {
  if (typeof value === "number") return value;
  if (typeof value === "string") {
    const parsed = Number(value);
    return Number.isNaN(parsed) ? null : parsed;
  }
  return null;
}

function formatRatio(value: number | null) {
  if (value === null) return "N/A";
  return new Intl.NumberFormat("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(value);
}

function ratioTone(value: number | null, low: number, high: number, lowerIsBetter = true) {
  if (value === null) return { tone: "neutral" as const, note: "Data unavailable" };

  if (lowerIsBetter) {
    if (value <= low) return { tone: "positive" as const, note: "Below Average" };
    if (value >= high) return { tone: "negative" as const, note: "Above Average" };
  } else {
    if (value >= high) return { tone: "positive" as const, note: "Above Average" };
    if (value <= low) return { tone: "negative" as const, note: "Below Average" };
  }

  return { tone: "neutral" as const, note: "In Range" };
}

function dividendTone(value: number | null) {
  if (value === null) return { tone: "neutral" as const, note: "Data unavailable" };
  if (value >= 3) return { tone: "positive" as const, note: "Above Average" };
  if (value <= 0.5) return { tone: "neutral" as const, note: "Low Yield" };
  return { tone: "positive" as const, note: "Shareholder Return" };
}

function highLowTone(currentPrice: number, target: number | null, type: "high" | "low") {
  if (!target || !currentPrice) return { tone: "neutral" as const, note: "Data unavailable" };
  const distance = Math.abs(currentPrice - target) / target;
  if (type === "high" && distance < 0.08) return { tone: "negative" as const, note: "Near 52W High" };
  if (type === "low" && distance < 0.12) return { tone: "positive" as const, note: "Near 52W Low" };
  return { tone: "neutral" as const, note: "Normal Range" };
}

function invertedSentimentColor(position: number) {
  const stops: [number, [number, number, number]][] = [
    [0, [52, 211, 153]], [25, [163, 230, 53]], [50, [250, 204, 21]],
    [75, [249, 115, 22]], [100, [220, 38, 38]],
  ];
  const clamped = Math.max(0, Math.min(100, position));
  let low = stops[0];
  let high = stops[stops.length - 1];
  for (let index = 0; index < stops.length - 1; index += 1) {
    if (clamped >= stops[index][0] && clamped <= stops[index + 1][0]) {
      low = stops[index];
      high = stops[index + 1];
      break;
    }
  }
  const progress = (clamped - low[0]) / (high[0] - low[0] || 1);
  return `rgb(${low[1].map((channel, index) => Math.round(channel + (high[1][index] - channel) * progress)).join(", ")})`;
}

export function FundamentalsGrid({
  metrics,
  marketCap,
  currentPrice,
  stockSymbol = "",
  stockName = "",
  isEtf = false,
  show52WeekRange = false
}: {
  metrics?: Record<string, MetricValue>;
  marketCap?: number;
  currentPrice: number;
  stockSymbol?: string;
  stockName?: string;
  isEtf?: boolean;
  show52WeekRange?: boolean;
}) {
  const pe = toNumber(metrics?.peTTM ?? metrics?.peNormalizedAnnual);
  const forwardPe = toNumber(metrics?.forwardPE ?? null);        // ✅ correct Finnhub field
  const peg = (() => {
    const raw = toNumber(metrics?.pegRatio);
    if (raw) return raw;
    if (!pe || pe <= 0) return null;
    const growth = toNumber(metrics?.epsGrowth5Y)
      ?? toNumber(metrics?.epsGrowth3Y)
      ?? toNumber(metrics?.revenueGrowth5Y)
      ?? toNumber(metrics?.revenueGrowth3Y);
    if (!growth || growth <= 0) return null;
    return pe / growth;
})();
  const eps = toNumber(metrics?.epsNormalizedAnnual ?? metrics?.epsTTM);
  const dividendYield = toNumber(metrics?.dividendYieldIndicatedAnnual);
  const beta = toNumber(metrics?.beta);
  const high52 = toNumber(metrics?.["52WeekHigh"]);
  const low52 = toNumber(metrics?.["52WeekLow"]);
  const volume = toNumber(metrics?.["10DayAverageTradingVolume"]);
  const [selectedIndicator, setSelectedIndicator] = useState<FundamentalItem | null>(null);
  useEffect(() => {
    if (!selectedIndicator) return;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => { document.body.style.overflow = previousOverflow; };
  }, [selectedIndicator]);

  function askWarrentAboutIndicator(item: FundamentalItem) {
    const company = stockName || stockSymbol || "this stock";
    const prompt = `What has been happening lately with ${item.label} for ${company}${stockSymbol ? ` (${stockSymbol})` : ""}? The current reading is ${item.value}. Explain what this indicator is showing, recent relevant changes and likely drivers, and how it relates to the stock's recent performance. Keep it concise.`;
    setSelectedIndicator(null);
    window.dispatchEvent(new CustomEvent("warrent-ask-indicator", { detail: { symbol: stockSymbol, prompt } }));
  }

  const items: FundamentalItem[] = [
    {
      label: "Market Cap",
      value: formatCompact((marketCap ?? 0) * 1_000_000),
      tone: "neutral",
      note: "Company Size"
    },
    { label: "Beta", value: formatRatio(beta), ...ratioTone(beta, 0.8, 1.4) },
    {
      label: "P/E Ratio",
      value: pe !== null ? formatRatio(pe) : eps !== null && eps < 0 ? "Loss-making" : "N/A",
      ...(pe !== null
        ? ratioTone(pe, 15, 30)
        : eps !== null && eps < 0
        ? { tone: "negative" as const, note: "Negative EPS" }
        : { tone: "neutral" as const, note: "Data unavailable" })
    },
    {
      label: "Forward P/E",
      value: forwardPe !== null ? formatRatio(forwardPe) : eps !== null && eps < 0 ? "Loss-making" : "N/A",
      ...(forwardPe !== null
        ? ratioTone(forwardPe, 15, 28)
        : eps !== null && eps < 0
        ? { tone: "negative" as const, note: "Negative EPS" }
        : { tone: "neutral" as const, note: "Data unavailable" })
    },
    { label: "PEG", value: formatRatio(peg), ...ratioTone(peg, 1, 2) },
    {
      label: "EPS",
      value: formatCurrency(eps),
      tone: eps && eps > 0 ? "positive" : "negative",
      note: eps && eps > 0 ? "Profitable" : "Watch Earnings"
    },
    { label: "Avg. Volume", value: formatCompact(volume ? volume * 1_000_000 : null), tone: "neutral", note: "10 Day Avg." },
    { label: "Dividend Yield", value: formatPercent(dividendYield), ...dividendTone(dividendYield) }
  ];

  if (!show52WeekRange) {
    items.splice(6, 0,
      { label: "52W Low", value: formatCurrency(low52), ...highLowTone(currentPrice, low52, "low") },
      { label: "52W High", value: formatCurrency(high52), ...highLowTone(currentPrice, high52, "high") }
    );
  }

  const ETF_EXCLUDED_LABELS = new Set([
    "Market Cap", "P/E Ratio", "Forward P/E", "PEG", "EPS", "Dividend Yield"
  ]);
  const visibleItems = isEtf ? items.filter(item => !ETF_EXCLUDED_LABELS.has(item.label)) : items;
  const indicatorGroups = [
    ["Market Cap", "Beta", "P/E Ratio", "Forward P/E"],
    ["PEG", "EPS"],
    ["52W Low", "52W High", "Avg. Volume", "Dividend Yield"],
  ].map((labels) => labels
    .map((label) => visibleItems.find((item) => item.label === label))
    .filter((item): item is FundamentalItem => item !== undefined))
    .filter((group) => group.length > 0);

  return (
    <section>
      <p className="mb-3 inline-flex items-center gap-2 text-sm font-medium uppercase tracking-[0.18em] text-accent">
        <OptionalSvgIcon name="indicators" className="h-6 w-6" colorClassName="text-accent" />Indicators
      </p>
      <div className="mx-5 grid grid-cols-1 gap-y-2">
        {indicatorGroups.map((group, groupIndex) => (
          <div key={groupIndex} className="grid grid-cols-2 gap-x-4 gap-y-2">
            {group.map((item) => (
              <button
                key={item.label}
                type="button"
                onClick={() => setSelectedIndicator(item)}
                className="indicator-data-pill min-w-0 w-full rounded-3xl border px-4 py-3 text-left"
                aria-label={`${item.label}: ${item.value}. Open explanation`}
              >
                <span className="indicator-data-pill__label block truncate text-xs uppercase tracking-[0.12em]">{item.label}</span>
                <span className="indicator-data-pill__value mt-1 block text-xl font-semibold">
                  <WheelPrice value={item.value} size="md" compact colorClass="indicator-data-pill__value" />
                </span>
              </button>
            ))}
          </div>
        ))}
      </div>
      {show52WeekRange && high52 !== null && low52 !== null && high52 >= low52 && (
        <div className="mx-5 mt-2">
          <p className="mb-3 text-xs uppercase tracking-[0.12em] text-text-muted">52W Range</p>
          {(() => {
            // Low is at the left and high is at the right, like a range scale.
            const position = high52 === low52 ? 50 : ((currentPrice - low52) / (high52 - low52)) * 100;
            const clampedPosition = Math.max(0, Math.min(100, position));
            // Stock sentiment colors the filled portion from its current score.
            // Use one color across this full-width range, inverse toward red at 52W high.
            const color = invertedSentimentColor(clampedPosition);
            const glow = color.replace("rgb(", "rgba(").replace(")", ", 0.42)");
            return (
              <div className="w-full">
                <div className="mb-3 flex items-center justify-between gap-3 text-xl font-semibold text-text-primary">
                  <span>{formatCurrency(low52)}</span>
                  <span>{formatCurrency(high52)}</span>
                </div>
                <div className="relative h-2 w-full rounded-full bg-panel-muted">
                  <div className="h-full w-full rounded-full" style={{ backgroundColor: color, boxShadow: `0 0 10px ${glow}` }} />
                  <span
                    className="absolute top-1/2 h-4 w-0.5 -translate-x-1/2 -translate-y-1/2 rounded-full"
                    style={{ left: `${clampedPosition}%`, backgroundColor: "var(--color-range-marker)" }}
                    aria-label={`Current price ${formatCurrency(currentPrice)}, position ${Math.round(clampedPosition)}% of the 52 week range`}
                    title={`Current price: ${formatCurrency(currentPrice)}`}
                  />
                </div>
                <div className="relative mt-2 h-7">
                  <span
                    className="absolute top-0 whitespace-nowrap text-xl font-semibold text-text-primary"
                    style={{
                      left: `${clampedPosition}%`,
                      transform: clampedPosition <= 5 ? "translateX(0)" : clampedPosition >= 95 ? "translateX(-100%)" : "translateX(-50%)",
                    }}
                  >
                    {formatCurrency(currentPrice)}
                  </span>
                </div>
              </div>
            );
          })()}
        </div>
      )}
      {selectedIndicator && typeof document !== "undefined" && createPortal(
        <div
          className="smoked-glass-backdrop fixed inset-0 z-[9999] flex items-center justify-center p-4"
          style={{ background: "rgba(0,0,0,0.16)", backdropFilter: "blur(12px) brightness(0.97)", WebkitBackdropFilter: "blur(12px) brightness(0.97)" }}
          onClick={(event) => { if (event.target === event.currentTarget) setSelectedIndicator(null); }}
        >
          <div
            className="indicator-detail-panel smoked-glass-surface w-full max-w-sm rounded-3xl border border-white/15 p-5 shadow-2xl"
            style={{ background: "linear-gradient(145deg, rgba(8,20,20,0.48), rgba(5,15,15,0.62) 56%, rgba(3,10,10,0.54))", backdropFilter: "blur(24px) saturate(180%)", WebkitBackdropFilter: "blur(24px) saturate(180%)", boxShadow: "0 24px 70px rgba(0,0,0,0.28), 0 6px 22px rgba(0,0,0,0.14), inset 0 0 18px rgba(0,0,0,0.18)" }}
            onClick={(event) => event.stopPropagation()}
          >
            <div className="mb-5 flex items-center justify-between gap-3">
              <div className="flex min-w-0 items-center gap-3">
                <OptionalSvgIcon name="info" className="h-6 w-6" colorClassName="text-text-primary" />
                <h2 className="text-3xl font-semibold tracking-normal text-text-primary">{selectedIndicator.label}</h2>
              </div>
              <GlossyIconButton aria-label="Close indicator details" onClick={() => setSelectedIndicator(null)}><GlossyCloseIcon /></GlossyIconButton>
            </div>
            <p className="mb-6 text-sm leading-6 text-text-primary">{INDICATOR_DESCRIPTIONS[selectedIndicator.label] ?? `${selectedIndicator.label} is a financial measure used to understand the company's performance or valuation.`}</p>
            <button
              type="button"
              onClick={() => askWarrentAboutIndicator(selectedIndicator)}
              className="h-11 w-full rounded-full bg-accent text-sm font-semibold text-on-accent"
            >
              <span className="inline-flex items-center justify-center gap-2" style={{ color: "var(--AI_COLOR)" }}>
                <OptionalSvgIcon name="ai" className="h-5 w-5" color="var(--AI_COLOR)" />
                Ask Warrent
              </span>
            </button>
          </div>
        </div>,
        document.body
      )}
    </section>
  );
}
