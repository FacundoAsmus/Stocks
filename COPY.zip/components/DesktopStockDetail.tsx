import type { RefObject } from "react";

import { AddToWatchlistButton } from "@/components/AddToWatchlistButton";
import { AnalystSection } from "@/components/AnalystSection";
import { CompanyDescription } from "@/components/CompanyDescription";
import { FundamentalsGrid } from "@/components/FundamentalsGrid";
import { FilingIndicators } from "@/components/FilingIndicators";
import { DesktopEarningsCalendar } from "@/components/desktop/DesktopEarningsCalendar";
import { MarketSentiment } from "@/components/MarketSentiment";
import { NewsCard } from "@/components/NewsCard";
import { NewsSummary } from "@/components/NewsSummary";
import { PriceChart } from "@/components/PriceChart";
import { StockLogo } from "@/components/StockLogo";
import { StockPriceAlertButton } from "@/components/StockPriceAlertButton";
import { AIUnavailableNotice } from "@/components/AIUnavailableNotice";
import { StockFunctionButton, StockChartToolsMenu } from "@/components/desktop/StockToolsButton";
import { OptionalSvgIcon } from "@/components/OptionalSvgIcon";
import { SECTOR_ETFS } from "@/lib/etfs";
import type { getStockDetail } from "@/lib/finnhub";

type StockDetail = Awaited<ReturnType<typeof getStockDetail>>;

interface DesktopStockDetailProps {
  stock: StockDetail;
  currentPrice: number;
  sentiment: { score: number; drivers: string[] };
  metrics: Record<string, number | string | null> | undefined;
  /** Height passed to the price chart. Defaults to the size used on the standalone stock page. */
  chartHeightClassName?: string;
  /** When provided (e.g. from the watchlist split view), the earnings
   *  calendar sheet is confined to this element's bounds instead of the
   *  full viewport. Left undefined on the standalone stock page, where
   *  full-viewport is correct. */
  earningsCalendarContainerRef?: RefObject<HTMLElement | null>;
  /** Hides the cursor-following date bubble in the compact watchlist detail panel. */
  hideCursorDateTooltip?: boolean;
  /** Enlarges and vertically centers the title in the desktop watchlist detail pane. */
  watchlistDetailHeader?: boolean;
}

// This is the exact "Desktop stock page" content that used to live inline in
// app/stock/[symbol]/page.tsx. It's now a standalone component so it can be
// rendered both there (full page, unchanged) and inside the right-hand panel
// of the merged desktop watchlist view.
export function DesktopStockDetail({
  stock,
  currentPrice,
  sentiment,
  metrics,
  chartHeightClassName = "h-[461px]",
  earningsCalendarContainerRef,
  hideCursorDateTooltip = false,
  watchlistDetailHeader = false
}: DesktopStockDetailProps) {
  // ETFs don't file earnings reports the way individual companies do — same
  // check the mobile stock page already uses to hide the calendar button and
  // filter irrelevant fundamentals (P/E, EPS, etc.) out of the grid.
  const isEtf = SECTOR_ETFS.some((e) => e.symbol === stock.symbol);
  return (
    <div className="relative space-y-6">
      <div className="relative z-10 space-y-6">
        <section className="relative p-5">
          <div className="absolute right-5 top-5 z-50 flex flex-col items-end gap-1">
            <div className="flex items-center gap-2">
              <StockPriceAlertButton symbol={stock.symbol} name={stock.profile.name ?? stock.symbol} currentPrice={currentPrice} />
              <AddToWatchlistButton symbol={stock.symbol} name={stock.profile.name ?? stock.symbol} compact hoverRemoveIcon={watchlistDetailHeader} />
            </div>
            {watchlistDetailHeader && <StockFunctionButton symbol={stock.symbol} chartHeight={384} />}
          </div>
          {watchlistDetailHeader && <StockChartToolsMenu symbol={stock.symbol} />}
          {/* ── Logo + name row ── */}
          <div className={`flex gap-4 ${watchlistDetailHeader ? "-ml-5 items-center pr-44" : "items-start"}`}>
            <div className="shrink-0">
              <StockLogo
                logo={isEtf ? undefined : stock.profile.logo}
                shape={watchlistDetailHeader ? "circle" : "rounded"}
              />
            </div>
            <div>
              <h1 className={`font-semibold tracking-normal text-text-primary ${watchlistDetailHeader ? "text-4xl sm:text-5xl" : "text-3xl sm:text-4xl"}`}>
                {stock.profile.name ?? stock.symbol}
              </h1>
              {!watchlistDetailHeader && <p className="mt-0.5 text-base text-text-muted">{stock.symbol}</p>}
            </div>
          </div>
          {/* ── Price + chart — price indented to align with name, chart full width ── */}
          <div className="mt-4">
            <PriceChart
              symbol={stock.symbol}
              currentPrice={currentPrice}
              currentChangePercent={stock.quote.dp ?? 0}
              previousClose={stock.quote.pc ?? undefined}
              heightClassName={chartHeightClassName}
              hideCursorDateTooltip={hideCursorDateTooltip}
              hideMovingAverageControls={watchlistDetailHeader}
            />
          </div>
        </section>

        <MarketSentiment score={sentiment.score} drivers={sentiment.drivers} />

        {!isEtf && (
          <AnalystSection
            recommendations={stock.recommendations}
            priceTarget={stock.priceTarget}
            currentPrice={currentPrice}
          />
        )}

        <FundamentalsGrid
          metrics={metrics}
          marketCap={stock.profile.marketCapitalization}
          currentPrice={currentPrice}
          earnings={stock.earnings}
          isEtf={isEtf}
        />

        {!isEtf && (
          <div className="flex justify-end -mb-4">
            <DesktopEarningsCalendar symbol={stock.symbol} earnings={stock.earnings} containerRef={earningsCalendarContainerRef} />
          </div>
        )}

        {!isEtf && <FilingIndicators symbol={stock.symbol} />}

        <section className="px-5">
          <div className="mb-4 flex items-end justify-between">
            <div>
              <p className="-ml-5 inline-flex items-center gap-2 text-sm font-medium uppercase tracking-[0.18em] text-accent"><OptionalSvgIcon name="news" className="h-5 w-5" />News</p>
            </div>
          </div>
          {stock.newsUnavailable ? <AIUnavailableNotice /> : stock.news.length > 0 && <NewsSummary symbol={stock.symbol} articles={stock.news} />}
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
            {stock.news.length ? (
              stock.news.map((article) => <NewsCard key={article.id} article={article} />)
            ) : stock.newsUnavailable ? null : (
              <div className="rounded-md  p-5 text-sm text-text-muted">
                No recent Finnhub news was available for this symbol.
              </div>
            )}
          </div>
        </section>

        <CompanyDescription symbol={stock.symbol} className="px-5 pb-32" />
      </div>
    </div>
  );
}
